// PY源管理入口：本地源管理、单文件导入与批量导入。
var core = $.require("hiker://page/py_core_v1844");
var items = [];
var scanFolder = core.getScanFolder();

setPageTitle("PY源管理");

items.push({
    title: "PY源管理",
    desc: "管理本地 PY 视频源",
    pic_url: getPath(core.DATA_ROOT + "/assets/settings_v116.png"),
    col_type: "icon_2",
    url: "hiker://page/py_source_manager_v1844#noRecordHistory##noHistory#",
    extra: {lineVisible: false}
});

items.push({
    title: "导入 PY",
    desc: "选择单个 .py 文件",
    pic_url: getPath(core.DATA_ROOT + "/assets/import_v116.png"),
    col_type: "icon_2",
    url: core.importUrl(),
    extra: {lineVisible: false}
});

items.push({
    title: "批量导入",
    desc: scanFolder || "选择 PY 文件夹",
    pic_url: getPath(core.DATA_ROOT + "/assets/video_source_v116.png"),
    col_type: "icon_2",
    url: "hiker://page/py_folder_picker_v1844#noRecordHistory##noHistory#",
    extra: {lineVisible: false}
});

setResult(items);
