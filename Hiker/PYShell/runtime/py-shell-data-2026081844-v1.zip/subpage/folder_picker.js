var core = $.require("hiker://page/py_core_v1844");
var items = [];
var currentPath = String((typeof MY_PARAMS !== "undefined" && MY_PARAMS && MY_PARAMS.path) || "");
var callbackCoreLoader = core.callbackCoreLoaderSource();

function openFolder(path) {
    return {
        url: "hiker://page/py_folder_picker_v1844#noRecordHistory##noHistory#",
        extra: {path: String(path || ""), lineVisible: false}
    };
}

try {
    setPageTitle("选择 PY 文件夹");
    if (!currentPath) {
        items.push({
            title: "请选择存放 PY 文件的手机目录",
            desc: "这里只浏览目录，不会自动选中或扫描。",
            col_type: "text_center_1",
            url: "hiker://empty",
            extra: {lineVisible: false}
        });
        core.listFolderRoots().forEach(function(root) {
            var route = openFolder(root.path);
            items.push({
                title: "📁 " + root.name,
                desc: root.path,
                col_type: "text_1",
                url: route.url,
                extra: route.extra
            });
        });
    } else {
        var info = core.listFolder(currentPath);
        items.push({
            title: "使用当前文件夹",
            desc: info.path + "\n检测到 " + info.pyFiles.length + " 个 PY 文件",
            pic_url: getPath(core.DATA_ROOT + "/assets/import_py.png"),
            col_type: "icon_2",
            url: $("#noLoading#").lazyRule(function(path, count, loaderSource) {
                try {
                    eval(loaderSource)(["setScanFolder"]).setScanFolder(path);
                    back(true);
                    return "toast://已选择文件夹，共 " + count + " 个 PY 文件";
                } catch (error) {
                    return "toast://" + (error && error.toString ? error.toString() : String(error));
                }
            }, info.path, info.pyFiles.length, callbackCoreLoader),
            extra: {lineVisible: false}
        });
        items.push({
            title: "扫描并导入当前文件夹",
            desc: info.pyFiles.length ? "直接检测并导入这 " + info.pyFiles.length + " 个 PY 文件" : "当前文件夹没有 PY 文件",
            pic_url: getPath(core.DATA_ROOT + "/assets/reload.png"),
            col_type: "icon_2",
            url: $("#noLoading#").lazyRule(function(path, count, loaderSource) {
                if (!count) return "toast://当前文件夹没有 PY 文件";
                try {
                    if (typeof showLoading === "function") showLoading("正在扫描并导入 " + count + " 个 PY 文件...");
                    var report = eval(loaderSource)(["importFolder"]).importFolder(path);
                    back(true);
                    return "toast://扫描完成：成功 " + report.imported + "，跳过 " + report.skipped + "，失败 " + report.failed;
                } catch (error) {
                    return "toast://批量导入失败: " + (error && error.toString ? error.toString() : String(error));
                } finally {
                    try { if (typeof hideLoading === "function") hideLoading(); } catch (ignoreHideLoadingError) {}
                }
            }, info.path, info.pyFiles.length, callbackCoreLoader),
            extra: {lineVisible: false}
        });
        if (info.parent && info.parent !== info.path) {
            var parentRoute = openFolder(info.parent);
            items.push({
                title: "⬆ 返回上级目录",
                desc: info.parent,
                col_type: "text_1",
                url: parentRoute.url,
                extra: parentRoute.extra
            });
        }
        info.folders.forEach(function(folder) {
            var route = openFolder(folder.path);
            items.push({
                title: "📁 " + folder.name,
                desc: folder.path,
                col_type: "text_1",
                url: route.url,
                extra: route.extra
            });
        });
        if (info.pyFiles.length) {
            items.push({title: "当前文件夹中的 PY", col_type: "rich_text", url: "hiker://empty"});
            info.pyFiles.slice(0, 50).forEach(function(file) {
                items.push({
                    title: file.name,
                    desc: Math.max(1, Math.round(file.size / 1024)) + " KB",
                    col_type: "text_1",
                    url: "hiker://empty",
                    extra: {lineVisible: false}
                });
            });
        }
    }
} catch (error) {
    items.push({
        title: "目录读取失败",
        desc: core.errorText(error),
        col_type: "text_center_1",
        url: "hiker://empty",
        extra: {lineVisible: false}
    });
}

setResult(items);
