// 设置页：源管理、显示模式和首页筛选开关。
var core = $.require("hiker://page/py_core_v1844");
var items = [];
var modeKey = "py_ui_mode";
var homeFiltersKey = "py_home_filters_enabled";
var savedMode = "";
try { savedMode = String(getItem(modeKey, "") || ""); } catch (ignorePersistentModeError) {}
if (!savedMode) savedMode = String(getMyVar(modeKey, "shell") || "shell");
var mode = savedMode === "simple" ? "simple" : "shell";
var homeFiltersEnabled = true;
try { homeFiltersEnabled = String(getItem(homeFiltersKey, "1")) !== "0"; } catch (ignoreHomeFiltersSettingError) {}

setPageTitle("设置");

items.push({
    title: "接口源管理",
    desc: "配置导入与线路管理",
    pic_url: getPath(core.DATA_ROOT + "/assets/settings_v116.png"),
    col_type: "icon_2",
    url: "hiker://page/py_interface_manager_v1844#noRecordHistory##noHistory#",
    extra: {lineVisible: false}
});

items.push({
    title: "PY源管理",
    desc: "管理、导入与批量导入 PY 文件",
    pic_url: getPath(core.DATA_ROOT + "/assets/video_source_v116.png"),
    col_type: "icon_2",
    url: "hiker://page/py_manager_hub_v1844#noRecordHistory##noHistory#",
    extra: {lineVisible: false}
});

items.push({
    title: "简约模式",
    desc: "当前源、历史记录、重新载入、设置",
    pic_url: getPath(core.DATA_ROOT + "/assets/reload_v116.png"),
    col_type: "icon_2",
    url: $("#noLoading#").lazyRule(function(key) {
        try { setItem(key, "simple"); } catch (ignorePersistentModeError) {}
        putMyVar(key, "simple");
        refreshPage(false);
        return "toast://已切换为简约模式";
    }, modeKey),
    extra: {
        backgroundColor: mode === "simple" ? "#E8F5F1" : "",
        textColor: mode === "simple" ? "#116B58" : "",
        lineVisible: false
    }
});

items.push({
    title: "影视壳模式",
    desc: "线路、当前源、历史、直播、设置",
    pic_url: getPath(core.DATA_ROOT + "/assets/video_source_v116.png"),
    col_type: "icon_2",
    url: $("#noLoading#").lazyRule(function(key) {
        try { setItem(key, "shell"); } catch (ignorePersistentModeError) {}
        putMyVar(key, "shell");
        refreshPage(false);
        return "toast://已切换为影视壳模式";
    }, modeKey),
    extra: {
        backgroundColor: mode === "shell" ? "#E8F5F1" : "",
        textColor: mode === "shell" ? "#116B58" : "",
        lineVisible: false
    }
});

items.push({
    title: homeFiltersEnabled ? "筛选：打开" : "筛选：关闭",
    desc: homeFiltersEnabled ? "类型、地区、语言、年份等" : "首页仅显示主分类",
    pic_url: getPath(core.DATA_ROOT + "/assets/settings_v116.png"),
    col_type: "icon_2",
    url: $("#noLoading#").lazyRule(function(key, enabled) {
        var nextValue = enabled ? "0" : "1";
        try { setItem(key, nextValue); } catch (ignorePersistentFilterSettingError) {}
        putMyVar(key, nextValue);
        refreshPage(false);
        return nextValue === "1" ? "toast://筛选已打开" : "toast://筛选已关闭";
    }, homeFiltersKey, homeFiltersEnabled),
    extra: {
        backgroundColor: homeFiltersEnabled ? "#E8F5F1" : "",
        textColor: homeFiltersEnabled ? "#116B58" : "",
        lineVisible: false
    }
});

setResult(items);
