var core = $.require("hiker://page/py_core_v1844");

function loadLiveParser(requiredMethods) {
    var parserPath = "hiker://files/data/PY\u5f71\u89c6\u58f3/subpage/live_parse.js";
    var pagePath = "hiker://page/py_live_parse_v1844";
    var methods = Array.isArray(requiredMethods) ? requiredMethods : [];
    function ready(candidate) {
        if (!candidate) return false;
        for (var i = 0; i < methods.length; i++) {
            if (typeof candidate[methods[i]] !== "function") return false;
        }
        return true;
    }
    var loaded = null;
    try { loaded = $.require(pagePath); } catch (ignoreLiveParserPageError) {}
    if (!ready(loaded)) {
        try { loaded = $.require(parserPath, true); } catch (ignoreLiveParserRequireError) {}
    }
    if (!ready(loaded)) {
        var previousExports = $.exports;
        try {
            $.exports = {};
            var code = "";
            try {
                if (typeof readFile === "function") code = String(readFile(parserPath) || "");
            } catch (ignoreLiveParserReadError) {}
            if (!code) code = String(request(parserPath) || "");
            code = code.replace(/^\s*js:\s*/, "");
            if (!code) throw new Error("直播解析模块为空");
            eval(code);
            loaded = $.exports;
        } finally {
            $.exports = previousExports;
        }
    }
    if (!ready(loaded)) {
        var missing = [];
        for (var j = 0; j < methods.length; j++) {
            if (!loaded || typeof loaded[methods[j]] !== "function") missing.push(methods[j]);
        }
        throw new Error("直播解析模块缺少方法 " + missing.join("、"));
    }
    return loaded;
}

// input/lazyRule 会脱离当前页面执行，传入可序列化加载器，避免回调中的
// hiker://page 别名命中当前页对象或旧缓存对象。
function callbackLiveParserLoaderSource() {
    return "(function(requiredMethods){" +
        "var pagePath='hiker://page/py_live_parse_v1844';" +
        "var parserPath='hiker://files/data/PY影视壳/subpage/live_parse.js';" +
        "var methods=Array.isArray(requiredMethods)?requiredMethods:[];" +
        "function ready(candidate){if(!candidate)return false;for(var i=0;i<methods.length;i++){if(typeof candidate[methods[i]]!=='function')return false;}return true;}" +
        "var loaded=null;" +
        "try{loaded=$.require(pagePath);}catch(ignorePageRequireError){}" +
        "if(!ready(loaded)){try{loaded=$.require(parserPath,true);}catch(ignoreFileRequireError){}}" +
        "if(!ready(loaded)){" +
            "var previousExports=$.exports;" +
            "try{" +
                "$.exports={};" +
                "var code='';" +
                "try{if(typeof readFile==='function')code=String(readFile(parserPath)||'');}catch(ignoreReadError){}" +
                "if(!code)code=String(request(parserPath)||'');" +
                "code=code.replace(/^\\s*js:\\s*/,'');" +
                "if(!code)throw new Error('直播解析模块为空');" +
                "eval(code);" +
                "loaded=$.exports;" +
            "}finally{$.exports=previousExports;}" +
        "}" +
        "if(!ready(loaded)){var missing=[];for(var j=0;j<methods.length;j++){if(!loaded||typeof loaded[methods[j]]!=='function')missing.push(methods[j]);}throw new Error('直播解析模块缺少方法 '+missing.join('、'));}" +
        "return loaded;" +
    "})";
}

var parser = loadLiveParser(["parseRemoteResult", "parseRemotePage"]);
var callbackLiveParserLoader = callbackLiveParserLoaderSource();
var callbackCoreLoader = core.callbackCoreLoaderSource();
var items = [];
var page = typeof MY_PAGE === "undefined" ? 1 : Math.max(1, Number(MY_PAGE || 1));
var currentKey = "py_live_current";
var groupKey = "py_live_group";
var searchKey = "py_live_search";
var LIVE_PARSER_VERSION = 2;

// movie_3 原生卡片为固定比例并使用 centerCrop，直播封面比例不一致时会裁掉边缘。
// 这里先把原图等比缩放到同一画布，再交给 movie_3，保持三列布局且完整保留图片内容。
function fitLiveCover(image) {
    if (!image) return image;
    return $(image).image(function() {
        var inputStream = input;
        if (!inputStream) return null;
        var output = new java.io.ByteArrayOutputStream();
        var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
        var length;
        while ((length = inputStream.read(buffer)) !== -1) {
            if (length > 0) output.write(buffer, 0, length);
            if (output.size() > 16 * 1024 * 1024) return new java.io.ByteArrayInputStream(output.toByteArray());
        }
        var originalBytes = output.toByteArray();
        var source = android.graphics.BitmapFactory.decodeByteArray(originalBytes, 0, originalBytes.length);
        if (!source) return new java.io.ByteArrayInputStream(originalBytes);

        // 对应 movie_2 的固定卡片比例：宽:高 = 16:9（列表改为两列大图后）。
        var targetWidth = 960;
        var targetHeight = 540;
        var scale = Math.min(targetWidth / source.getWidth(), targetHeight / source.getHeight());
        var drawWidth = Math.max(1, Math.round(source.getWidth() * scale));
        var drawHeight = Math.max(1, Math.round(source.getHeight() * scale));
        var left = Math.floor((targetWidth - drawWidth) / 2);
        var top = Math.floor((targetHeight - drawHeight) / 2);
        var canvasBitmap = android.graphics.Bitmap.createBitmap(targetWidth, targetHeight, android.graphics.Bitmap.Config.ARGB_8888);
        var canvas = new android.graphics.Canvas(canvasBitmap);
        canvas.drawColor(android.graphics.Color.TRANSPARENT);
        var paint = new android.graphics.Paint(3);
        canvas.drawBitmap(source, null, new android.graphics.Rect(left, top, left + drawWidth, top + drawHeight), paint);
        var encoded = new java.io.ByteArrayOutputStream();
        canvasBitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, encoded);
        try { source.recycle(); } catch (ignoreLiveSourceRecycleError) {}
        try { canvasBitmap.recycle(); } catch (ignoreLiveCanvasRecycleError) {}
        return new java.io.ByteArrayInputStream(encoded.toByteArray());
    });
}

function readSources() {
    try {
        var value = JSON.parse(String(readFile(core.LIVE_INDEX_PATH) || "[]"));
        return Array.isArray(value) ? value : [];
    } catch (ignoreLiveReadError) { return []; }
}

function saveSources(sources) {
    writeFile(core.LIVE_INDEX_PATH, JSON.stringify(sources || [], null, 2));
}

function sourceId(url, name) {
    return "live_" + md5(String(url || name || Date.now())).slice(0, 16);
}

setPageTitle("直播");
var sources = readSources();
var currentId = String(getMyVar(currentKey, "") || "");
var current = sources.find(function(source) { return String(source.id) === currentId; }) || sources[0] || null;
if (current && currentId !== String(current.id)) {
    currentId = String(current.id);
    putMyVar(currentKey, currentId);
}

if (current && page === 1 && current.url && Number(current.parserVersion || 0) < LIVE_PARSER_VERSION) {
    try {
        var migrated = parser.parseRemoteResult(current.url, 1);
        current.channels = migrated.channels;
        current.pageInfo = migrated.pageInfo;
        current.parserVersion = LIVE_PARSER_VERSION;
        current.updatedAt = Date.now();
        saveSources(sources);
    } catch (ignoreLiveSourceMigrationError) {}
}

if (page > 1 && typeof toast === "function") {
    try { toast("正在加载下一页"); } catch (ignoreLiveLoadingToastError) {}
}

if (page === 1) {
items.push({
    title: "添加",
    pic_url: getPath(core.DATA_ROOT + "/assets/import_v116.png"),
    col_type: "icon_small_4",
    url: $("", "📝 格式：名称||URL||UA\n示例：测试||http://ge.html-5.me//ii/4gTV.txt||aptv1.3").input(function(parserLoaderSource, coreLoaderSource, path) {
        var rawInput = String(input || "").trim();
        if (!rawInput) return "toast://请输入直播源 URL";
        // 支持 "名称||URL||UA" 完整格式，也兼容纯 URL
        var name = "";
        var url = rawInput;
        var ua = "";
        if (rawInput.indexOf("||") >= 0) {
            var segments = rawInput.split("||").map(function(part) { return String(part || "").trim(); });
            name = segments[0] || "";
            url = segments[1] || "";
            ua = segments[2] || "";
        }
        if (!url) return "toast://请输入直播源 URL";
        try {
            showLoading("正在解析直播源...");
            var parser = eval(parserLoaderSource)(["parseRemoteResult"]);
            if (!name) name = String(url).replace(/^https?:\/\//i, "").split("/")[0] || "直播源";
            var core = eval(coreLoaderSource)(["getLiveIndexPath"]);
            var liveIndexPath = core.getLiveIndexPath();
            var sources = [];
            try { sources = JSON.parse(String(readFile(liveIndexPath) || "[]")); } catch (ignoreReadError) {}
            if (!Array.isArray(sources)) sources = [];
            var id = "live_" + md5(url).slice(0, 16);
            var parsed = parser.parseRemoteResult(url, 1);
            var item = {id: id, name: name, url: url, channels: parsed.channels, pageInfo: parsed.pageInfo, parserVersion: 2, updatedAt: Date.now()};
            if (ua) item.ua = ua;
            var old = sources.findIndex(function(source) { return String(source.id) === id; });
            if (old >= 0) sources[old] = item;
            else sources.push(item);
            writeFile(liveIndexPath, JSON.stringify(sources, null, 2));
            putMyVar("py_live_current", id);
            refreshPage(true);
            return "toast://已添加 " + parsed.channels.length + " 个频道";
        } catch (error) {
            return "toast://直播源导入失败：" + (error && error.toString ? error.toString() : String(error));
        } finally {
            try { hideLoading(); } catch (ignoreHideLoadingError) {}
        }
    }, callbackLiveParserLoader, callbackCoreLoader, current && current.url || ""),
    extra: {lineVisible: false}
});
items.push({
    title: "刷新",
    pic_url: getPath(core.DATA_ROOT + "/assets/reload_v116.png"),
    col_type: "icon_small_4",
    url: $("#noLoading#").lazyRule(function(currentId, parserLoaderSource, coreLoaderSource) {
        var core = eval(coreLoaderSource)(["getLiveIndexPath"]);
        var liveIndexPath = core.getLiveIndexPath();
        var parser = eval(parserLoaderSource)(["parseRemoteResult"]);
        var sources = [];
        try { sources = JSON.parse(String(readFile(liveIndexPath) || "[]")); } catch (ignoreReadError) {}
        var source = sources.find(function(item) { return String(item.id) === String(currentId); });
        if (!source || !source.url) return "toast://当前线路没有远程地址";
        try {
            showLoading("正在刷新直播线路...");
            var parsed = parser.parseRemoteResult(source.url, 1);
            source.channels = parsed.channels;
            source.pageInfo = parsed.pageInfo;
            source.parserVersion = 2;
            source.updatedAt = Date.now();
            writeFile(liveIndexPath, JSON.stringify(sources, null, 2));
            refreshPage(true);
            return "toast://已刷新 " + source.channels.length + " 个频道";
        } catch (error) {
            return "toast://刷新失败：" + (error && error.toString ? error.toString() : String(error));
        } finally {
            try { hideLoading(); } catch (ignoreHideLoadingError) {}
        }
    }, currentId, callbackLiveParserLoader, callbackCoreLoader),
    extra: {lineVisible: false}
});
items.push({
    title: "管理",
    pic_url: getPath(core.DATA_ROOT + "/assets/video_source_v116.png"),
    col_type: "icon_small_4",
    url: "hiker://page/py_live_manager_v1844#noRecordHistory##noHistory#",
    extra: {lineVisible: false}
});
items.push({
    title: "配置",
    pic_url: getPath(core.DATA_ROOT + "/assets/settings_v116.png"),
    col_type: "icon_small_4",
    url: "hiker://page/py_config_import_v1844#noRecordHistory##noHistory#",
    extra: {lineVisible: false}
});

sources.forEach(function(source) {
    var selected = current && String(source.id) === String(current.id);
    items.push({
        title: (selected ? "➡️ " : "") + String(source.name || "直播线路"),
        col_type: "scroll_button",
        url: $("#noLoading#").lazyRule(function(key, id, groupKey) {
            putMyVar(key, id);
            putMyVar(groupKey, "");
            refreshPage(false);
            return "hiker://empty";
        }, currentKey, source.id, groupKey),
        extra: selected ? {backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false} : {lineVisible: false}
    });
});
}

if (current && page === 1) {
    var channels = Array.isArray(current.channels) ? current.channels : [];
    var groups = [];
    channels.forEach(function(channel) {
        var name = String(channel.group || "默认分组");
        if (groups.indexOf(name) < 0) groups.push(name);
    });
    var selectedGroup = String(getMyVar(groupKey, "") || "");
    if (selectedGroup && groups.indexOf(selectedGroup) < 0) selectedGroup = "";
    // 直播源按钮与分组按钮之间插入独立标题，避免被海阔合并成同一横向行；
    // 连续的分组 scroll_button 会由原生组件自动折叠到右侧展开入口。
    items.push({
        title: "分组分类",
        col_type: "text_1",
        extra: {lineVisible: false}
    });
    items.push({
        title: "全部",
        col_type: "scroll_button",
        url: $("#noLoading#").lazyRule(function(key) { putMyVar(key, ""); refreshPage(false); return "hiker://empty"; }, groupKey),
        extra: !selectedGroup ? {backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false} : {lineVisible: false}
    });
    groups.forEach(function(group) {
        var selected = group === selectedGroup;
        items.push({
            title: group,
            col_type: "scroll_button",
            url: $("#noLoading#").lazyRule(function(key, value) { putMyVar(key, value); refreshPage(false); return "hiker://empty"; }, groupKey, group),
            extra: selected ? {backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false} : {lineVisible: false}
        });
    });
    items.push({
        title: "搜索",
        desc: "频道关键字",
        col_type: "input",
        url: $.toString(function(key) { putMyVar(key, input); refreshPage(false); }, searchKey),
        extra: {defaultValue: String(getMyVar(searchKey, "") || ""), titleVisible: true, lineVisible: false}
    });
    var keyword = String(getMyVar(searchKey, "") || "").trim().toLowerCase();
    channels.filter(function(channel) {
        if (selectedGroup && String(channel.group || "默认分组") !== selectedGroup) return false;
        return !keyword || [channel.name, channel.group, channel.url].join(" ").toLowerCase().indexOf(keyword) >= 0;
    }).forEach(function(channel) {
        var image = "";
        if (channel.pic) {
            try { image = core.imageUrl(String(current.id), channel.pic, current.url); } catch (ignoreLiveImageError) { image = String(channel.pic); }
        }
        image = fitLiveCover(image);
        items.push({
            title: String(channel.name || "直播频道"),
            desc: String(channel.group || "默认分组"),
            pic_url: image,
            img: image,
            col_type: image ? "movie_2" : "text_3",
            url: String(channel.url || "") + "#isVideo=true#",
            extra: {lineVisible: false, longClick: [{title: "复制地址", js: $.toString(function(url) { return "copy://" + url; }, String(channel.url || ""))}]}
        });
    });
}

if (current && page > 1) {
    var pageChannels = [];
    var livePageError = "";
    try {
        var pageCount = Number(current.pageInfo && current.pageInfo.pageCount || 0);
        // 单页源（pageCount<=0，如 txt 全量接口）：不触发第二页请求，避免底部空白追加。
        pageChannels = pageCount <= 0 ? [] : (page > pageCount ? [] : (parser.parseRemotePage(current.url, page) || []));
        var known = {};
        (Array.isArray(current.channels) ? current.channels : []).forEach(function(channel) {
            known[String(channel.url || channel.name || "")] = true;
        });
        var freshChannels = pageChannels.filter(function(channel) {
            var key = String(channel.url || channel.name || "");
            return key && !known[key];
        });
        pageChannels = freshChannels;
    } catch (error) {
        pageChannels = [];
        livePageError = error && error.toString ? error.toString() : String(error);
    }
    if (livePageError && typeof toast === "function") {
        try { toast("第 " + page + " 页加载失败（超时或源失效）：" + livePageError.slice(0, 120)); } catch (ignoreLivePageErrorToast) {}
    }
    pageChannels.forEach(function(channel) {
        var image = "";
        if (channel.pic) {
            try { image = core.imageUrl(String(current.id), channel.pic, current.url); } catch (ignoreNextLiveImageError) { image = String(channel.pic); }
        }
        image = fitLiveCover(image);
        items.push({
            title: String(channel.name || "直播频道"),
            desc: String(channel.group || "默认分组"),
            pic_url: image,
            img: image,
            col_type: image ? "movie_2" : "text_3",
            url: String(channel.url || "") + "#isVideo=true#",
            extra: {lineVisible: false, longClick: [{title: "复制地址", js: $.toString(function(url) { return "copy://" + url; }, String(channel.url || ""))}]}
        });
    });
    if (!pageChannels.length && typeof toast === "function") {
        try { toast("到底了"); } catch (ignoreLiveEndToastError) {}
    }
}

if (!sources.length && page === 1) {
    items.push({title: "暂无直播线路", col_type: "text_center_1", url: "hiker://empty"});
}

setResult(items);
