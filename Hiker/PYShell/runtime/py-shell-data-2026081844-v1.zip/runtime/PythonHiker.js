var BUILD_VERSION = "2026081844";
var runtimeTitle = (typeof MY_RULE !== "undefined" && MY_RULE && MY_RULE.title) ? MY_RULE.title : "PY影视壳";
var mpath = "hiker://files/data/" + runtimeTitle + "/runtime";
var MIN_ANDROID_SDK = 25;
var NATIVE_BUNDLE_VERSION = "chaquopy-python38-arm64-api25-v1";
var NATIVE_BUNDLE_SHA256 = "8c593da639d642a594ba16b1a8a37f1ef62ca5d8a0a6c4d7210899920a9d0d53";
var NATIVE_BUNDLE_SIZE = 16438757;
var NATIVE_RUNTIME_HOME = "hiker://files/data/PYShellRuntime";
var NATIVE_BUNDLE_URLS = [
    "https://gh-proxy.org/https://raw.githubusercontent.com/xiaoxiaoxia136/master/main/Hiker/PYShell/runtime/chaquopy-python38-arm64-api25-v1.zip",
    "https://gh-proxy.com/https://raw.githubusercontent.com/xiaoxiaoxia136/master/main/Hiker/PYShell/runtime/chaquopy-python38-arm64-api25-v1.zip",
    "https://raw.githubusercontent.com/xiaoxiaoxia136/master/main/Hiker/PYShell/runtime/chaquopy-python38-arm64-api25-v1.zip",
    "https://cdn.jsdelivr.net/gh/xiaoxiaoxia136/master@main/Hiker/PYShell/runtime/chaquopy-python38-arm64-api25-v1.zip"
];
var NATIVE_FILES = [
    {path: "chaquopy.apk", size: 13654057, sha256: "42922e3506604057b890b72b216a719eecd786e78ce0c593fd4cc02c91856226"},
    {path: "classes.dex", size: 35272, sha256: "5d054664b3ec9b44b841afbd6392d03656ac2132e6d31ecd885261ec0c436053"},
    {path: "arm64-v8a/libchaquopy_java.so", size: 159824, sha256: "92e9c1f2841e10053055001b886c4ebd7580e2a6aa9dfb2356f2e988091d5940"},
    {path: "arm64-v8a/libcrypto_chaquopy.so", size: 3688, sha256: "fe59dede7bb351e2434b3bb1fd9919369cbdd2319789c014bc1196553c49203b"},
    {path: "arm64-v8a/libcrypto_python.so", size: 2355168, sha256: "cf0f9e1b740c069f0e9bf54bb3f9f01c651cd26cb74117f934265ab81a9133fa"},
    {path: "arm64-v8a/libpython3.8.so", size: 3255616, sha256: "deade80a987c4f178d66f85e30d3da6cb4bf186ec52ef82ac47e44bf2cc50bd2"},
    {path: "arm64-v8a/libsqlite3_chaquopy.so", size: 3688, sha256: "97aa5e152385e1d60e81c85d321a869df08a6179d308cb92c33f1906eeb9bb6f"},
    {path: "arm64-v8a/libsqlite3_python.so", size: 1178920, sha256: "fa355dda67c86b62f67026b7b5a8ec17732ee30e9e8280b86362b4e2a886548b"},
    {path: "arm64-v8a/libssl_chaquopy.so", size: 3688, sha256: "4479c6c88ed634593fc1cae9c015cae7d8ef61b3b7e90143bfbb501ce3292a3f"},
    {path: "arm64-v8a/libssl_python.so", size: 549488, sha256: "5809bf914caa387c23b132a2a71e2edab0b2afd2fb92cae454a1a3ae296c6040"}
];
var loadedSourceModules = {};
var runtimeObjectCaches = {
    spider: {},
    dependency: {}
};
var sourceCacheStats = {hits: 0, misses: 0, rebuilt: 0, lastHit: false, lastModuleId: ""};

function stringStartsWith(value, prefix) {
    value = String(value || "");
    prefix = String(prefix || "");
    return value.slice(0, prefix.length) === prefix;
}

function stringEndsWith(value, suffix) {
    value = String(value || "");
    suffix = String(suffix || "");
    return suffix === "" || value.slice(-suffix.length) === suffix;
}

function androidRuntimeEnvironment() {
    var sdk = 0;
    var abis = [];
    try { sdk = Number(android.os.Build.VERSION.SDK_INT || 0); } catch (ignoreSdkError) {}
    try {
        var supported = android.os.Build.SUPPORTED_ABIS;
        for (var index = 0; supported && index < supported.length; index++) {
            abis.push(String(supported[index] || ""));
        }
    } catch (ignoreSupportedAbisError) {}
    if (!abis.length) {
        try { abis.push(String(android.os.Build.CPU_ABI || "")); } catch (ignoreCpuAbiError) {}
    }
    return {sdk: sdk, abis: abis};
}

function selectRuntimeAbi(environment, nativeRoot) {
    if (environment.sdk && environment.sdk < MIN_ANDROID_SDK) {
        throw new Error("PY 运行时最低支持 Android 7.1（API 25），当前 API " + environment.sdk);
    }
    var candidates = ["arm64-v8a"];
    for (var abiIndex = 0; abiIndex < environment.abis.length; abiIndex++) {
        var abi = String(environment.abis[abiIndex] || "");
        if (candidates.indexOf(abi) < 0) candidates.push(abi);
    }
    for (var candidateIndex = 0; candidateIndex < candidates.length; candidateIndex++) {
        var candidate = candidates[candidateIndex];
        if (environment.abis.indexOf(candidate) < 0) continue;
        var path = String(nativeRoot || "").replace(/\/$/, "") + "/" + candidate;
        try {
            if (new java.io.File(path).isDirectory()) return {abi: candidate, path: path};
        } catch (ignoreAbiDirectoryError) {}
    }
    throw new Error("PY 运行库仅包含 arm64-v8a；当前设备 ABI: " + environment.abis.join(","));
}

// 代理线程没有完整的规则请求上下文。使用 Java 直接读取已安装的本地
// 运行时文件，避免 request(hiker://files/...) 被误判为规则请求。
function runtimeLocalPath(path) {
    var value = String(path || "");
    var hikerValue = value;
    if (stringStartsWith(value, "hiker://") && typeof getPath === "function") {
        try { value = String(getPath(value)); } catch (ignoreRuntimeGetPathError) {}
    }
    if (stringStartsWith(value, "file://")) value = value.slice(7);
    if (stringStartsWith(hikerValue, "hiker://") && (value === hikerValue || stringStartsWith(value, "hiker://"))) {
        try {
            var activity = typeof getCurrentActivity === "function" ? getCurrentActivity() : null;
            var external = activity && activity.getExternalFilesDir ? activity.getExternalFilesDir(null) : null;
            if (external) {
                var documents = String(external.getAbsolutePath()) + "/Documents";
                value = documents + "/" + hikerValue.slice("hiker://files/".length);
            }
        } catch (ignoreRuntimeExternalPathError) {}
    }
    return value;
}

function readRuntimeText(path) {
    var localPath = runtimeLocalPath(path);
    var input = new java.io.FileInputStream(localPath);
    var output = new java.io.ByteArrayOutputStream();
    var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
    try {
        var length;
        while ((length = input.read(buffer)) !== -1) {
            if (length > 0) output.write(buffer, 0, length);
        }
    } finally {
        input.close();
    }
    return String(new java.lang.String(output.toByteArray(), "UTF-8"));
}

function deleteRuntimeTree(file) {
    if (!file || !file.exists()) return;
    if (file.isDirectory()) {
        var children = file.listFiles();
        for (var index = 0; children && index < children.length; index++) deleteRuntimeTree(children[index]);
    }
    file.delete();
}

function runtimeFileSha256(file) {
    var digest = java.security.MessageDigest.getInstance("SHA-256");
    var input = new java.io.FileInputStream(file);
    var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 32768);
    try {
        var length;
        while ((length = input.read(buffer)) !== -1) {
            if (length > 0) digest.update(buffer, 0, length);
        }
    } finally {
        input.close();
    }
    var bytes = digest.digest();
    var output = "";
    for (var byteIndex = 0; byteIndex < bytes.length; byteIndex++) {
        var hex = (Number(bytes[byteIndex]) & 255).toString(16);
        output += hex.length < 2 ? "0" + hex : hex;
    }
    return output;
}

function nativeRootValid(root, verifyHashes) {
    var directory = new java.io.File(String(root || ""));
    if (!directory.isDirectory()) return false;
    for (var index = 0; index < NATIVE_FILES.length; index++) {
        var expected = NATIVE_FILES[index];
        var file = new java.io.File(directory, expected.path);
        if (!file.isFile() || Number(file.length()) !== Number(expected.size)) return false;
        if (verifyHashes && runtimeFileSha256(file) !== expected.sha256) return false;
    }
    if (!verifyHashes) {
        var marker = new java.io.File(directory, "bundle.ready");
        if (!marker.isFile()) return false;
        try {
            var markerText = readRuntimeText("file://" + marker.getAbsolutePath());
            if (String(markerText).trim() !== NATIVE_BUNDLE_VERSION + "@" + NATIVE_BUNDLE_SHA256) return false;
        } catch (ignoreMarkerReadError) {
            return false;
        }
    }
    return true;
}

function writeRuntimeMarker(directory) {
    var marker = new java.io.File(directory, "bundle.ready");
    var output = new java.io.FileOutputStream(marker, false);
    try {
        output.write(new java.lang.String(NATIVE_BUNDLE_VERSION + "@" + NATIVE_BUNDLE_SHA256).getBytes("UTF-8"));
        output.getFD().sync();
    } finally {
        output.close();
    }
}

function downloadNativeBundle(url, target) {
    var connection = new java.net.URL(String(url)).openConnection();
    connection.setConnectTimeout(10000);
    connection.setReadTimeout(300000);
    connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) PY影视壳/1831");
    connection.setRequestProperty("Accept", "application/zip,application/octet-stream,*/*");
    var input = connection.getInputStream();
    var output = new java.io.FileOutputStream(target, false);
    var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 32768);
    var total = 0;
    try {
        var length;
        while ((length = input.read(buffer)) !== -1) {
            if (length <= 0) continue;
            total += length;
            if (total > 64 * 1024 * 1024) throw new Error("远程运行时文件超过大小上限");
            output.write(buffer, 0, length);
        }
        output.getFD().sync();
    } finally {
        try { input.close(); } catch (ignoreInputCloseError) {}
        output.close();
    }
    if (total !== NATIVE_BUNDLE_SIZE) throw new Error("远程运行时大小校验失败: " + total);
    if (runtimeFileSha256(target) !== NATIVE_BUNDLE_SHA256) throw new Error("远程运行时 SHA-256 校验失败");
}

function extractNativeBundle(bundle, targetDirectory) {
    var canonicalRoot = String(targetDirectory.getCanonicalPath()) + java.io.File.separator;
    var input = new java.util.zip.ZipInputStream(new java.io.BufferedInputStream(new java.io.FileInputStream(bundle)));
    var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 32768);
    try {
        var entry;
        while ((entry = input.getNextEntry()) !== null) {
            var name = String(entry.getName() || "").replace(/\\/g, "/");
            if (!name || name.charAt(0) === "/" || name.indexOf("../") >= 0 || name.indexOf(":") >= 0) {
                throw new Error("远程运行时包含非法路径: " + name);
            }
            var outputFile = new java.io.File(targetDirectory, name);
            if (String(outputFile.getCanonicalPath()).indexOf(canonicalRoot) !== 0) {
                throw new Error("远程运行时路径越界: " + name);
            }
            if (entry.isDirectory()) {
                outputFile.mkdirs();
            } else {
                outputFile.getParentFile().mkdirs();
                var output = new java.io.FileOutputStream(outputFile, false);
                try {
                    var length;
                    while ((length = input.read(buffer)) !== -1) {
                        if (length > 0) output.write(buffer, 0, length);
                    }
                    output.getFD().sync();
                } finally {
                    output.close();
                }
            }
            input.closeEntry();
        }
    } finally {
        input.close();
    }
}

function installNativeRuntime() {
    var home = new java.io.File(runtimeLocalPath(NATIVE_RUNTIME_HOME));
    if (!home.exists()) home.mkdirs();
    var finalDirectory = new java.io.File(home, NATIVE_BUNDLE_VERSION);
    if (nativeRootValid(finalDirectory.getAbsolutePath(), false)) return finalDirectory.getAbsolutePath();

    var lockFile = new java.io.File(home, "install.lock");
    var lockAccess = new java.io.RandomAccessFile(lockFile, "rw");
    var channel = lockAccess.getChannel();
    var lock = null;
    try {
        var waitUntil = Date.now() + 60000;
        while (!lock && Date.now() < waitUntil) {
            try { lock = channel.tryLock(); } catch (ignoreLockBusyError) {}
            if (!lock) {
                if (nativeRootValid(finalDirectory.getAbsolutePath(), false)) return finalDirectory.getAbsolutePath();
                java.lang.Thread.sleep(250);
            }
        }
        if (!lock) throw new Error("另一个页面正在安装 PY 运行时，请稍后重试");
        if (nativeRootValid(finalDirectory.getAbsolutePath(), false)) return finalDirectory.getAbsolutePath();

        if (typeof showLoading === "function") showLoading("首次使用，正在下载 PY 运行时（约16MB）...");
        var errors = [];
        for (var urlIndex = 0; urlIndex < NATIVE_BUNDLE_URLS.length; urlIndex++) {
            var token = String(Date.now()) + "_" + urlIndex;
            var bundle = new java.io.File(home, "." + NATIVE_BUNDLE_VERSION + "." + token + ".zip");
            var staging = new java.io.File(home, "." + NATIVE_BUNDLE_VERSION + "." + token + ".tmp");
            try {
                deleteRuntimeTree(bundle);
                deleteRuntimeTree(staging);
                staging.mkdirs();
                downloadNativeBundle(NATIVE_BUNDLE_URLS[urlIndex], bundle);
                extractNativeBundle(bundle, staging);
                if (!nativeRootValid(staging.getAbsolutePath(), true)) throw new Error("远程运行时逐文件校验失败");
                writeRuntimeMarker(staging);

                var backup = new java.io.File(home, "." + NATIVE_BUNDLE_VERSION + ".backup." + token);
                deleteRuntimeTree(backup);
                if (finalDirectory.exists() && !finalDirectory.renameTo(backup)) throw new Error("旧运行时备份失败");
                if (!staging.renameTo(finalDirectory)) {
                    if (backup.exists()) backup.renameTo(finalDirectory);
                    throw new Error("新运行时原子切换失败");
                }
                deleteRuntimeTree(backup);
                deleteRuntimeTree(bundle);
                if (typeof hideLoading === "function") hideLoading();
                return finalDirectory.getAbsolutePath();
            } catch (installError) {
                errors.push(String(installError && installError.toString ? installError.toString() : installError));
                deleteRuntimeTree(bundle);
                deleteRuntimeTree(staging);
            }
        }

        var legacyRoot = runtimeLocalPath(mpath);
        if (nativeRootValid(legacyRoot, true)) {
            if (typeof hideLoading === "function") hideLoading();
            return legacyRoot;
        }
        throw new Error("PY 运行时下载失败: " + errors.join(" | "));
    } finally {
        if (typeof hideLoading === "function") {
            try { hideLoading(); } catch (ignoreHideRuntimeLoadingError) {}
        }
        if (lock) try { lock.release(); } catch (ignoreLockReleaseError) {}
        try { channel.close(); } catch (ignoreChannelCloseError) {}
        try { lockAccess.close(); } catch (ignoreLockFileCloseError) {}
    }
}

function getMP(name) {
    return mpath + "/" + name;
}

var loadedPythonClass = null;
var PYTHON_LOADER_KEY = "py.shell.classloader." + NATIVE_BUNDLE_VERSION;

function sharedPythonClassLoader() {
    try { return java.lang.System.getProperties().get(PYTHON_LOADER_KEY); } catch (ignoreSharedPythonLoaderError) {}
    return null;
}

function adoptPythonClassLoader(clazz) {
    if (!clazz) return clazz;
    try {
        var loader = clazz.getClassLoader();
        if (loader) {
            java.lang.System.getProperties().put(PYTHON_LOADER_KEY, loader);
            java.lang.Thread.currentThread().setContextClassLoader(loader);
        }
    } catch (ignoreAdoptPythonLoaderError) {}
    return clazz;
}

function loadedJavaClass(name) {
    try {
        return java.lang.Class.forName(String(name));
    } catch (ignoreDefaultClassLoaderError) {}
    try {
        var sharedLoader = sharedPythonClassLoader();
        if (sharedLoader) return java.lang.Class.forName(String(name), true, sharedLoader);
    } catch (ignoreSharedClassLoaderError) {}
    try {
        var loader = java.lang.Thread.currentThread().getContextClassLoader();
        if (loader) return java.lang.Class.forName(String(name), true, loader);
    } catch (ignoreContextClassLoaderError) {}
    // 代理线程没有规则上下文，findJavaClass 会因“获取规则失败”抛错；
    // 通过海阔主 Activity 的类加载器查找 Chaquopy 运行时类（进程内已由主页面加载）。
    try {
        var activityClazz = java.lang.Class.forName("com.example.hikerview.ui.home.MainActivity");
        var activityLoader = activityClazz.getClassLoader();
        if (activityLoader) return java.lang.Class.forName(String(name), true, activityLoader);
    } catch (ignoreActivityLoaderError) {}
    // 最后手段：遍历当前进程所有存活线程的 contextClassLoader 及其父链，
    // 从任意一个能找到目标类（Chaquopy 启动后 com.chaquo.python.Python 一定
    // 在某个类加载器里）。Android 的 ClassLoader 没有 OpenJDK 的 loaders 字段，
    // 不能靠 getDeclaredField("loaders")。
    try {
        var stackTraces = java.lang.Thread.getAllStackTraces();
        var threads = stackTraces.keySet().toArray();
        var seenLoaders = [];
        for (var ti = 0; ti < threads.length; ti++) {
            var scanLoader = null;
            try { scanLoader = threads[ti].getContextClassLoader(); } catch (ignoreThreadLoaderError) {}
            var depth = 0;
            while (scanLoader && depth < 16) {
                if (seenLoaders.indexOf(scanLoader) < 0) {
                    seenLoaders.push(scanLoader);
                    try {
                        return java.lang.Class.forName(String(name), true, scanLoader);
                    } catch (ignoreLoaderScanItem) {}
                }
                try { scanLoader = scanLoader.getParent(); } catch (ignoreLoaderParentError) { scanLoader = null; }
                depth++;
            }
        }
    } catch (ignoreLoaderScanError) {}
    return findJavaClass(String(name));
}

function startedPythonClass() {
    try {
        var clazz = loadedJavaClass("com.chaquo.python.Python");
        if (!clazz) return null;
        var nativePython = new org.mozilla.javascript.NativeJavaClass(this, clazz);
        return nativePython.isStarted() ? adoptPythonClassLoader(clazz) : null;
    } catch (ignoreStartedPythonError) {
        return null;
    }
}

function initPython() {
    var environment = androidRuntimeEnvironment();
    if (environment.sdk && environment.sdk < MIN_ANDROID_SDK) {
        throw new Error("PY 运行时最低支持 Android 7.1（API 25），当前 API " + environment.sdk);
    }
    if (environment.abis.indexOf("arm64-v8a") < 0) {
        throw new Error("PY 运行库仅包含 arm64-v8a；当前设备 ABI: " + environment.abis.join(","));
    }
    // 图片/播放本地代理运行在无当前规则的工作线程。主页面已经启动过
    // Chaquopy 时直接复用进程内类，避免 initChaquopy 再次索取规则上下文。
    loadedPythonClass = startedPythonClass();
    if (loadedPythonClass) return;
    var nativeRoot = installNativeRuntime();
    var selectedAbi = selectRuntimeAbi(environment, nativeRoot);
    // 代理线程没有规则上下文：initChaquopy 若收到 hiker:// 虚拟路径会
    // 因“获取规则失败”抛错。先把运行时文件转成真实路径再初始化。
    var apkPath = String(nativeRoot).replace(/\/$/, "") + "/chaquopy.apk";
    var dexPath = String(nativeRoot).replace(/\/$/, "") + "/classes.dex";
    var abiPath = selectedAbi.path;
    try {
        initChaquopy(apkPath);
    } catch (ignoreInitChaquopyError) {
        // 主页面已初始化过 Chaquopy 时，initChaquopy 可能因重复初始化抛错；
        // 进程内类仍可直接复用。
        loadedPythonClass = startedPythonClass();
        if (loadedPythonClass) return;
        throw ignoreInitChaquopyError;
    }
    findJavaClass(dexPath, 'com.chaquo.python.android.AndroidPlatform', abiPath);
    loadedPythonClass = adoptPythonClassLoader(loadedJavaClass("com.chaquo.python.Python"));
}
initPython();


var File = java.io.File;
var Integer = java.lang.Integer;

var AndroidPlatform = new org.mozilla.javascript.NativeJavaClass(this, loadedJavaClass("com.chaquo.python.android.AndroidPlatform"));
var Python = new org.mozilla.javascript.NativeJavaClass(this, loadedPythonClass || loadedJavaClass("com.chaquo.python.Python"));
var PyObject = new org.mozilla.javascript.NativeJavaClass(this, loadedJavaClass("com.chaquo.python.PyObject"));
var Kwarg = new org.mozilla.javascript.NativeJavaClass(this, loadedJavaClass("com.chaquo.python.Kwarg"));

if (!Python.isStarted()) {
    var androidPlatform = new AndroidPlatform(getCurrentActivity())
    Python.start(androidPlatform);
}

var sys = Python.getInstance().getModule("sys");
var spath = sys.get("path").asList();
var libsPyPath = runtimeLocalPath(getMP("libs_py"));
if (!spath.contains(libsPyPath)) {
    spath.add(spath.size(), PyObject.fromJava(libsPyPath));
}


var py = Python.getInstance();

var machinery = py.getModule("importlib.machinery");




var Builtins = py.getBuiltins();

//构建海阔环境模块
var hkrule = (typeof MY_RULE !== "undefined") && MY_RULE ? MY_RULE : {};
var hiker = py.getModule("base.hiker");
hiker.put("CACHE_NAME", "PY_CACHE");
hiker.put("MY_TITLE", hkrule.title || "");
hiker.put("MY_TICKET", typeof MY_TICKET === "undefined" ? "" : MY_TICKET);
hiker.put("CALLBACK_KEY", typeof CALLBACK_KEY === "undefined" ? "" : CALLBACK_KEY);
hiker.put("my_rule", JSON.stringify(hkrule));

// 海阔覆盖更新小程序时 Android 进程和 Chaquopy 解释器可能继续存活。
// 直接 py.getModule 会拿到旧包缓存，因此每次加载运行时都从当前文件重载
// base.spider 和 app，确保新兼容层即时生效。
var baseSpiderPath = runtimeLocalPath(getMP("libs_py/base/spider.py"));
machinery.callAttr("SourceFileLoader", "base.spider", baseSpiderPath).callAttr("load_module");
var appPath = runtimeLocalPath(getMP("libs_py/app.py"));
var appSource;
try {
    appSource = readRuntimeText(getMP("libs_py/app.py"));
} catch (readRuntimeTextError) {
    // 普通页面上下文仍可使用 readFile；此回退不触碰 hiker:// request。
    appSource = String(readFile(getMP("libs_py/app.py")) || "");
}
var appModuleName = "hiker_runtime_app_" + md5(appSource).slice(0, 12);
var NativePyApp = machinery.callAttr("SourceFileLoader", appModuleName, appPath).callAttr("load_module");


function evalCode() {
    var args = Array.prototype.slice.call(arguments);
    return NativePyApp.callAttr("call_global_function", ["eval"].concat(args));
}

function execCode() {
    var args = Array.prototype.slice.call(arguments);
    return NativePyApp.callAttr("call_global_function", ["exec"].concat(args));
}

function wrapperJsFunc(func) {
    return NativePyApp.callAttr("wrapper_jsfunc", [func]);
}

function wrapperPyFunc(pyObject) {
    return function() {
        var arr = Array.prototype.slice.call(arguments);
        arr = arr.map(function(v) { return fromJs(v); });
        return pyToJs(pyObject.call(arr));
    }
}

function callFunc(pyObject, name) {
    var arr = Array.prototype.slice.call(arguments, 2);
    arr = arr.map(function(v) { return fromJs(v); });
    return pyToJs(pyObject.callAttr(name, arr));
}

function callFuncCompatible(pyObject, names, candidates) {
    return pyToJs(NativePyApp.callAttr("call_compatible", [
        pyObject,
        fromJs(names || []),
        fromJs(candidates || [])
    ]));
}

function instantiateSpider(module) {
    return NativePyApp.callAttr("instantiate_spider", [module]);
}

function inspectSourceFile(path) {
    path = String(path || "");
    if (stringStartsWith(path, "hiker://")) {
        path = getPath(path).slice(7);
    } else if (stringStartsWith(path, "file://")) {
        path = path.slice(7);
    }
    return pyToJs(NativePyApp.callAttr("inspect_source_file", [path]));
}

function syncAndroidProxy() {
    try {
        return pyToJs(NativePyApp.callAttr("sync_android_proxy"));
    } catch (error) {
        return {enabled: false, proxy: "", source: "", error: String(error)};
    }
}

function callSyncFunc(pyObject, name){
    var arr = Array.prototype.slice.call(arguments, 2);
    arr = fromJs(arr);
    return pyToJs(NativePyApp.callAttr("sync_wrapper",[pyObject.get(name), arr]));
}

function pyToJs(pyObject) {
    if (pyObject == null) {
        return null;
    }
    var type = String(pyObject.type().toString()).replace("<class '", "").replace("'>", "");
    //log(type)
    if (type === "list" || type === "tuple" || type === "set") {
        if (type === "set") {
            pyObject = Builtins.callAttr("list", [pyObject]);
        }
        var arr = [];
        var list = pyObject.asList();
        var size = list.size();

        for (var i = 0; i < size; i++) {
            arr.push(pyToJs(list.get(i)));
        }
        return arr;
    } else if (type === "int" || type === "float") {
        return Number(pyObject.toDouble());
    } else if (type === "bool") {
        return Boolean(pyObject.toBoolean());
    } else if (type === "dict") {
        var obj = {};
        var dictIterator = pyObject.asMap().entrySet().iterator();
        while (dictIterator.hasNext()) {
            var item = dictIterator.next();
            obj[String(item.getKey().toString())] = pyToJs(item.getValue());
        }
        return obj;
    } else if (type === "str") {
        return String(pyObject.toString());
    } else if (type === "function") {
        return wrapperPyFunc(pyObject);
    } else if(type === "bytes" || type === "bytearray" || type === "memoryview"){
        if (type !== "bytes") pyObject = Builtins.callAttr("bytes", [pyObject]);
        return pyObject.toJava(java.lang.Class.forName("[B"));
    } else {
        try {
            var clazz = java.lang.Class.forName(type, javaLoader);
            if (clazz !== null) {
                return pyObject.toJava(clazz);
            }
        } catch (e) {

        }
    }
    return pyObject;
}

function toJson(pyObj) {
    return JSON.parse(NativePyApp.callAttr("json_stringify", [pyObj]).toString());
}

function toPyJson(json) {
    return NativePyApp.callAttr("json_parse", [JSON.stringify(json)]);
}
var sourceCachePath = runtimeLocalPath("hiker://files/_cache/py/source_compat/");
var downloadCachePath = runtimeLocalPath("hiker://files/_cache/py/downloads/");
try { new File(sourceCachePath).mkdirs(); } catch (ignoreSourceCacheMkdirError) {}
try { new File(downloadCachePath).mkdirs(); } catch (ignoreDownloadCacheMkdirError) {}

function modulePrefix(value) {
    var prefix = String(value || "hiker_py").replace(/[^a-zA-Z0-9_]/g, "_");
    return prefix || "hiker_py";
}

function prepareCachedSource(sourcePath) {
    return pyToJs(NativePyApp.callAttr("prepare_source_cache", [
        runtimeLocalPath(sourcePath),
        sourceCachePath,
        64,
        16 * 1024 * 1024
    ]));
}

function unloadModuleId(moduleId) {
    if (!moduleId) return;
    try { NativePyApp.callAttr("unload_python_module", [String(moduleId), false]); } catch (ignoreUnloadModuleError) {}
}

function unloadPy(name, recursive) {
    var prefix = modulePrefix(name);
    var removed = 0;
    for (var logicalName in loadedSourceModules) {
        if (!Object.prototype.hasOwnProperty.call(loadedSourceModules, logicalName)) continue;
        if (logicalName !== prefix && !(recursive && stringStartsWith(logicalName, prefix + "_"))) continue;
        unloadModuleId(loadedSourceModules[logicalName]);
        delete loadedSourceModules[logicalName];
        removed++;
    }
    return removed;
}

function clearPyModules() {
    var removed = 0;
    for (var logicalName in loadedSourceModules) {
        if (!Object.prototype.hasOwnProperty.call(loadedSourceModules, logicalName)) continue;
        unloadModuleId(loadedSourceModules[logicalName]);
        delete loadedSourceModules[logicalName];
        removed++;
    }
    clearRuntimeObjects("");
    return removed;
}

function getRuntimeObject(kind, key) {
    var bucket = runtimeObjectCaches[String(kind || "")];
    if (!bucket) return null;
    var cacheKey = String(key || "");
    return Object.prototype.hasOwnProperty.call(bucket, cacheKey) ? bucket[cacheKey] : null;
}

function putRuntimeObject(kind, key, value) {
    var bucketName = String(kind || "");
    if (!runtimeObjectCaches[bucketName]) runtimeObjectCaches[bucketName] = {};
    runtimeObjectCaches[bucketName][String(key || "")] = value;
    return value;
}

function clearRuntimeObjects(prefix) {
    var normalized = String(prefix || "");
    var removed = 0;
    Object.keys(runtimeObjectCaches).forEach(function(kind) {
        var bucket = runtimeObjectCaches[kind] || {};
        Object.keys(bucket).forEach(function(key) {
            if (normalized && !stringStartsWith(String(key), normalized)) return;
            delete bucket[key];
            removed++;
        });
    });
    return removed;
}

function recordSourceCache(report, moduleId) {
    if (report && report.hit) sourceCacheStats.hits++;
    else sourceCacheStats.misses++;
    if (report && report.rebuilt) sourceCacheStats.rebuilt++;
    sourceCacheStats.lastHit = !!(report && report.hit);
    sourceCacheStats.lastModuleId = String(moduleId || "");
}

function getSourceCacheStats() {
    return {
        hits: sourceCacheStats.hits,
        misses: sourceCacheStats.misses,
        rebuilt: sourceCacheStats.rebuilt,
        lastHit: sourceCacheStats.lastHit,
        lastModuleId: sourceCacheStats.lastModuleId
    };
}

function runPy(path, mname, nocache) {
    path = String(path || "");
    if (stringStartsWith(path, "hiker://")) {
        path = runtimeLocalPath(path);
    } else if (stringStartsWith(path, "file://")) {
        path = path.slice(7);
    }
    var name = "";
    var sourcePath = "";
    if (stringStartsWith(path, "http")) {
        if (stringEndsWith(path, ".py")) {
            name = path.split("/").pop().split(".")[0];
        } else {
            name = md5(path);
        }
        sourcePath = downloadCachePath + md5(path) + ".py";
        if(nocache){
           downloadFile(path, sourcePath);
        }else {
           requireDownload(path, sourcePath);
        }
    } else {
        var pa = path.split("/");
        name = pa.pop().split(".")[0];
        sourcePath = path;
    }
    var logicalName = modulePrefix(mname || ("hiker_" + BUILD_VERSION + "_" + name));
    var report = prepareCachedSource(sourcePath);
    var moduleId = logicalName + "_" + String(report.cacheKey || report.sourceHash || "");
    recordSourceCache(report, moduleId);
    if (loadedSourceModules[logicalName] && loadedSourceModules[logicalName] !== moduleId) {
        unloadModuleId(loadedSourceModules[logicalName]);
    }
    try {
        var module = machinery.callAttr("SourceFileLoader", moduleId, report.path).callAttr("load_module");
        loadedSourceModules[logicalName] = moduleId;
        return module;
    } catch (firstLoadError) {
        unloadModuleId(moduleId);
        try { NativePyApp.callAttr("invalidate_source_cache", [report.path]); } catch (ignoreInvalidateError) {}
        report = prepareCachedSource(sourcePath);
        moduleId = logicalName + "_" + String(report.cacheKey || report.sourceHash || "");
        recordSourceCache(report, moduleId);
        var repairedModule = machinery.callAttr("SourceFileLoader", moduleId, report.path).callAttr("load_module");
        loadedSourceModules[logicalName] = moduleId;
        return repairedModule;
    }
}

function fromJs(obj) {
    var type = Object.prototype.toString.call(obj)
    if ("[object Array]" === type) {

        var list = Builtins.callAttr("list");
        for (var arrayIndex = 0; arrayIndex < obj.length; arrayIndex++) {
            list.callAttr("append", fromJs(obj[arrayIndex]));
        }
        return PyObject.fromJava(list);
    } else if ("[object Object]" === type) {
        var dict = Builtins.callAttr("dict");
        for (var key in obj) {
            if (Object.prototype.hasOwnProperty.call(obj, key)) {
                dict.callAttr("update", Kwarg(String(key), fromJs(obj[key])));
            }
        }
        return dict;
    } else if ("[object Undefined]" === type || "[object Null]" === type) {
        return null;
    } else if ("[object Function]" === type) {
        return wrapperJsFunc(obj);
    } else if ("[object Date]" === type) {
        return obj.getTime();
    } else if ("[object Set]" === type) {
        var set = Builtins.callAttr("set");
        obj.forEach(function(value) { set.callAttr("add", fromJs(value)); });
        return set;
    } else if ("[object Map]" === type) {
        var dict = Builtins.callAttr("dict");
        obj.forEach(function(value, key) {
            dict.callAttr("update", Kwarg(String(key), fromJs(value)));
        });
        return dict;
    }
    /* else if("[object Number]"===type&&isInteger(obj)){
            return new Integer(obj);
        }*/
    return obj;
    //return PyObject.fromJava(obj);
}

function isInteger(obj) {
    return ~~obj == obj
}

function toInt(num) {
    return new Integer(num);
}
Builtins.put("print", hiker.get("log"));
$.exports = {
    BUILD_VERSION: BUILD_VERSION,
    __buildVersion: BUILD_VERSION,
    PyObject: PyObject,
    callSyncFunc: callSyncFunc,
    callFuncCompatible: callFuncCompatible,
    instantiateSpider: instantiateSpider,
    inspectSourceFile: inspectSourceFile,
    syncAndroidProxy: syncAndroidProxy,
    runtimeEnvironment: androidRuntimeEnvironment,
    unloadPy: unloadPy,
    clearPyModules: clearPyModules,
    getRuntimeObject: getRuntimeObject,
    putRuntimeObject: putRuntimeObject,
    clearRuntimeObjects: clearRuntimeObjects,
    getSourceCacheStats: getSourceCacheStats,
    Kwarg: Kwarg,
    callFunc: callFunc,
    evalCode: evalCode,
    execCode: execCode,
    runPy: runPy,
    toJson: toJson,
    toPyJson: toPyJson,
    Builtins: Builtins,
    wrapperJsFunc: wrapperJsFunc,
    pyToJs: pyToJs,
    fromJs: fromJs,
    toInt: toInt
}
