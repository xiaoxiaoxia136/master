import ast
import hashlib
import json
import os
import tempfile
import time
from contextlib import contextmanager


# Bump this value whenever the source transformation changes. The processed
# cache key deliberately does not include the app build, so unchanged PY source
# can be reused after an app process restart or a shell package update.
SOURCE_COMPAT_VERSION = "re_split_flags_kw_v1"
SOURCE_CACHE_SCHEMA = 1
DEFAULT_CACHE_MAX_ENTRIES = 64
DEFAULT_CACHE_MAX_BYTES = 16 * 1024 * 1024
_CACHE_PREFIX = "compat_"

_RE_FLAG_NAMES = {
    "A", "ASCII", "DEBUG", "I", "IGNORECASE", "L", "LOCALE",
    "M", "MULTILINE", "S", "DOTALL", "U", "UNICODE", "X", "VERBOSE",
}


def _is_re_flag(node):
    if isinstance(node, ast.Attribute):
        return (
            isinstance(node.value, ast.Name)
            and node.value.id == "re"
            and node.attr in _RE_FLAG_NAMES
        )
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitOr):
        return _is_re_flag(node.left) and _is_re_flag(node.right)
    return False


def _is_re_split(node):
    return (
        isinstance(node, ast.Attribute)
        and isinstance(node.value, ast.Name)
        and node.value.id == "re"
        and node.attr == "split"
    )


def _patch_source_text(source, filename):
    tree = ast.parse(source, filename=filename)
    lines = source.splitlines(True)
    line_offsets = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    insertions = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not _is_re_split(node.func):
            continue
        if len(node.args) < 3 or any(keyword.arg == "flags" for keyword in node.keywords):
            continue
        third = node.args[2]
        if not _is_re_flag(third):
            continue
        # CPython AST column offsets are UTF-8 byte offsets, while Python string
        # slices use Unicode character offsets.
        current_line = lines[third.lineno - 1]
        prefix = current_line.encode("utf-8")[:third.col_offset].decode("utf-8")
        start = line_offsets[third.lineno - 1] + len(prefix)
        insertions.append(start)

    unique_insertions = sorted(set(insertions), reverse=True)
    for start in unique_insertions:
        source = source[:start] + "flags=" + source[start:]
    return source, len(unique_insertions)


def _atomic_write_bytes(path, content):
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    descriptor, temporary_path = tempfile.mkstemp(
        prefix=".%s." % os.path.basename(path), suffix=".tmp", dir=directory
    )
    try:
        with os.fdopen(descriptor, "wb") as output_file:
            output_file.write(content)
            output_file.flush()
            os.fsync(output_file.fileno())
        os.replace(temporary_path, path)
    except Exception:
        try:
            os.unlink(temporary_path)
        except OSError:
            pass
        raise


def _sha256(content):
    return hashlib.sha256(content).hexdigest()


def _source_cache_key(source_bytes):
    digest = hashlib.sha256()
    digest.update(SOURCE_COMPAT_VERSION.encode("ascii"))
    digest.update(b"\0")
    digest.update(source_bytes)
    return digest.hexdigest()


def _cache_paths(cache_dir, cache_key):
    stem = os.path.join(os.path.abspath(cache_dir), _CACHE_PREFIX + cache_key)
    return stem + ".py", stem + ".meta.json"


def _read_valid_cache(cache_path, metadata_path, source_hash, cache_key):
    try:
        with open(metadata_path, "r", encoding="utf-8") as metadata_file:
            metadata = json.load(metadata_file)
        if not isinstance(metadata, dict):
            return None
        if metadata.get("schema") != SOURCE_CACHE_SCHEMA:
            return None
        if metadata.get("compatVersion") != SOURCE_COMPAT_VERSION:
            return None
        if metadata.get("sourceHash") != source_hash:
            return None
        if metadata.get("cacheKey") != cache_key:
            return None
        with open(cache_path, "rb") as cache_file:
            processed_bytes = cache_file.read()
        if len(processed_bytes) != metadata.get("size"):
            return None
        if _sha256(processed_bytes) != metadata.get("processedHash"):
            return None
        return metadata
    except (OSError, ValueError, TypeError):
        return None


def _touch_cache(cache_path, metadata_path):
    now = time.time()
    for path in (cache_path, metadata_path):
        try:
            os.utime(path, (now, now))
        except OSError:
            pass


def _remove_cache_pair(cache_path, metadata_path):
    removed = 0
    removed_bytes = 0
    for path in (cache_path, metadata_path):
        try:
            removed_bytes += os.path.getsize(path)
        except OSError:
            pass
        try:
            os.unlink(path)
            removed += 1
        except OSError:
            pass
    return removed, removed_bytes


@contextmanager
def _cache_key_lock(lock_path, timeout=5.0):
    deadline = time.time() + timeout
    acquired = False
    while not acquired:
        try:
            descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(descriptor)
            acquired = True
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(lock_path) > 30.0:
                    os.unlink(lock_path)
                    continue
            except OSError:
                continue
            if time.time() >= deadline:
                break
            time.sleep(0.05)
    try:
        yield acquired
    finally:
        if acquired:
            try:
                os.unlink(lock_path)
            except OSError:
                pass


def prune_source_cache(
    cache_dir,
    max_entries=DEFAULT_CACHE_MAX_ENTRIES,
    max_bytes=DEFAULT_CACHE_MAX_BYTES,
    keep_path="",
):
    """Remove least-recently-used processed sources within fixed limits."""
    cache_dir = os.path.abspath(cache_dir)
    max_entries = max(1, int(max_entries))
    max_bytes = max(1, int(max_bytes))
    keep_path = os.path.abspath(keep_path) if keep_path else ""
    entries = []
    removed_files = 0
    removed_bytes = 0
    try:
        names = os.listdir(cache_dir)
    except OSError:
        return {"removedEntries": 0, "removedFiles": 0, "removedBytes": 0}

    source_names = {
        name for name in names
        if name.startswith(_CACHE_PREFIX) and name.endswith(".py")
    }
    metadata_names = {
        name for name in names
        if name.startswith(_CACHE_PREFIX) and name.endswith(".meta.json")
    }
    stems = {name[:-3] for name in source_names}
    stems.update(name[:-10] for name in metadata_names)

    for stem in stems:
        cache_path = os.path.join(cache_dir, stem + ".py")
        metadata_path = os.path.join(cache_dir, stem + ".meta.json")
        if not os.path.isfile(cache_path) or not os.path.isfile(metadata_path):
            if os.path.abspath(cache_path) != keep_path:
                count, size = _remove_cache_pair(cache_path, metadata_path)
                removed_files += count
                removed_bytes += size
            continue
        try:
            size = os.path.getsize(cache_path) + os.path.getsize(metadata_path)
            modified = max(os.path.getmtime(cache_path), os.path.getmtime(metadata_path))
        except OSError:
            continue
        entries.append((modified, cache_path, metadata_path, size))

    entries.sort(key=lambda item: item[0])
    total_bytes = sum(item[3] for item in entries)
    removed_entries = 0
    while len(entries) > max_entries or total_bytes > max_bytes:
        removable_index = next(
            (index for index, item in enumerate(entries) if os.path.abspath(item[1]) != keep_path),
            None,
        )
        if removable_index is None:
            break
        _, cache_path, metadata_path, size = entries.pop(removable_index)
        count, actual_size = _remove_cache_pair(cache_path, metadata_path)
        if count:
            removed_entries += 1
            removed_files += count
            removed_bytes += actual_size
        total_bytes -= size

    return {
        "removedEntries": removed_entries,
        "removedFiles": removed_files,
        "removedBytes": removed_bytes,
    }


def invalidate_source_cache(cache_path):
    """Delete one processed source and its metadata without touching its origin."""
    cache_path = os.path.abspath(cache_path)
    name = os.path.basename(cache_path)
    if not name.startswith(_CACHE_PREFIX) or not name.endswith(".py"):
        return {"removed": False, "path": cache_path}
    metadata_path = cache_path[:-3] + ".meta.json"
    count, removed_bytes = _remove_cache_pair(cache_path, metadata_path)
    return {
        "removed": bool(count),
        "removedFiles": count,
        "removedBytes": removed_bytes,
        "path": cache_path,
    }


def prepare_source_cache(
    source_path,
    cache_dir,
    max_entries=DEFAULT_CACHE_MAX_ENTRIES,
    max_bytes=DEFAULT_CACHE_MAX_BYTES,
):
    """Return an immutable, content-addressed compatible copy of a PY source.

    A valid hit checks byte hashes only and deliberately skips AST parsing. The
    original source is always read-only. Cache damage causes the pair to be
    removed and rebuilt under the same key.
    """
    source_path = os.path.abspath(source_path)
    cache_dir = os.path.abspath(cache_dir)
    os.makedirs(cache_dir, exist_ok=True)
    with open(source_path, "rb") as source_file:
        source_bytes = source_file.read()
    source_hash = _sha256(source_bytes)
    cache_key = _source_cache_key(source_bytes)
    cache_path, metadata_path = _cache_paths(cache_dir, cache_key)
    lock_path = cache_path + ".lock"

    metadata = _read_valid_cache(cache_path, metadata_path, source_hash, cache_key)
    if metadata is not None:
        _touch_cache(cache_path, metadata_path)
        return {
            "path": cache_path,
            "sourceHash": source_hash,
            "cacheKey": cache_key,
            "moduleKey": "hiker_py_cache_" + cache_key,
            "compatVersion": SOURCE_COMPAT_VERSION,
            "hit": True,
            "rebuilt": False,
            "changed": bool(metadata.get("changed")),
            "count": int(metadata.get("count", 0)),
            "cleanup": {"removedEntries": 0, "removedFiles": 0, "removedBytes": 0},
        }

    had_invalid_cache = os.path.exists(cache_path) or os.path.exists(metadata_path)
    with _cache_key_lock(lock_path):
        metadata = _read_valid_cache(cache_path, metadata_path, source_hash, cache_key)
        if metadata is not None:
            _touch_cache(cache_path, metadata_path)
            return {
                "path": cache_path,
                "sourceHash": source_hash,
                "cacheKey": cache_key,
                "moduleKey": "hiker_py_cache_" + cache_key,
                "compatVersion": SOURCE_COMPAT_VERSION,
                "hit": True,
                "rebuilt": False,
                "changed": bool(metadata.get("changed")),
                "count": int(metadata.get("count", 0)),
                "cleanup": {"removedEntries": 0, "removedFiles": 0, "removedBytes": 0},
            }

        if os.path.exists(cache_path) or os.path.exists(metadata_path):
            had_invalid_cache = True
            _remove_cache_pair(cache_path, metadata_path)

        source = source_bytes.decode("utf-8-sig")
        processed_source, count = _patch_source_text(source, source_path)
        processed_bytes = processed_source.encode("utf-8")
        metadata = {
            "schema": SOURCE_CACHE_SCHEMA,
            "compatVersion": SOURCE_COMPAT_VERSION,
            "sourceHash": source_hash,
            "cacheKey": cache_key,
            "processedHash": _sha256(processed_bytes),
            "size": len(processed_bytes),
            "changed": bool(count),
            "count": count,
        }
        _atomic_write_bytes(cache_path, processed_bytes)
        _atomic_write_bytes(
            metadata_path,
            json.dumps(metadata, ensure_ascii=True, separators=(",", ":")).encode("utf-8"),
        )

    cleanup = prune_source_cache(cache_dir, max_entries, max_bytes, cache_path)
    return {
        "path": cache_path,
        "sourceHash": source_hash,
        "cacheKey": cache_key,
        "moduleKey": "hiker_py_cache_" + cache_key,
        "compatVersion": SOURCE_COMPAT_VERSION,
        "hit": False,
        "rebuilt": had_invalid_cache,
        "changed": bool(metadata.get("changed")),
        "count": int(metadata.get("count", 0)),
        "cleanup": cleanup,
    }


def patch_source_compat(path):
    """Patch unambiguous legacy PY API mistakes in a runtime cache copy."""
    with open(path, "rb") as source_file:
        source_bytes = source_file.read()
    source = source_bytes.decode("utf-8-sig")
    processed_source, count = _patch_source_text(source, path)
    if not count:
        return {"changed": False, "count": 0, "path": path}
    _atomic_write_bytes(path, processed_source.encode("utf-8"))
    return {"changed": True, "count": count, "path": path}
