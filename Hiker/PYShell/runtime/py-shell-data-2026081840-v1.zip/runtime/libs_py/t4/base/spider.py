# -*- coding: utf-8 -*-
"""影视仓 T4 模板的 base.spider 兼容：``from t4.base.spider import Spider``。

Spider 从 t4 包惰性导出（base.spider 顶层依赖海阔 Java 环境），
保证 ``import t4.base.spider`` 本身不触发 Java 加载。
"""
import os as _os
import sys as _sys

_base_dir = _os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
if _base_dir not in _sys.path:
    _sys.path.insert(0, _base_dir)

from t4 import Spider, BaseSpider  # noqa: F401,E402  (惰性 __getattr__)
