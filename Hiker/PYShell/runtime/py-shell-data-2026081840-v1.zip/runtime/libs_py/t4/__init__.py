# -*- coding: utf-8 -*-
"""影视仓（TVBox 影视仓/T4 环境）PY 源兼容层。

影视壳上许多 PY 源按影视仓 T4 模板编写：``from t4 import *`` 或
``from t4.base.spider import Spider``。本壳以海阔 T3 环境运行，这里提供
T4 常用接口的轻量映射，使这类源导入后无需改写即可加载。

设计约束：base.spider 顶层 import base.hiker（海阔 Java 环境），因此在
非海阔环境（如本地静态检查）导入 base.spider 会失败。本模块所有可能
触发该依赖的符号（Spider 等）都通过模块级 __getattr__ 惰性提供：
``import t4`` / ``from t4 import json`` 等不触碰 Java 环境；只有真正
取用 Spider / 调用 fetch / log 时才加载 base 包。
"""
import json as _json
import sys as _sys
import os as _os

_base_dir = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
if _base_dir not in _sys.path:
    _sys.path.insert(0, _base_dir)


def _hiker_attr(name):
    from base import hiker as _hiker
    return getattr(_hiker, name)


def fetch(url, options=None):
    return str(_hiker_attr("fetch")(url, options or {}))


def post(url, options=None):
    """T4 模板的 post 请求 -> 复用海阔 fetch（GET 语义），返回字符串。"""
    return str(_hiker_attr("fetch")(url, options or {}))


def get(url, options=None):
    return str(_hiker_attr("fetch")(url, options or {}))


def log(*objects, **kwargs):
    return _hiker_attr("log")(*objects, **kwargs)


def toast(info):
    return _hiker_attr("toast")(info)


def getCache(key, default=""):
    return _hiker_attr("getCache")(key, default)


def setCache(key, value):
    return _hiker_attr("setCache")(key, value)


def delCache(key):
    return _hiker_attr("delCache")(key)


def json(data=None, ensure_ascii=False):
    """T4 的 json 函数（序列化或反序列化）。"""
    if data is None:
        return _json
    if isinstance(data, (str, bytes)):
        return _json.loads(data)
    return _json.dumps(data, ensure_ascii=ensure_ascii)


def printf(*args, **kwargs):
    print(*args, **kwargs)


def __getattr__(name):
    # 惰性：Spider / BaseSpider 只有被显式取用时才加载 base.spider
    # （该包顶层依赖海阔 Java 环境，不能在本模块导入阶段触发）。
    if name in ("Spider", "BaseSpider"):
        from base.spider import BaseSpider as _BaseSpider
        if name == "Spider":
            return _BaseSpider
        return _BaseSpider
    raise AttributeError("module 't4' has no attribute %r" % (name,))


# 兼容 from t4 import * 时拿到的一等函数（不含惰性符号）
__all__ = [
    "Spider", "BaseSpider",
    "fetch", "post", "get", "json", "log", "toast",
    "getCache", "setCache", "delCache", "printf",
]
