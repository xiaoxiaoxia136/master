import Crypto as _crypto

__path__ = _crypto.__path__
__version__ = getattr(_crypto, "__version__", "")
