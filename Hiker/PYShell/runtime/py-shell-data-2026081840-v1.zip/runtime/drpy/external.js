 //正则matchAll
function matchesAll(str, pattern, flatten) {
  if (!pattern.global) {
    pattern = new RegExp(pattern.source, "g" + (pattern.ignoreCase ? "i" : "") + (pattern.multiline ? "m" : ""));
  }
  var matches = [];
  var match;
  while ((match = pattern.exec(str)) !== null) {
    matches.push(match);
  }
  return flatten ? matches.flat() : matches;
}

//文本扩展
function stringUtils() {
  Object.defineProperties(String.prototype, {
    replaceX: {
      value: function (regex, replacement) {
        let matches = matchesAll(this, regex,true);
        if (matches && matches.length > 1) {
          const hasCaptureGroup = /\$\d/.test(replacement);
          if (hasCaptureGroup) {
            return this.replace(regex, (m) => m.replace(regex, replacement));
          } else {
            return this.replace(regex, (m, p1) => m.replace(p1, replacement));
          }
        }
        return this.replace(regex, replacement);
      },
      configurable: true,
      enumerable: false,
      writable: true
    },
    parseX: {
      get: function () {
        try {
          //console.log(typeof this);
          return JSON.parse(this);
        } catch (e) {
          console.log(e);
          return this.startsWith("[") ? [] : {};
        }
      },
      configurable: true,
      enumerable: false,
    }
  });
}

//正则裁切
function cut(text, start, end, method, All) {
  let result = "";
  let c = (t, s, e) => {
    let result = "";
    let rs = [];
    let results = [];
    try {
      let lr = new RegExp(String.raw`${s}`.toString());
      let rr = new RegExp(String.raw`${e}`.toString());
      const segments = t.split(lr);
      if (segments.length < 2) return '';
      let cutSegments = segments.slice(1).map(segment => {
        let splitSegment = segment.split(rr);
        //log(splitSegment)
        return splitSegment.length < 2 ? undefined : splitSegment[0] + e;
      }).filter(f => f);
      //log(cutSegments.at(-1))
      if (All) {
        return `[${cutSegments.join(',')}]`;
      } else {
        return cutSegments[0];
      }
    } catch (e) {
      console.error("Error cutting text:", e);
    }
    return result;
  }
  result = c(text, start, end);
  stringUtils();
  if (method && typeof method === "function") {
    result = method(result);
  }
  //console.log(result);
  return result
}

// HTML标签转纯文本
function html2text(html) {
    if (!html || typeof html !== 'string') return html || '';
    return html.replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#(\d+);/g, (m, code) => String.fromCharCode(Number(code))).trim();
}

// 去除HTML标签但保留内容
function stripTags(str) {
    if (!str || typeof str !== 'string') return str || '';
    return str.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<[^>]+>/g, '');
}

// URL安全的字符串转换
function slugify(str) {
    if (!str || typeof str !== 'string') return '';
    return str.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_]+/g, '-').replace(/^-+|-+$/g, '');
}

// 截断字符串到指定长度
function truncate(str, len, suffix) {
    if (!str || typeof str !== 'string') return str || '';
    len = len || 50;
    suffix = suffix || '...';
    if (str.length <= len) return str;
    return str.substring(0, len) + suffix;
}

// HTML实体编码（防XSS）
function escHtml(str) {
    if (!str || typeof str !== 'string') return str || '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// 简易DOM文本提取（从HTML中按选择器提取文本）
function parseDom(html, selector) {
    if (!html || !selector) return '';
    try {
        let el = pdfa(html, selector);
        if (el && el.length > 0) return pdfh(el[0], 'Text') || '';
    } catch(e) {}
    return '';
}