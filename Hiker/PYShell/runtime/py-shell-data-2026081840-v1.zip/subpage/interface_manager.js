// 接口源管理：配置导入与配置线路分开进入。
var core = $.require("hiker://page/py_core_v1840");
var items = [];

setPageTitle("接口源管理");

items.push({
    title: "配置导入",
    desc: "输入远程地址或选择本地 JSON / JS 配置",
    pic_url: getPath(core.DATA_ROOT + "/assets/import_v116.png"),
    col_type: "icon_2",
    url: "hiker://page/py_config_import_v1840#noRecordHistory##noHistory#",
    extra: {lineVisible: false}
});

items.push({
    title: "线路管理",
    desc: "切换、搜索、分享或删除配置线路",
    pic_url: getPath(core.DATA_ROOT + "/assets/settings_v116.png"),
    col_type: "icon_2",
    url: "hiker://page/py_config_lines_v1840#noRecordHistory##noHistory#",
    extra: {lineVisible: false}
});

setResult(items);
