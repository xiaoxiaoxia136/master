// ES5-compatible bootstrap for older Hiker/Rhino runtimes.
function defineMethod(target, name, implementation) {
    if (typeof target[name] === "function") return;
    try {
        Object.defineProperty(target, name, {
            value: implementation,
            configurable: true,
            writable: true
        });
    } catch (ignoreDefinePropertyError) {
        target[name] = implementation;
    }
}

function sameValueZero(left, right) {
    return left === right || (left !== left && right !== right);
}

function installArrayMethods() {
    if (typeof Array.isArray !== "function") {
        Array.isArray = function(value) {
            return Object.prototype.toString.call(value) === "[object Array]";
        };
    }
    defineMethod(Array.prototype, "forEach", function(callback, thisArg) {
        if (this === null || this === undefined) throw new TypeError("Array.forEach called on null");
        for (var index = 0, length = Number(this.length) >>> 0; index < length; index++) {
            if (index in this) callback.call(thisArg, this[index], index, this);
        }
    });
    defineMethod(Array.prototype, "map", function(callback, thisArg) {
        if (this === null || this === undefined) throw new TypeError("Array.map called on null");
        var length = Number(this.length) >>> 0;
        var result = new Array(length);
        for (var index = 0; index < length; index++) {
            if (index in this) result[index] = callback.call(thisArg, this[index], index, this);
        }
        return result;
    });
    defineMethod(Array.prototype, "filter", function(callback, thisArg) {
        if (this === null || this === undefined) throw new TypeError("Array.filter called on null");
        var result = [];
        for (var index = 0, length = Number(this.length) >>> 0; index < length; index++) {
            if (index in this && callback.call(thisArg, this[index], index, this)) result.push(this[index]);
        }
        return result;
    });
    defineMethod(Array.prototype, "some", function(callback, thisArg) {
        if (this === null || this === undefined) throw new TypeError("Array.some called on null");
        for (var index = 0, length = Number(this.length) >>> 0; index < length; index++) {
            if (index in this && callback.call(thisArg, this[index], index, this)) return true;
        }
        return false;
    });
    defineMethod(Array.prototype, "find", function(callback, thisArg) {
        if (this === null || this === undefined) throw new TypeError("Array.find called on null");
        for (var index = 0, length = Number(this.length) >>> 0; index < length; index++) {
            var value = this[index];
            if (callback.call(thisArg, value, index, this)) return value;
        }
        return undefined;
    });
    defineMethod(Array.prototype, "findIndex", function(callback, thisArg) {
        if (this === null || this === undefined) throw new TypeError("Array.findIndex called on null");
        for (var index = 0, length = Number(this.length) >>> 0; index < length; index++) {
            if (callback.call(thisArg, this[index], index, this)) return index;
        }
        return -1;
    });
    defineMethod(Array.prototype, "includes", function(value, fromIndex) {
        var length = Number(this.length) >>> 0;
        var index = Number(fromIndex || 0);
        if (index < 0) index = Math.max(length + index, 0);
        for (; index < length; index++) {
            if (sameValueZero(this[index], value)) return true;
        }
        return false;
    });
}

function installObjectMethods() {
    if (typeof Object.keys !== "function") {
        Object.keys = function(object) {
            if (object === null || object === undefined) throw new TypeError("Object.keys called on null");
            var result = [];
            for (var key in Object(object)) {
                if (Object.prototype.hasOwnProperty.call(object, key)) result.push(key);
            }
            return result;
        };
    }
    if (typeof Object.assign !== "function") {
        Object.assign = function(target) {
            if (target === null || target === undefined) throw new TypeError("Object.assign target is null");
            var output = Object(target);
            for (var sourceIndex = 1; sourceIndex < arguments.length; sourceIndex++) {
                var source = arguments[sourceIndex];
                if (source === null || source === undefined) continue;
                for (var key in Object(source)) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) output[key] = source[key];
                }
            }
            return output;
        };
    }
}

function installStringMethods() {
    defineMethod(String.prototype, "trim", function() {
        return String(this).replace(/^\s+|\s+$/g, "");
    });
    defineMethod(String.prototype, "startsWith", function(prefix, position) {
        var text = String(this);
        var start = Math.max(0, Number(position || 0));
        prefix = String(prefix);
        return text.slice(start, start + prefix.length) === prefix;
    });
    defineMethod(String.prototype, "endsWith", function(suffix, length) {
        var text = String(this);
        var end = length === undefined ? text.length : Math.min(Number(length), text.length);
        suffix = String(suffix);
        return text.slice(end - suffix.length, end) === suffix;
    });
    defineMethod(String.prototype, "includes", function(value, position) {
        return String(this).indexOf(String(value), Number(position || 0)) >= 0;
    });
}

function legacyMapClass() {
    function LegacyMap(entries) {
        this._keys = [];
        this._values = [];
        this.size = 0;
        if (entries && typeof entries.length === "number") {
            for (var index = 0; index < entries.length; index++) {
                if (entries[index]) this.set(entries[index][0], entries[index][1]);
            }
        }
    }
    LegacyMap.prototype._indexOf = function(key) {
        for (var index = 0; index < this._keys.length; index++) {
            if (sameValueZero(this._keys[index], key)) return index;
        }
        return -1;
    };
    LegacyMap.prototype.set = function(key, value) {
        var index = this._indexOf(key);
        if (index < 0) {
            this._keys.push(key);
            this._values.push(value);
            this.size = this._keys.length;
        } else {
            this._values[index] = value;
        }
        return this;
    };
    LegacyMap.prototype.get = function(key) {
        var index = this._indexOf(key);
        return index < 0 ? undefined : this._values[index];
    };
    LegacyMap.prototype.has = function(key) { return this._indexOf(key) >= 0; };
    LegacyMap.prototype.delete = function(key) {
        var index = this._indexOf(key);
        if (index < 0) return false;
        this._keys.splice(index, 1);
        this._values.splice(index, 1);
        this.size = this._keys.length;
        return true;
    };
    LegacyMap.prototype.clear = function() {
        this._keys.length = 0;
        this._values.length = 0;
        this.size = 0;
    };
    LegacyMap.prototype.forEach = function(callback, thisArg) {
        var keys = this._keys.slice();
        for (var index = 0; index < keys.length; index++) {
            if (this.has(keys[index])) callback.call(thisArg, this.get(keys[index]), keys[index], this);
        }
    };
    return LegacyMap;
}

function legacySetClass(MapClass) {
    function LegacySet(values) {
        this._map = new MapClass();
        this.size = 0;
        if (values && typeof values.length === "number") {
            for (var index = 0; index < values.length; index++) this.add(values[index]);
        }
    }
    LegacySet.prototype.add = function(value) {
        this._map.set(value, value);
        this.size = this._map.size;
        return this;
    };
    LegacySet.prototype.has = function(value) { return this._map.has(value); };
    LegacySet.prototype.delete = function(value) {
        var removed = this._map.delete(value);
        this.size = this._map.size;
        return removed;
    };
    LegacySet.prototype.clear = function() { this._map.clear(); this.size = 0; };
    LegacySet.prototype.forEach = function(callback, thisArg) {
        var self = this;
        this._map.forEach(function(value) { callback.call(thisArg, value, value, self); });
    };
    return LegacySet;
}

function install() {
    installObjectMethods();
    installArrayMethods();
    installStringMethods();
    var root = (function() { return this; })();
    if (typeof Map !== "function") {
        var MapPolyfill = legacyMapClass();
        try { root.Map = MapPolyfill; } catch (ignoreMapRootError) { Map = MapPolyfill; }
    }
    if (typeof Set !== "function") {
        var SetPolyfill = legacySetClass(typeof Map === "function" ? Map : legacyMapClass());
        try { root.Set = SetPolyfill; } catch (ignoreSetRootError) { Set = SetPolyfill; }
    }
    return true;
}

install();

$.exports = {
    install: install
};
