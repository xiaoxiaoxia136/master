function resolveUrl(base, relative) {
    var value = String(relative || "").trim();
    if (!value || /^[a-zA-Z][\w+.-]*:\/\//.test(value)) return value;
    var origin = String(base || "").match(/^(https?:\/\/[^/]+)/i);
    if (value[0] === "/") return origin ? origin[1] + value : value;
    return String(base || "").replace(/[^/]*(?:[?#].*)?$/, "") + value;
}

function proxyExt(url) {
    var text = String(url || "");
    if (!/^proxy:\/\//i.test(text)) return text;
    var match = text.match(/[?&]ext=([^&]+)/i);
    if (!match) return "";
    var value = match[1];
    try { value = decodeURIComponent(value); } catch (ignoreDecodeError) {}
    try { if (!/^https?:/i.test(value)) value = base64Decode(value); } catch (ignoreBase64Error) {}
    return value;
}

function normalizeGroup(value) {
    var group = String(value || "").trim();
    return /^第\d+页$/i.test(group) ? "默认分组" : (group || "默认分组");
}

function attrValue(line, name) {
    var quoted = new RegExp(name + "\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']", "i").exec(String(line || ""));
    if (quoted) return quoted[1].trim();
    var plain = new RegExp(name + "\\s*=\\s*([^\\s,]+)", "i").exec(String(line || ""));
    return plain ? plain[1].trim() : "";
}

function pageUrl(url, page) {
    var value = String(url || "");
    var number = Math.max(1, Number(page || 1));
    if (number <= 1) return value;
    if (/[?&]page=\d+/i.test(value)) return value.replace(/([?&]page=)\d+/i, "$1" + number);
    return value + (value.indexOf("?") >= 0 ? "&" : "?") + "page=" + number;
}

function parsePageInfo(text) {
    var content = String(text || "");
    var footer = content.match(/共\s*([\d,]+)\s*部[，,]?\s*当前第\s*(\d+)\s*页[，,]?\s*每页\s*(\d+)/i);
    if (footer) {
        var total = Number(String(footer[1]).replace(/,/g, ""));
        var pageSize = Number(footer[3] || 0);
        return {
            total: total,
            page: Number(footer[2] || 1),
            pageSize: pageSize,
            pageCount: pageSize > 0 ? Math.ceil(total / pageSize) : 0
        };
    }
    if (content[0] === "{" || content[0] === "[") {
        try {
            var json = JSON.parse(content);
            var pageInfo = json && !Array.isArray(json) ? (json.pageInfo || json.pagination || json) : {};
            var page = Number(pageInfo.page || pageInfo.current || 1);
            var pageSize = Number(pageInfo.pageSize || pageInfo.limit || pageInfo.size || 0);
            var total = Number(pageInfo.total || pageInfo.count || 0);
            var pageCount = Number(pageInfo.pageCount || pageInfo.pages || 0);
            if (pageCount || total || pageSize) return {total: total, page: page, pageSize: pageSize, pageCount: pageCount || (pageSize ? Math.ceil(total / pageSize) : 0)};
        } catch (ignoreJsonPageInfoError) {}
    }
    return {total: 0, page: 1, pageSize: 0, pageCount: 0};
}

function parseChannels(text, baseUrl) {
    var content = String(text || "").trim();
    var channels = [];
    if (!content) return channels;
    // 部分直播源返回的 txt 用 <br> 连接条目（如 fanmingming txt 接口），
    // 先归一化为换行，否则整块内容会被当成单行解析成一个大"频道"。
    if (content.indexOf("<br") >= 0) {
        content = content.replace(/<br\s*\/?>/gi, "\n");
    }
    if (content[0] === "{" || content[0] === "[") {
        try {
            var json = JSON.parse(content);
            var lives = Array.isArray(json) ? json : (json.lives || []);
            lives.forEach(function(group) {
                var groupName = normalizeGroup(group.group || group.name || "默认分组");
                (group.channels || []).forEach(function(channel) {
                    var urls = Array.isArray(channel.urls) ? channel.urls : [channel.url || ""];
                    urls.filter(Boolean).forEach(function(url, index) {
                        var item = {group: groupName, name: String(channel.name || "频道") + (index ? " " + (index + 1) : ""), url: String(url)};
                        var pic = channel.pic || channel.pic_url || channel.logo || channel.image || channel.cover || channel.poster || "";
                        if (pic) item.pic = resolveUrl(baseUrl, pic);
                        channels.push(item);
                    });
                });
            });
            if (channels.length) return channels;
        } catch (ignoreJsonError) {}
    }
    var lines = content.split(/\r?\n/);
    var group = "默认分组";
    var isM3u = /#EXTM3U|#EXTINF/i.test(content);
    for (var i = 0; i < lines.length; i++) {
        var line = String(lines[i] || "").trim();
        if (!line) continue;
        if (/^#EXTGRP:/i.test(line)) {
            group = normalizeGroup(line.replace(/^#EXTGRP:/i, "").trim());
            continue;
        }
        if (/^#EXTINF/i.test(line)) {
            var groupMatch = line.match(/group-title=["']([^"']+)["']/i);
            var nameMatch = line.match(/,([^,]+)$/);
            var logo = attrValue(line, "tvg-logo");
            var next = i + 1;
            while (next < lines.length && !String(lines[next] || "").trim()) next++;
            var media = String(lines[next] || "").trim();
            if (media && media[0] !== "#") {
                var m3uItem = {group: normalizeGroup(groupMatch ? groupMatch[1] : group), name: nameMatch ? nameMatch[1].trim() : "频道 " + (channels.length + 1), url: resolveUrl(baseUrl, media)};
                if (logo) m3uItem.pic = resolveUrl(baseUrl, logo);
                channels.push(m3uItem);
                i = next;
            }
            continue;
        }
        if (!isM3u && line[0] !== "#" && /[a-zA-Z][\w+.-]*:\/\//.test(line)) {
            var comma = line.lastIndexOf(",");
            var separator = comma > 0 ? comma : line.lastIndexOf("$");
            var name = separator > 0 ? line.slice(0, separator).trim() : "频道 " + (channels.length + 1);
            var url = separator > 0 ? line.slice(separator + 1).trim() : line;
            channels.push({group: group, name: name, url: resolveUrl(baseUrl, url)});
        } else if (/^[^,\s]+,#genre#\s*$/i.test(line)) {
            // txt 格式的分组标记行：`央视频道,#genre#` → 后续频道归入该组
            group = normalizeGroup(line.replace(/#genre#\s*$/i, "").replace(/^[,\s]+|[,\s]+$/g, "").trim());
        }
    }
    return channels;
}

function parseRemoteResult(url, page) {
    var target = proxyExt(url);
    if (!target) throw new Error("直播源地址无效");
    var requestUrl = pageUrl(target, page);
    var text = "";
    try {
        text = request(requestUrl, {timeout: 8000, headers: {}});
    } catch (error) {
        var errorText = error && error.toString ? error.toString() : String(error);
        throw new Error("直播源请求失败（超时或网络错误）：" + errorText);
    }
    if (!text) throw new Error("直播源没有返回内容（可能已失效或需要UA）");
    var channels = parseChannels(text, requestUrl);
    if (!channels.length) throw new Error("没有解析到直播频道");
    return {channels: channels, pageInfo: parsePageInfo(text), requestUrl: requestUrl};
}

function parseRemote(url) {
    return parseRemoteResult(url, 1).channels;
}

function parseRemotePage(url, page) {
    return parseRemoteResult(url, page).channels;
}

$.exports = {resolveUrl: resolveUrl, proxyExt: proxyExt, pageUrl: pageUrl, parsePageInfo: parsePageInfo, parseChannels: parseChannels, parseRemoteResult: parseRemoteResult, parseRemote: parseRemote, parseRemotePage: parseRemotePage};
