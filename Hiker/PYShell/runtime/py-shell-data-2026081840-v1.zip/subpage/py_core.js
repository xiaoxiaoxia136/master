var RULE_TITLE = (typeof MY_RULE !== "undefined" && MY_RULE && MY_RULE.title)
    ? String(MY_RULE.title)
    : "PY影视壳";
var legacyCompat = $.require("hiker://files/data/" + RULE_TITLE + "/subpage/legacy_compat.js");
legacyCompat.install();
var BUILD_VERSION = "2026081840";
var PAGE_SUFFIX = "_v1840";
var CORE_PAGE_PATH = "hiker://page/py_core_v1840";
var EXTERNAL_RUNTIME_PAGE_PATH = "hiker://page/py_external_runtime_v1840";

// 兼容旧版 Rhino：不要依赖 ES6 的 String.prototype.startsWith/endsWith。
function startsWith(value, prefix) {
    value = String(value || "");
    prefix = String(prefix || "");
    return value.slice(0, prefix.length) === prefix;
}

function endsWith(value, suffix) {
    value = String(value || "");
    suffix = String(suffix || "");
    return suffix === "" || value.slice(-suffix.length) === suffix;
}
var DATA_ROOT = "hiker://files/data/" + RULE_TITLE;
var BUNDLED_SOURCE_ROOT = DATA_ROOT + "/sources";
var SOURCE_ROOT = "hiker://files/rules/" + RULE_TITLE + "/py_sources";
var INDEX_PATH = "hiker://files/rules/" + RULE_TITLE + "/py_sources.json";
var LINE_SOURCE_INDEX_PATH = "hiker://files/rules/" + RULE_TITLE + "/line_sources.json";
var ACTIVE_SOURCE_PATH = "hiker://files/rules/" + RULE_TITLE + "/active_source.json";
var HISTORY_PATH = "hiker://files/rules/" + RULE_TITLE + "/py_history.json";
var SCAN_FOLDER_PATH = "hiker://files/rules/" + RULE_TITLE + "/py_scan_folder.txt";
var BATCH_REPORT_PATH = "hiker://files/rules/" + RULE_TITLE + "/py_batch_import.json";
var CONFIG_INDEX_PATH = "hiker://files/rules/" + RULE_TITLE + "/source_configs.json";
var SOURCE_STATUS_PATH = "hiker://files/rules/" + RULE_TITLE + "/source_status.json";
var LIVE_INDEX_PATH = "hiker://files/rules/" + RULE_TITLE + "/live_sources.json";
var CATEGORY_PREFETCH_PATH = "hiker://files/_cache/" + RULE_TITLE + "_category_prefetch_" + BUILD_VERSION + ".json";
var SHARE_ROOT = "hiker://files/_cache";
var HISTORY_LIMIT = 200;
var RUNTIME_PATH = DATA_ROOT + "/runtime/PythonHiker.js";
var RUNTIME_INFO = {
    python: "3.8",
    abi: "arm64-v8a",
    packages: [
        "requests 2.32.4",
        "beautifulsoup4 4.13.4",
        "lxml 4.6.3",
        "pyquery 2.0.1",
        "jsonpath 0.82.2",
        "pycryptodome 3.9.4",
        "Cryptodome 兼容别名",
        "ujson 1.35",
        "Jinja2 3.1.6"
    ]
};
var instanceCache = new Map();
var dependencyCache = new Map();
var detailCache = new Map();
var imageHeaderCache = new Map();
var imageDecoderConfigCache = new Map();
var genericListCache = new Map();
var homeClassCache = new Map();
var categoryResultMemoryCache = new Map();
// 切源预热的一次性首页结果：主页消费后立即删除，避免 warmSource 后
// 紧接着再次调用同一个 homeContent。不是长期内容缓存。
var warmHomeResultCache = new Map();
var CATEGORY_PREFETCH_VERSION = 4;
var CATEGORY_PREFETCH_TTL_MS = 15 * 60 * 1000;
var CATEGORY_PREFETCH_STALE_TTL_MS = 6 * 60 * 60 * 1000;
var CATEGORY_PREFETCH_MAX_ITEMS = 60;
var CATEGORY_PREFETCH_MAX_FILES = 48;
var CATEGORY_PREFETCH_MAX_BYTES = 4 * 1024 * 1024;
var CATEGORY_PREFETCH_PRUNE_INTERVAL_MS = 10 * 60 * 1000;
var GENERIC_LIST_CACHE_TTL_MS = 5 * 60 * 1000;
var lastCategoryPrefetchPruneAt = 0;
var runtimeModule = null;
var externalRuntimeModule = null;
var lastRuntimeProxySyncAt = 0;
var localProxyUrl = "";
var IMAGE_PIPELINE_VERSION = "2026081840";
var BUILTIN_IMAGE_DECODERS = [
    {
        id: "black-material-aes-cbc-v1",
        hosts: ["pic.uforxk.cn", "pic.lbupup.cn", "pic.gylhaa.cn", "new.slfpld.cn", "pic.xmbvxj.cn"],
        type: "cipher",
        transformation: "AES/CBC/PKCS5Padding",
        key: "f5d965df75336270",
        iv: "97b60394abc2fbe1",
        keyEncoding: "utf8",
        ivEncoding: "utf8"
    },
    {
        id: "py-xiaohongshu-xor100-v1",
        sourceNames: ["小红薯APP", "py_411098a318a30cc6"],
        type: "xor",
        xorKey: "2020-zq3-888",
        xorKeyEncoding: "utf8",
        xorLength: 100,
        headers: {
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 11; M2012K10C Build/RP1A.200720.011)"
        }
    },
    {
        id: "py-black-material-aes-auto-v1",
        // 导入器/用户重命名会去掉作者装饰符，使用稳定的核心名称匹配。
        sourceNames: ["51爆料", "818黑料网", "51吸瓜"],
        type: "auto-cipher",
        candidates: [
            {transformation: "AES/CBC/PKCS5Padding", key: "f5d965df75336270", iv: "97b60394abc2fbe1"},
            {transformation: "AES/CBC/PKCS5Padding", key: "75336270f5d965df", iv: "abc2fbe197b60394"},
            {transformation: "AES/ECB/PKCS5Padding", key: "f5d965df75336270", iv: ""},
            {transformation: "AES/ECB/PKCS5Padding", key: "75336270f5d965df", iv: ""}
        ]
    },
    {
        id: "py-bihe-data-url-v1",
        sourceNames: ["笔盒", "py_d9c3f55263fa39fa"],
        urlContains: [".txt"],
        type: "bh-data-url"
    },
    {
        id: "py-together-xor88-v1",
        sourceNames: ["一起草", "py_3463dd47712573f5"],
        type: "xor",
        xorKey: "88",
        xorKeyEncoding: "hex",
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 15; 23013RK75C Build/AQ3A.250226.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/146.0.7680.177 Mobile Safari/537.36",
            "Referer": "https://www.17c.com/"
        }
    }
];
// 图片网络健康路由。机制按域名工作，不绑定 PY 源 ID；同域名的任意源均受益。
// 目标 IP 请求失败时，图片桥会回退原始域名 URL。
var BUILTIN_IMAGE_NETWORK_ROUTES = [
    {
        hosts: ["pic.dipiccdn.cc"],
        healthyIp: "216.158.73.37"
    }
];
// 普通图片不再维护逐域 HTTPS 白名单。公共 HTTP CDN 会先生成 HTTPS
// 候选；海阔图片主请求失败时由 @js InputStream 回调退回原 HTTP，避免
// 只支持 HTTP 的旧 CDN 被强制升级后失效。回环、局域网和自定义端口
// 保持原协议，不触碰 PY 本地代理。
var AUTO_IMAGE_CIPHERS = [
    {
        transformation: "AES/CBC/PKCS5Padding",
        key: "f5d965df75336270",
        iv: "97b60394abc2fbe1"
    },
    {
        transformation: "AES/CBC/PKCS5Padding",
        key: "75336270f5d965df",
        iv: "abc2fbe197b60394"
    },
    {
        transformation: "AES/ECB/PKCS5Padding",
        key: "f5d965df75336270",
        iv: ""
    },
    {
        transformation: "AES/ECB/PKCS5Padding",
        key: "75336270f5d965df",
        iv: ""
    }
];

function clone(value) {
    return JSON.parse(JSON.stringify(value));
}

function pause(ms) {
    try { java.lang.Thread.sleep(Number(ms || 0)); } catch (ignoreSleepError) {}
}

function decodeJsonResult(value) {
    if (typeof value !== "string") return value;
    var text = value.trim();
    if (!text || (text[0] !== "{" && text[0] !== "[")) return value;
    try { return JSON.parse(text); } catch (ignoreJsonError) { return value; }
}

function getExternalRuntime() {
    if (!externalRuntimeModule) externalRuntimeModule = $.require(EXTERNAL_RUNTIME_PAGE_PATH);
    return externalRuntimeModule;
}

function sourceRuntimeKind(source) {
    source = source || {};
    var kind = String(source.runtime || source.kind || "").toLowerCase();
    if (kind) return kind;
    return /\.py(?:$|[?#])/i.test(String(source.path || source.api || "")) ? "py" : "py";
}

function isExternalSource(source) {
    return sourceRuntimeKind(source) !== "py";
}

function firstValue(object, keys, fallback) {
    object = object || {};
    for (var i = 0; i < keys.length; i++) {
        var value = object[keys[i]];
        if (value !== undefined && value !== null && String(value) !== "") return value;
    }
    return fallback;
}

function normalizeVod(vod, index) {
    var item;
    if (Array.isArray(vod)) {
        item = {
            vod_id: vod[0],
            vod_name: vod[1],
            vod_pic: vod[2],
            vod_remarks: vod[3]
        };
    } else if (vod && typeof vod === "object") {
        item = Object.assign({}, vod);
    } else {
        item = {vod_id: vod, vod_name: vod};
    }

    var id = firstValue(item, ["vod_id", "vodId", "id", "video_id", "url", "link", "href"], "");
    var name = firstValue(item, ["vod_name", "vodName", "name", "title", "text"], id || ("未命名 " + (Number(index || 0) + 1)));
    var pic = firstValue(item, ["vod_pic", "vodPic", "pic", "pic_url", "img", "image", "cover", "poster", "thumb"], "");
    var remarks = firstValue(item, ["vod_remarks", "vodRemarks", "remarks", "remark", "desc", "description", "note", "subtitle", "vod_year"], "");

    item.vod_id = String(id || name || "");
    item.vod_name = String(name || item.vod_id || "未命名");
    item.vod_pic = String(pic || "");
    item.vod_remarks = String(remarks || "");
    if (!item.vod_tag && item.tag) item.vod_tag = item.tag;
    if (!item.vod_play_from) item.vod_play_from = firstValue(item, ["play_from", "playFrom"], "");
    if (!item.vod_play_url) item.vod_play_url = firstValue(item, ["play_url", "playUrl"], "");
    if (!item.vod_content) item.vod_content = firstValue(item, ["vodContent", "content", "summary", "intro"], "");
    if (!item.vod_actor) item.vod_actor = firstValue(item, ["actor", "actors", "cast"], "");
    if (!item.vod_director) item.vod_director = firstValue(item, ["director", "directors"], "");
    return item;
}

function extractList(value) {
    var raw = decodeJsonResult(value);
    if (Array.isArray(raw)) return raw;
    if (!raw || typeof raw !== "object") return [];
    var keys = ["list", "videos", "items", "results", "result", "data"];
    for (var i = 0; i < keys.length; i++) {
        var candidate = decodeJsonResult(raw[keys[i]]);
        if (Array.isArray(candidate)) return candidate;
        if (candidate && typeof candidate === "object" && Array.isArray(candidate.list)) return candidate.list;
    }
    return [];
}

// 列表→详情兜底缓存：源 detailContent 依赖自身内存缓存时（如 March 的
// self.items），PY 壳列表页与详情页可能不在同一 spider 实例，缓存会在
// 详情阶段丢失。这里在 normalizeVodList 时缓存每个 vod 的原始数据
// （含 url 等源侧字段），detailSource 源返回空时用它构造兜底详情。
var vodListRawCache = new Map();
var VOD_RAW_CACHE_KEY = "py_shell_vod_raw_cache@" + BUILD_VERSION;
var VOD_RAW_CACHE_MAX = 500;
var vodRawCacheLoaded = false;

function loadVodRawCache() {
    if (vodRawCacheLoaded) return;
    vodRawCacheLoaded = true;
    try {
        var saved = readJson(VOD_RAW_CACHE_KEY, null);
        if (saved && Array.isArray(saved)) {
            saved.forEach(function(entry) {
                if (entry && entry.k) vodListRawCache.set(entry.k, entry.v);
            });
        }
    } catch (ignoreVodRawCacheLoadError) {}
}

function persistVodRawCache() {
    try {
        var entries = [];
        vodListRawCache.forEach(function(value, key) {
            entries.push({k: key, v: value});
        });
        writeJson(VOD_RAW_CACHE_KEY, entries.slice(-VOD_RAW_CACHE_MAX));
    } catch (ignoreVodRawCacheSaveError) {}
}

function cacheVodRaw(sourceId, vodId, rawVod, deferPersist) {
    if (!sourceId || !vodId || !rawVod) return false;
    loadVodRawCache();
    vodListRawCache.set(String(sourceId) + "@" + String(vodId), rawVod);
    if (vodListRawCache.size > VOD_RAW_CACHE_MAX) {
        // 简单淘汰：清掉最旧的 1/3
        var keys = [];
        vodListRawCache.forEach(function(_, key) { keys.push(key); });
        keys.slice(0, Math.floor(VOD_RAW_CACHE_MAX / 3)).forEach(function(key) {
            vodListRawCache.delete(key);
        });
    }
    if (!deferPersist) persistVodRawCache();
    return true;
}

function getVodRawCached(sourceId, vodId) {
    loadVodRawCache();
    return vodListRawCache.get(String(sourceId) + "@" + String(vodId)) || null;
}

function clearVodRawForSource(sourceId) {
    loadVodRawCache();
    var prefix = String(sourceId || "") + "@";
    var changed = false;
    vodListRawCache.forEach(function(_, key) {
        if (startsWith(String(key), prefix)) {
            vodListRawCache.delete(key);
            changed = true;
        }
    });
    if (changed) persistVodRawCache();
}

function normalizeVodList(value, sourceId) {
    var list = extractList(value);
    var rawCacheChanged = false;
    if (sourceId) {
        list.forEach(function(vod) {
            try {
                var raw = vod && typeof vod === "object" ? vod : {vod_id: vod, vod_name: vod};
                var vid = String(raw.vod_id || raw.id || raw.url || raw.link || "");
                if (vid && cacheVodRaw(sourceId, vid, raw, true)) rawCacheChanged = true;
            } catch (ignoreVodRawCacheError) {}
        });
        // A list can contain dozens of items. Persist once per parsed list instead
        // of rewriting the whole fallback cache for every card.
        if (rawCacheChanged) persistVodRawCache();
    }
    return list.map(function(vod, index) { return normalizeVod(vod, index); });
}

function normalizeClassList(value) {
    var list = Array.isArray(value) ? value : [];
    return list.map(function(category, index) {
        if (!category || typeof category !== "object") {
            return {type_id: String(category || index), type_name: String(category || "分类")};
        }
        var typeId = firstValue(category, ["type_id", "typeId", "id", "tid", "value", "url"], index);
        var typeName = firstValue(category, ["type_name", "typeName", "name", "title", "text"], typeId);
        return Object.assign({}, category, {type_id: String(typeId), type_name: String(typeName || typeId)});
    });
}

function normalizePageResult(value, sourceId) {
    var raw = decodeJsonResult(value);
    var result = raw && !Array.isArray(raw) && typeof raw === "object" ? Object.assign({}, raw) : {};
    result.list = normalizeVodList(raw, sourceId);
    return result;
}

function normalizeHomeResult(value, sourceId) {
    var raw = decodeJsonResult(value);
    var result = raw && !Array.isArray(raw) && typeof raw === "object" ? Object.assign({}, raw) : {};
    var classes = firstValue(result, ["class", "classes", "categories", "types"], []);
    result.class = normalizeClassList(classes);
    result.filters = firstValue(result, ["filters", "filter"], {}) || {};
    result.list = normalizeVodList(raw, sourceId);
    return result;
}

function errorText(error) {
    var text = error && error.toString ? error.toString() : String(error);
    if (error && error.lineNumber) text += " (line " + error.lineNumber + ")";
    return text;
}

function readJson(path, fallback) {
    if (!fileExist(path)) return clone(fallback);
    try {
        var text = readLocalText(path);
        return text ? JSON.parse(text) : clone(fallback);
    } catch (error) {
        return clone(fallback);
    }
}

function writeJson(path, value) {
    writeFile(path, JSON.stringify(value));
}

function defaultHistory() {
    return {version: 1, items: []};
}

function getHistoryStore() {
    var store = readJson(HISTORY_PATH, defaultHistory());
    if (!store || typeof store !== "object") store = defaultHistory();
    if (!Array.isArray(store.items)) store.items = [];
    store.version = 1;
    store.items = store.items.filter(function(item) {
        return item && item.sourceId && item.vodId;
    }).slice(0, HISTORY_LIMIT);
    return store;
}

function listHistory() {
    return clone(getHistoryStore().items);
}

function recordHistory(entry) {
    entry = entry || {};
    var sourceId = String(entry.sourceId || "");
    var vodId = String(entry.vodId || "");
    if (!sourceId || !vodId) throw new Error("历史记录缺少视频源或详情 ID");

    var store = getHistoryStore();
    var key = sourceId + "@" + md5(vodId);
    var old = store.items.find(function(item) { return item.key === key; }) || {};
    var sourceName = String(entry.sourceName || old.sourceName || sourceId);
    try { sourceName = String(entry.sourceName || getSource(sourceId).name || sourceName); } catch (ignoreSourceNameError) {}

    var merged = Object.assign({}, old, {
        key: key,
        sourceId: sourceId,
        sourceName: sourceName,
        vodId: vodId,
        title: String(entry.title || old.title || "未命名"),
        pic: String(entry.pic || old.pic || ""),
        updatedAt: Date.now()
    });
    ["flag", "episodeName", "playId"].forEach(function(field) {
        if (entry[field] !== undefined && entry[field] !== null && String(entry[field]) !== "") {
            merged[field] = String(entry[field]);
        }
    });

    store.items = [merged].concat(store.items.filter(function(item) { return item.key !== key; }));
    store.items = store.items.slice(0, HISTORY_LIMIT);
    writeJson(HISTORY_PATH, store);
    return clone(merged);
}

function removeHistory(key) {
    var store = getHistoryStore();
    var before = store.items.length;
    store.items = store.items.filter(function(item) { return item.key !== String(key || ""); });
    if (store.items.length !== before) writeJson(HISTORY_PATH, store);
    return store.items.length !== before;
}

function clearHistory() {
    writeJson(HISTORY_PATH, defaultHistory());
    return true;
}

function normalizeFolderPath(path) {
    var value = String(path || "").trim();
    if (startsWith(value, "hiker://")) value = getPath(value);
    if (startsWith(value, "file://")) value = value.slice(7);
    value = value.replace(/\\/g, "/");
    return value.length > 1 ? value.replace(/\/$/, "") : value;
}

function folderObject(path) {
    return new java.io.File(normalizeFolderPath(path));
}

function folderCanonicalPath(file) {
    try { return String(file.getCanonicalPath()); } catch (ignoreCanonicalError) { return String(file.getAbsolutePath()); }
}

function getScanFolder() {
    if (!fileExist(SCAN_FOLDER_PATH)) return "";
    try { return normalizeFolderPath(request(SCAN_FOLDER_PATH)); } catch (ignoreScanFolderReadError) { return ""; }
}

function setScanFolder(path) {
    var value = normalizeFolderPath(path);
    if (!value) throw new Error("请选择或填写 PY 文件夹");
    var folder = folderObject(value);
    if (!folder.exists() || !folder.isDirectory()) throw new Error("文件夹不存在或没有访问权限: " + value);
    value = folderCanonicalPath(folder);
    writeFile(SCAN_FOLDER_PATH, value);
    return value;
}

function listFolderRoots() {
    var roots = [];
    var seen = {};
    ["/storage/emulated/0", "/sdcard", "/storage"].forEach(function(path) {
        try {
            var file = folderObject(path);
            if (!file.exists() || !file.isDirectory()) return;
            var canonical = folderCanonicalPath(file);
            if (seen[canonical]) return;
            seen[canonical] = true;
            roots.push({name: path, path: canonical});
        } catch (ignoreRootError) {}
    });
    return roots;
}

function listFolder(path) {
    var folder = folderObject(path);
    if (!folder.exists() || !folder.isDirectory()) throw new Error("文件夹不存在或没有访问权限: " + path);
    var files = folder.listFiles();
    if (files === null) throw new Error("系统未允许读取该文件夹");
    var folders = [];
    var pyFiles = [];
    for (var index = 0; index < files.length; index++) {
        var file = files[index];
        var name = String(file.getName());
        if (!name || startsWith(name, ".")) continue;
        if (file.isDirectory()) {
            folders.push({name: name, path: folderCanonicalPath(file)});
        } else if (file.isFile() && /\.py$/i.test(name)) {
            pyFiles.push({name: name, path: folderCanonicalPath(file), size: Number(file.length() || 0)});
        }
    }
    folders.sort(function(left, right) { return left.name.localeCompare(right.name); });
    pyFiles.sort(function(left, right) { return left.name.localeCompare(right.name); });
    var parent = folder.getParentFile();
    return {
        path: folderCanonicalPath(folder),
        parent: parent ? folderCanonicalPath(parent) : "",
        folders: folders,
        pyFiles: pyFiles
    };
}

function getBatchImportReport() {
    return readJson(BATCH_REPORT_PATH, {folder: "", total: 0, imported: 0, skipped: 0, failed: 0, failures: [], savedAt: 0});
}

function importFolder(path) {
    var selectedFolder = setScanFolder(path);
    var folderInfo = listFolder(selectedFolder);
    if (!folderInfo.pyFiles.length) throw new Error("当前文件夹没有 .py 文件");
    var report = {
        folder: selectedFolder,
        total: folderInfo.pyFiles.length,
        imported: 0,
        skipped: 0,
        failed: 0,
        importedNames: [],
        failures: [],
        savedAt: Date.now()
    };
    folderInfo.pyFiles.forEach(function(file) {
        try {
            var code = request("file://" + file.path);
            if (code && code.charCodeAt(0) === 0xfeff) code = code.slice(1);
            var digest = md5(code || "");
            var existed = getIndex().sources.some(function(source) { return String(source.md5 || "") === digest; });
            if (existed) {
                report.skipped++;
                return;
            }
            var source = importSource("file://" + file.path);
            report.imported++;
            report.importedNames.push(source.name || file.name);
        } catch (error) {
            report.failed++;
            report.failures.push({file: file.name, error: errorText(error)});
        }
    });
    writeJson(BATCH_REPORT_PATH, report);
    return clone(report);
}

function defaultIndex() {
    return {
        version: 4,
        current: "",
        sources: []
    };
}

function defaultLineSourceIndex() {
    return {version: 1, current: "", sources: []};
}

function readLineSourceIndexRaw() {
    var store = readJson(LINE_SOURCE_INDEX_PATH, defaultLineSourceIndex());
    if (!store || typeof store !== "object") store = defaultLineSourceIndex();
    if (!Array.isArray(store.sources)) store.sources = [];
    return store;
}

function sourcePathIsAvailable(source) {
    if (!source || !source.id || !source.path) return false;
    if (source.managedLocal === false) return true;
    return fileExist(source.path);
}

function migrateLegacyLineSources() {
    var raw = readJson(INDEX_PATH, defaultIndex());
    if (!raw || typeof raw !== "object" || !Array.isArray(raw.sources)) return;
    var legacy = raw.sources.filter(function(source) { return source && source.lineId; });
    if (!legacy.length) return;
    var lineStore = readLineSourceIndexRaw();
    var byId = {};
    lineStore.sources.forEach(function(source) { if (source && source.id) byId[String(source.id)] = source; });
    legacy.forEach(function(source) { byId[String(source.id)] = source; });
    lineStore.sources = Object.keys(byId).map(function(id) { return byId[id]; });
    if (!lineStore.current || !lineStore.sources.some(function(source) { return source.id === lineStore.current; })) {
        lineStore.current = legacy.some(function(source) { return source.id === raw.current; }) ? String(raw.current) : (lineStore.sources[0] ? lineStore.sources[0].id : "");
    }
    var legacyCurrentId = legacy.some(function(source) { return source.id === raw.current; }) ? String(raw.current) : "";
    raw.sources = raw.sources.filter(function(source) { return !(source && source.lineId); });
    raw.version = 4;
    if (!raw.sources.some(function(source) { return source.id === raw.current; })) raw.current = raw.sources[0] ? raw.sources[0].id : "";
    writeJson(INDEX_PATH, raw);
    writeJson(LINE_SOURCE_INDEX_PATH, lineStore);
    if (legacyCurrentId) {
        writeJson(ACTIVE_SOURCE_PATH, {version: 1, sourceId: legacyCurrentId});
    }
}

function getLineSourceIndex() {
    migrateLegacyLineSources();
    var store = readLineSourceIndexRaw();
    var before = store.sources.length;
    store.sources = store.sources.filter(sourcePathIsAvailable);
    if (store.sources.length !== before) {
        if (!store.sources.some(function(source) { return source.id === store.current; })) store.current = store.sources[0] ? store.sources[0].id : "";
        writeJson(LINE_SOURCE_INDEX_PATH, store);
    }
    return store;
}

function saveLineSourceIndex(store) {
    store = store || defaultLineSourceIndex();
    store.version = 1;
    if (!Array.isArray(store.sources)) store.sources = [];
    writeJson(LINE_SOURCE_INDEX_PATH, store);
    return store;
}

function getAllSourceRecords() {
    return getIndex().sources.concat(getLineSourceIndex().sources);
}

function getUserSources() {
    return getIndex().sources;
}

function findSourceRecord(sourceId) {
    var id = String(sourceId || "");
    var user = getIndex();
    var userIndex = user.sources.findIndex(function(source) { return String(source.id) === id; });
    if (userIndex >= 0) return {store: "user", index: user, position: userIndex, source: user.sources[userIndex]};
    var line = getLineSourceIndex();
    var lineIndex = line.sources.findIndex(function(source) { return String(source.id) === id; });
    if (lineIndex >= 0) return {store: "line", index: line, position: lineIndex, source: line.sources[lineIndex]};
    return null;
}

function saveSourceRecord(record) {
    if (!record) return;
    if (record.store === "line") saveLineSourceIndex(record.index);
    else saveIndex(record.index);
}

function getActiveSourceId() {
    var active = readJson(ACTIVE_SOURCE_PATH, {version: 1, sourceId: ""});
    if (active && active.sourceId) return String(active.sourceId);
    var line = getLineSourceIndex();
    if (line.current && line.sources.some(function(source) { return source.id === line.current; })) return String(line.current);
    return String(getIndex().current || "");
}

function setActiveSourceId(sourceId) {
    writeJson(ACTIVE_SOURCE_PATH, {version: 1, sourceId: String(sourceId || "")});
}

function getIndex() {
    migrateLegacyLineSources();
    var existed = fileExist(INDEX_PATH);
    var index = readJson(INDEX_PATH, defaultIndex());
    var changed = false;
    if (!Array.isArray(index.sources)) index.sources = [];
    index.sources = index.sources.map(function(source) {
        if (!source || !source.path) return source;
        var oldPrefix = BUNDLED_SOURCE_ROOT + "/";
        if (!source.builtIn && startsWith(String(source.path), oldPrefix) && fileExist(source.path)) {
            var target = SOURCE_ROOT + "/" + String(source.path).split("/").pop();
            if (!fileExist(target)) writeFile(target, request(source.path));
            source.path = target;
            changed = true;
        }
        return source;
    });
    var beforeFilter = index.sources.length;
    index.sources = index.sources.filter(function(source) {
        return sourcePathIsAvailable(source) && !source.lineId;
    });
    if (index.sources.length !== beforeFilter) changed = true;
    if (!index.sources.some(function(source) { return source.id === index.current; })) {
        index.current = index.sources.length ? index.sources[0].id : "";
        changed = true;
    }
    if (index.version !== 4) {
        index.version = 4;
        changed = true;
    }
    if (!existed || changed) writeJson(INDEX_PATH, index);
    return index;
}

function saveIndex(index) {
    index = index || defaultIndex();
    index.version = 4;
    if (!Array.isArray(index.sources)) index.sources = [];
    index.sources = index.sources.filter(function(source) { return source && !source.lineId; });
    writeJson(INDEX_PATH, index);
}

function sourceNameCompare(left, right) {
    left = String(left || "").trim();
    right = String(right || "").trim();
    if (left === right) return 0;
    try {
        return left.localeCompare(right, "zh-CN", {numeric: true, sensitivity: "base"});
    } catch (ignoreLocaleCompareError) {
        var leftLower = left.toLowerCase();
        var rightLower = right.toLowerCase();
        return leftLower < rightLower ? -1 : 1;
    }
}

function sortSources(mode) {
    mode = String(mode || "");
    if (mode !== "time_desc" && mode !== "name") throw new Error("不支持的排序方式");
    var index = getIndex();
    var decorated = index.sources.map(function(source, position) {
        return {source: source, position: position};
    });
    decorated.sort(function(left, right) {
        if (mode === "time_desc") {
            var leftTime = Number(left.source.importedAt || 0);
            var rightTime = Number(right.source.importedAt || 0);
            if (leftTime !== rightTime) return rightTime - leftTime;
        } else {
            var nameOrder = sourceNameCompare(left.source.name || left.source.fileName, right.source.name || right.source.fileName);
            if (nameOrder !== 0) return nameOrder;
        }
        return left.position - right.position;
    });
    index.sources = decorated.map(function(item) { return item.source; });
    saveIndex(index);
    return clone(index.sources);
}

// 手动排序：在 user/line 任一 store 内把指定源移动（top/up/down/bottom）。
// 支持 PY 源（py_sources.json）与线路源（line_sources.json），与直播源的
// moveLiveSource 语义一致；列表顺序即首页源选择、源管理的显示顺序。
function moveSource(sourceId, direction) {
    var id = String(sourceId || "");
    var mode = String(direction || "");
    if (["top", "up", "down", "bottom"].indexOf(mode) < 0) throw new Error("不支持的移动方式");
    var record = findSourceRecord(id);
    if (!record) throw new Error("视频源不存在");
    var list = record.index.sources;
    var position = Number(record.position);
    var target = position;
    if (mode === "top") target = 0;
    else if (mode === "up") target = Math.max(0, position - 1);
    else if (mode === "down") target = Math.min(list.length - 1, position + 1);
    else if (mode === "bottom") target = list.length - 1;
    if (target !== position) {
        var source = list.splice(position, 1)[0];
        list.splice(target, 0, source);
        if (record.store === "line") saveLineSourceIndex(record.index);
        else saveIndex(record.index);
    }
    return clone(list);
}

function listSources() {
    return getAllSourceRecords();
}

function listUserSources() {
    return getUserSources();
}

function getSource(sourceId) {
    var id = sourceId || getActiveSourceId();
    var record = findSourceRecord(id);
    if (!record) throw new Error("还没有可用的视频源");
    return record.source;
}

function getCurrentSource() {
    var records = getAllSourceRecords();
    var activeId = getActiveSourceId();
    var source = records.find(function(item) { return item.id === activeId && isSourceEnabled(item); });
    if (source) return source;
    var firstEnabled = records.find(isSourceEnabled);
    if (!firstEnabled) throw new Error("还没有可用的视频源");
    setActiveSourceId(firstEnabled.id);
    return firstEnabled;
}

function getSourceSelection(mode) {
    var requested = String(mode || "active").toLowerCase();
    var active = null;
    try { active = getCurrentSource(); } catch (ignoreCurrentSourceError) {}
    var scope = requested === "active" ? (active && active.lineId ? "line" : "py") : requested;
    if (scope === "line") {
        var lineStore = getLineSourceIndex();
        var lineId = active && active.lineId ? String(active.lineId) : String(getConfigIndex().current || "");
        var lineSources = lineStore.sources.filter(function(source) {
            return isSourceEnabled(source) && (!lineId || String(source.lineId || "") === lineId);
        });
        var lineCurrent = active && lineSources.some(function(source) { return source.id === active.id; })
            ? String(active.id)
            : (lineSources.some(function(source) { return source.id === lineStore.current; })
                ? String(lineStore.current)
                : (lineSources[0] ? String(lineSources[0].id) : ""));
        return {mode: "line", lineId: lineId, current: lineCurrent, sources: lineSources};
    }
    var pyStore = getIndex();
    var pyCurrent = active && !active.lineId && pyStore.sources.some(function(source) { return source.id === active.id; })
        ? String(active.id)
        : String(pyStore.current || "");
    return {
        mode: "py",
        lineId: "",
        current: pyCurrent,
        sources: pyStore.sources.filter(isSourceEnabled)
    };
}

function setCurrentSource(sourceId) {
    var record = findSourceRecord(sourceId);
    if (!record || !isSourceEnabled(record.source)) throw new Error("视频源不存在或已禁用");
    record.index.current = record.source.id;
    saveSourceRecord(record);
    setActiveSourceId(record.source.id);
    // 切源统一回到目标源的首次首页，并让旧标签请求立即失效。
    var categoryStateKey = "py_home_category_" + String(record.source.id);
    try { putMyVar(categoryStateKey, ""); } catch (ignoreResetCategoryStateError) {}
    try { putMyVar(categoryStateKey + "_request", "source_switch_" + Date.now()); } catch (ignoreResetCategoryRequestError) {}
    return record.source;
}

function renameSource(sourceId, displayName) {
    var name = String(displayName || "").replace(/\s+/g, " ").trim();
    var record = findSourceRecord(sourceId);
    if (!record) throw new Error("视频源不存在");
    var source = record.source;
    if (!name) {
        if (!source.originalName) throw new Error("名称不能为空");
        source.name = String(source.originalName);
        delete source.customName;
        saveSourceRecord(record);
        return clone(source);
    }
    if (name.length > 80) throw new Error("名称不能超过 80 个字符");
    if (!source.originalName) source.originalName = String(source.name || source.fileName || source.id);
    source.customName = name;
    source.name = name;
    saveSourceRecord(record);
    return clone(source);
}

// 仅返回启用的源（供首页切换列表使用）
function listEnabledSources() {
    return getIndex().sources.filter(isSourceEnabled);
}

function localFilePath(path) {
    var value = String(path || "");
    try {
        if (startsWith(value, "hiker://")) value = String(getPath(value));
    } catch (ignoreGetPathError) {}
    if (startsWith(value, "file://")) value = value.slice(7);
    return value;
}

function readJavaText(path) {
    var input = new java.io.FileInputStream(localFilePath(path));
    var output = new java.io.ByteArrayOutputStream();
    var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
    try {
        var length;
        while ((length = input.read(buffer)) !== -1) {
            if (length > 0) output.write(buffer, 0, length);
        }
    } finally {
        input.close();
    }
    return String(new java.lang.String(output.toByteArray(), "UTF-8"));
}

function readLocalText(path) {
    try {
        var fileText = readFile(path);
        if (fileText !== undefined && fileText !== null && String(fileText) !== "") return String(fileText);
    } catch (ignoreReadFileError) {}
    try {
        var javaText = readJavaText(path);
        if (javaText !== undefined && javaText !== null && String(javaText) !== "") return String(javaText);
    } catch (ignoreJavaReadError) {}
    return request(path);
}

function loadLocalModule(path, forceReload) {
    try {
        return $.require(path, forceReload);
    } catch (requireError) {
        var previousExports = $.exports;
        var loaded = null;
        try {
            $.exports = {};
            var sourceText = "";
            try { sourceText = String(readFile(path) || ""); } catch (ignoreModuleReadFileError) {}
            if (!sourceText) {
                var modulePath = String(path || "");
                try {
                    if (startsWith(modulePath, "hiker://")) modulePath = String(getPath(modulePath));
                } catch (ignoreModuleGetPathError) {}
                if (startsWith(modulePath, "file://")) modulePath = modulePath.slice(7);
                try {
                    var moduleInput = new java.io.FileInputStream(modulePath);
                    var moduleOutput = new java.io.ByteArrayOutputStream();
                    var moduleBuffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
                    try {
                        var moduleLength;
                        while ((moduleLength = moduleInput.read(moduleBuffer)) !== -1) {
                            if (moduleLength > 0) moduleOutput.write(moduleBuffer, 0, moduleLength);
                        }
                    } finally {
                        moduleInput.close();
                    }
                    sourceText = String(new java.lang.String(moduleOutput.toByteArray(), "UTF-8"));
                } catch (ignoreModuleJavaReadError) {}
            }
            if (!sourceText) sourceText = request(path);
            eval(sourceText);
            loaded = $.exports;
        } catch (evalError) {
            throw new Error("load " + path + ": " + errorText(evalError));
        } finally {
            $.exports = previousExports;
        }
        if (!loaded) throw requireError;
        return loaded;
    }
}

function globalRuntimeSlot() {
    // 主页面与本地代理线程共享进程；把已初始化的 PythonHiker 模块挂到
    // 全局槽位，代理线程直接复用，避免无规则上下文重新 initChaquopy。
    // 多通道：Rhino 不同版本/线程可能只暴露其中某一个。
    try {
        if (typeof globalThis !== "undefined" && globalThis) return globalThis;
    } catch (ignoreGlobalThisError) {}
    try {
        if (typeof window !== "undefined" && window) return window;
    } catch (ignoreWindowError) {}
    try {
        if (typeof top !== "undefined" && top) return top;
    } catch (ignoreTopError) {}
    return null;
}

function writeRuntimeSlot(runtimeModule) {
    var value = {version: BUILD_VERSION, module: runtimeModule};
    var slots = [];
    try { if (typeof globalThis !== "undefined" && globalThis) slots.push(globalThis); } catch (ignoreGlobalThisWriteError) {}
    try { if (typeof window !== "undefined" && window) slots.push(window); } catch (ignoreWindowWriteError) {}
    try { if (typeof top !== "undefined" && top) slots.push(top); } catch (ignoreTopWriteError) {}
    for (var index = 0; index < slots.length; index++) {
        try { slots[index].__pyRuntimeModule = value; } catch (ignoreSlotWriteError) {}
    }
}

function writeCoreSlot(coreModule) {
    var value = {version: BUILD_VERSION, module: coreModule};
    var slots = [];
    try { if (typeof globalThis !== "undefined" && globalThis) slots.push(globalThis); } catch (ignoreCoreGlobalThisWriteError) {}
    try { if (typeof window !== "undefined" && window) slots.push(window); } catch (ignoreCoreWindowWriteError) {}
    try { if (typeof top !== "undefined" && top) slots.push(top); } catch (ignoreCoreTopWriteError) {}
    for (var index = 0; index < slots.length; index++) {
        try { slots[index].__pyCoreModule = value; } catch (ignoreCoreSlotWriteError) {}
    }
}

function runtimeMatchesBuild(candidate) {
    if (!candidate || String(candidate.__buildVersion || candidate.BUILD_VERSION || "") !== BUILD_VERSION) return false;
    var required = [
        "runPy", "instantiateSpider", "callFuncCompatible", "syncAndroidProxy", "unloadPy",
        "clearPyModules", "getSourceCacheStats", "getRuntimeObject", "putRuntimeObject",
        "clearRuntimeObjects"
    ];
    for (var index = 0; index < required.length; index++) {
        if (typeof candidate[required[index]] !== "function") return false;
    }
    return true;
}

function getRuntime() {
    if (!fileExist(RUNTIME_PATH)) throw new Error("缺少 Python 运行时: " + RUNTIME_PATH);
    if (!runtimeModule) {
        var slot = globalRuntimeSlot();
        if (slot) {
            try {
                var entry = slot.__pyRuntimeModule;
                if (entry && String(entry.version || "") === BUILD_VERSION && runtimeMatchesBuild(entry.module)) {
                    runtimeModule = entry.module;
                }
            } catch (ignoreSlotReadError) {}
        }
    }
    if (!runtimeModule) {
        var runtimeLoadPath = RUNTIME_PATH;
        try { runtimeLoadPath = String(getPath(RUNTIME_PATH)); } catch (ignoreRuntimeGetPathError) {}
        if (runtimeLoadPath === RUNTIME_PATH || startsWith(runtimeLoadPath, "hiker://")) {
            try {
                var activity = typeof getCurrentActivity === "function" ? getCurrentActivity() : null;
                var external = activity && activity.getExternalFilesDir ? activity.getExternalFilesDir(null) : null;
                if (external) runtimeLoadPath = String(external.getAbsolutePath()) + "/Documents/" + RUNTIME_PATH.slice("hiker://files/".length);
            } catch (ignoreRuntimeExternalPathError) {}
        }
        // 代理线程没有当前规则：强制重载会重新 initChaquopy 并因“获取规则失败”
        // 抛错。此时走 $.require 缓存（force=false），复用主页面已初始化并
        // 启动 Chaquopy 的 PythonHiker 模块对象。
        // 判别依据：MY_PARAMS 仅在 startProxyServer 回调（代理线程）存在，
        // 主页面页面脚本里没有；MY_RULE 可能因带 ?rule= 的 require 被注入，不可靠。
        var proxyThread = typeof MY_PARAMS !== "undefined" && MY_PARAMS !== null;
        try {
            runtimeModule = loadLocalModule(runtimeLoadPath, !proxyThread);
            if (!runtimeMatchesBuild(runtimeModule) && proxyThread) {
                runtimeModule = loadLocalModule(runtimeLoadPath, true);
            }
        } catch (runtimeLoadError) {
            if (!proxyThread) throw runtimeLoadError;
            // 缓存未命中（主页面尚未加载过运行时）时，兜底强制加载；
            // 若仍失败则保持原错误，由调用方降级处理。
            try {
                runtimeModule = loadLocalModule(runtimeLoadPath, true);
            } catch (ignoreRuntimeFallbackError) {
                throw runtimeLoadError;
            }
        }
        if (!runtimeMatchesBuild(runtimeModule)) {
            throw new Error("Python 运行时版本不一致: expected=" + BUILD_VERSION);
        }
        writeRuntimeSlot(runtimeModule);
    }
    if (!runtimeMatchesBuild(runtimeModule)) {
        throw new Error("Python 运行时版本不一致: expected=" + BUILD_VERSION);
    }
    if (Date.now() - lastRuntimeProxySyncAt >= 5000) {
        try {
            runtimeModule.syncAndroidProxy();
            lastRuntimeProxySyncAt = Date.now();
        } catch (ignoreProxySyncError) {}
    }
    return runtimeModule;
}

function firstParam(value) {
    return Array.isArray(value) ? value[0] : value;
}

function proxyImageMagic(body) {
    var bytes = body;
    try {
        if (body && body.getClass && body.getClass().isArray && body.getClass().isArray()) {
            var component = body.getClass().getComponentType();
            if (component && String(component.getName()) === "byte") bytes = body;
        }
    } catch (ignoreProxyBodyClassError) {}
    if (!bytes || typeof bytes.length !== "number") return "";
    function at(index) { return Number(bytes[index]) & 255; }
    function starts(signature) {
        if (bytes.length < signature.length) return false;
        for (var index = 0; index < signature.length; index++) {
            if (at(index) !== signature[index]) return false;
        }
        return true;
    }
    function ascii(start, count) {
        var text = "";
        for (var index = start; index < start + count && index < bytes.length; index++) {
            text += String.fromCharCode(at(index));
        }
        return text;
    }
    if (starts([255, 216, 255])) return "image/jpeg";
    if (starts([137, 80, 78, 71, 13, 10, 26, 10])) return "image/png";
    if (ascii(0, 4) === "GIF8") return "image/gif";
    if (ascii(0, 4) === "RIFF" && ascii(8, 4) === "WEBP") return "image/webp";
    if (starts([66, 77])) return "image/bmp";
    if (starts([73, 73, 42, 0]) || starts([77, 77, 0, 42])) return "image/tiff";
    if (ascii(4, 4) === "ftyp") {
        var brand = ascii(8, 4).toLowerCase();
        if (["avif", "avis"].indexOf(brand) >= 0) return "image/avif";
        if (["heic", "heix", "mif1", "msf1"].indexOf(brand) >= 0) return "image/heic";
    }
    return "";
}

function bhDataUrlDecode(body) {
    // 笔盒等源的加密图：字节流 = gzip(可选) → XOR(key=18) → "data:image/...;base64,..." 文本。
    // 与 PY 源 localProxy 的 decrypt 管线对齐（见笔盒源 _IMG_XOR_KEY = 18）。
    // 内存优化：全程 byte[] 操作，不转 String（base64 文本可能数 MB，转 UTF-16 String
    // 会翻倍内存，列表页并发解码时直接 OOM）。
    if (!body || !body.length) return null;
    // 关键：必须在副本上操作！原始 body 可能是 AES 密文（51爆料等直连图），
    // 若 XOR 原地修改后找不到 data: 标记返回 null，调用方会用被破坏的数据
    // 继续 autoDecodeImageBytes，导致解密失败灰图。
    var bytes = java.util.Arrays.copyOf(body, Number(body.length || 0));
    try {
        if (bytes.length >= 2 && (Number(bytes[0]) & 255) === 31 && (Number(bytes[1]) & 255) === 139) {
            var gz = new java.util.zip.GZIPInputStream(new java.io.ByteArrayInputStream(bytes));
            var out = new java.io.ByteArrayOutputStream();
            var buf = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
            var n;
            while ((n = gz.read(buf)) !== -1) {
                if (n > 0) out.write(buf, 0, n);
            }
            gz.close();
            bytes = out.toByteArray();
        }
        // XOR 前 4096 字节（与 PY 源 decrypt 一致）。注意 Java byte 有符号，
        // 必须 & 255 取无符号值再异或，否则加密字节 0xC3 会被读成 -61。
        var limit = Math.min(Number(bytes.length || 0), 4096);
        for (var i = 0; i < limit; i++) {
            bytes[i] = (Number(bytes[i]) & 255) ^ 18;
        }
        // 直接在 byte[] 中定位 "base64," 分隔符，避免 String 转换
        var total = Number(bytes.length || 0);
        var marker = "base64,";
        var markerBytes = [];
        for (var m = 0; m < marker.length; m++) markerBytes.push(marker.charCodeAt(m) & 255);
        var b64Start = -1;
        for (var j = 0; j <= total - markerBytes.length; j++) {
            var matched = true;
            for (var k = 0; k < markerBytes.length; k++) {
                if ((Number(bytes[j + k]) & 255) !== markerBytes[k]) { matched = false; break; }
            }
            if (matched) { b64Start = j + markerBytes.length; break; }
        }
        if (b64Start < 0) return null;
        // 去掉 base64 中的空白字节（换行等），原地压缩
        var b64Len = 0;
        for (var p = b64Start; p < total; p++) {
            var c = Number(bytes[p]) & 255;
            if (c !== 10 && c !== 13 && c !== 32 && c !== 9) bytes[b64Start + b64Len++] = bytes[p];
        }
        if (b64Len < 8) return null;
        // Rhino 对 decode(byte[], int, int) 重载调用可能失败，先用 copyOfRange
        // 切出干净片段再 decode(byte[])，避免重载歧义。
        var slice = java.util.Arrays.copyOfRange(bytes, b64Start, b64Start + b64Len);
        var decoded = android.util.Base64.decode(slice, android.util.Base64.DEFAULT);
        return decoded && decoded.length ? decoded : null;
    } catch (ignoreBhDataUrlError) {
        return null;
    }
}

function autoDecodeImageBytes(body) {
    if (!body || proxyImageMagic(body) || Number(body.length || 0) < 16 || Number(body.length || 0) % 16 !== 0) return body;
    for (var index = 0; index < AUTO_IMAGE_CIPHERS.length; index++) {
        var profile = AUTO_IMAGE_CIPHERS[index];
        try {
            var cipher = javax.crypto.Cipher.getInstance(profile.transformation);
            var key = new javax.crypto.spec.SecretKeySpec(new java.lang.String(profile.key).getBytes("UTF-8"), "AES");
            if (/\/ECB\//i.test(profile.transformation)) {
                cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key);
            } else {
                var iv = new javax.crypto.spec.IvParameterSpec(new java.lang.String(profile.iv).getBytes("UTF-8"));
                cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key, iv);
            }
            var decoded = cipher.doFinal(body);
            if (proxyImageMagic(decoded)) return decoded;
        } catch (ignoreAutoImageCipherError) {}
    }
    return body;
}

function proxyBodyIsEmpty(body) {
    try {
        if (body && body.getClass && body.getClass().isArray && body.getClass().isArray()) {
            return Number(body.length || 0) === 0;
        }
    } catch (ignoreProxyBodyLengthError) {}
    return typeof body === "string" && body.trim() === "";
}

function proxyBodyLooksLikeError(body) {
    try {
        if (body && body.getClass && String(body.getClass().getName()) === "java.lang.String") body = String(body);
    } catch (ignoreProxyBodyStringError) {}
    try {
        if (body && body.getClass && body.getClass().isArray && body.getClass().isArray()) {
            var component = body.getClass().getComponentType();
            if (component && String(component.getName()) === "byte") {
                var preview = "";
                var count = Math.min(Number(body.length || 0), 512);
                for (var index = 0; index < count; index++) {
                    var code = Number(body[index]) & 255;
                    preview += String.fromCharCode(code >= 32 && code < 127 ? code : 32);
                }
                body = preview;
            }
        }
    } catch (ignoreProxyBodyPreviewError) {}
    if (typeof body !== "string") return false;
    var text = body.replace(/^\uFEFF/, "").trim().slice(0, 512).toLowerCase();
    if (!text) return true;
    return text.indexOf("<!doctype") === 0 || text.indexOf("<html") === 0 ||
        text.indexOf("<body") === 0 || text.indexOf("py_proxy_error[") === 0 ||
        text.indexOf("not found") === 0 || text.indexOf("error:") === 0 ||
        text[0] === "{" || text[0] === "[";
}

function decodeProxyImageUrl(value) {
    var text = String(value || "").trim();
    try { text = decodeURIComponent(text); } catch (ignoreProxyUrlDecodeError) {}
    if (/^https?:\/\//i.test(text)) return text;
    try {
        var urlSafe = /[-_]/.test(text);
        var decoded = new java.lang.String(
            android.util.Base64.decode(String(text), urlSafe ? android.util.Base64.URL_SAFE : android.util.Base64.DEFAULT),
            "UTF-8"
        );
        decoded = String(decoded).trim();
        return /^https?:\/\//i.test(decoded) ? decoded : "";
    } catch (ignoreProxyBase64Error) {
        return "";
    }
}

function directProxyImageFallback(sourceId, params) {
    if (typeof fetch !== "function") return null;
    params = params || {};
    var candidate = decodeProxyImageUrl(params.url || params.u || params.uri || "");
    if (!candidate) return null;
    try {
        var headers = sourceImageHeaders(sourceId, candidate);
        var hex = fetch(candidate, {headers: headers || {}, timeout: 15000, toHex: true});
        if (typeof hex !== "string" || !/^[0-9a-f]+$/i.test(hex) || hex.length < 8) return null;
        var body = hexToBytes(hex);
        var mime = proxyImageMagic(body);
        if (!mime) return null;
        return [200, mime, body];
    } catch (ignoreDirectImageFallbackError) {
        return null;
    }
}

function insecureSslContext() {
    // 图片 CDN 常使用不被系统信任的自签/私有 CA 证书；PY 侧 requests 用
    // verify=False 直连成功，这里等价地信任任意证书，避免 SSLHandshakeException。
    try {
        var trustManager = new javax.net.ssl.X509TrustManager({
            checkClientTrusted: function(chain, authType) {},
            checkServerTrusted: function(chain, authType) {},
            getAcceptedIssuers: function() { return new Array(0); }
        });
        var context = javax.net.ssl.SSLContext.getInstance("TLS");
        context.init(null, [trustManager], new java.security.SecureRandom());
        return context;
    } catch (ignoreSslContextError) {
        return null;
    }
}

function applyInsecureSsl(connection) {
    // HttpsURLConnection 专用：信任任意证书 + 关闭主机名校验，与 Python verify=False 对齐
    try {
        var className = String(connection.getClass().getName());
        if (className.indexOf("HttpsURLConnection") < 0 && !(connection instanceof javax.net.ssl.HttpsURLConnection)) return;
        var context = insecureSslContext();
        if (!context) return;
        if (connection.setSSLSocketFactory) connection.setSSLSocketFactory(context.getSocketFactory());
        if (connection.setHostnameVerifier) {
            connection.setHostnameVerifier(new javax.net.ssl.HostnameVerifier({
                verify: function(hostname, session) { return true; }
            }));
        }
    } catch (ignoreInsecureSslError) {}
}

function directImageFallbackParams(params, headers, target) {
    var fallback = String((params || {}).__img_fallback || "").trim();
    if (!/^https?:\/\//i.test(fallback) || fallback === String(target || "")) return null;
    var next = {};
    Object.keys(params || {}).forEach(function(key) { next[key] = params[key]; });
    var nextHeaders = {};
    Object.keys(headers || {}).forEach(function(key) {
        if (String(key).toLowerCase() !== "host") nextHeaders[key] = headers[key];
    });
    next.__direct_img = fallback;
    next.__img_headers = JSON.stringify(nextHeaders);
    next.__img_fallback = "";
    next.__img_route = "";
    return next;
}

function fetchDirectProxyImage(params) {
    params = params || {};
    var target = String(params.__direct_img || "").trim();
    if (!/^https?:\/\//i.test(target)) return [400, "text/plain; charset=utf-8", "Invalid direct image URL"];
    var headers = {};
    try { headers = JSON.parse(String(params.__img_headers || "{}")); } catch (ignoreDirectHeaderJsonError) {}
    var connection = null;
    var inputStream = null;
    try {
        connection = new java.net.URL(target).openConnection();
        applyInsecureSsl(connection);
        var routedRequest = String(params.__img_route || "") === "1";
        connection.setConnectTimeout(routedRequest ? 5000 : 15000);
        connection.setReadTimeout(routedRequest ? 8000 : 20000);
        if (connection.setInstanceFollowRedirects) connection.setInstanceFollowRedirects(true);
        Object.keys(headers || {}).forEach(function(key) {
            var value = headers[key];
            if (value !== undefined && value !== null && String(value) !== "") {
                try { connection.setRequestProperty(String(key), String(value)); } catch (ignoreDirectHeaderError) {}
            }
        });
        var status = connection.getResponseCode ? Number(connection.getResponseCode()) : 200;
        inputStream = status >= 400 && connection.getErrorStream ? connection.getErrorStream() : connection.getInputStream();
        if (!inputStream) {
            var emptyFallback = directImageFallbackParams(params, headers, target);
            if (emptyFallback) return fetchDirectProxyImage(emptyFallback);
            return [status || 502, "text/plain; charset=utf-8", "Empty direct image response"];
        }
        var output = new java.io.ByteArrayOutputStream();
        var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
        var length;
        while ((length = inputStream.read(buffer)) !== -1) {
            if (length > 0) output.write(buffer, 0, length);
            // 防御：单张图片原始字节超过 64MB 直接放弃，避免 OOM
            if (output.size() > 64 * 1024 * 1024) {
                try { if (inputStream) inputStream.close(); } catch (ignoreDirectInputCloseError) {}
                return [502, "text/plain; charset=utf-8", "DIRECT_IMAGE_TOO_LARGE: >64MB"];
            }
        }
        var body = output.toByteArray();
        if (body && body.length >= 2 && (Number(body[0]) & 255) === 31 && (Number(body[1]) & 255) === 139) {
            try {
                var gzip = new java.util.zip.GZIPInputStream(new java.io.ByteArrayInputStream(body));
                var unzipped = new java.io.ByteArrayOutputStream();
                while ((length = gzip.read(buffer)) !== -1) {
                    if (length > 0) unzipped.write(buffer, 0, length);
                    if (unzipped.size() > 128 * 1024 * 1024) {
                        try { gzip.close(); } catch (ignoreDirectGzipCloseError) {}
                        return [502, "text/plain; charset=utf-8", "DIRECT_IMAGE_TOO_LARGE: unzip>128MB"];
                    }
                }
                gzip.close();
                body = unzipped.toByteArray();
            } catch (ignoreDirectGzipError) {}
        }
        // 笔盒等源：加密图以 data:URL 文本形式存储（gzip→XOR→base64），先尝试
        // data URL 解码，再走内置 AES 解密（autoDecodeImageBytes）。
        var bhDecoded = bhDataUrlDecode(body);
        if (bhDecoded) body = bhDecoded;
        else body = autoDecodeImageBytes(body);
        var detected = proxyImageMagic(body);
        if (status >= 200 && status < 300 && detected) return [status, detected, body];
        var head = "";
        for (var index = 0; index < Math.min(Number(body && body.length || 0), 32); index++) {
            var hex = (Number(body[index]) & 255).toString(16);
            head += hex.length < 2 ? "0" + hex : hex;
        }
        var upstreamType = "";
        try { upstreamType = String(connection.getContentType() || ""); } catch (ignoreDirectContentTypeError) {}
        var networkFallback = directImageFallbackParams(params, headers, target);
        if (networkFallback) return fetchDirectProxyImage(networkFallback);
        return [status >= 200 && status < 300 ? 502 : status, "text/plain; charset=utf-8",
            "Direct image returned non-image bytes: status=" + status +
            ", type=" + upstreamType + ", length=" + Number(body && body.length || 0) +
            ", head=" + head + ", url=" + target];
    } catch (directImageError) {
        var errorFallback = directImageFallbackParams(params, headers, target);
        if (errorFallback) return fetchDirectProxyImage(errorFallback);
        return [502, "text/plain; charset=utf-8", "DIRECT_IMAGE_ERROR: " + errorText(directImageError)];
    } finally {
        try { if (inputStream) inputStream.close(); } catch (ignoreDirectInputCloseError) {}
        try { if (connection && connection.disconnect) connection.disconnect(); } catch (ignoreDirectDisconnectError) {}
    }
}

function directImageProxyUrl(sourceId, target, headers, fallbackTarget) {
    var value = sourceProxyRoot(sourceId) +
        "&type=image&__direct_img=" + encodeURIComponent(target) +
        "&__img_headers=" + encodeURIComponent(JSON.stringify(headers || {})) +
        (fallbackTarget ? "&__img_fallback=" + encodeURIComponent(fallbackTarget) + "&__img_route=1" : "") +
        "&pyproxy=" + IMAGE_PIPELINE_VERSION;
    return value.replace(/^https?:\/\/10\.0\.2\.15/i, "http://127.0.0.1");
}

function normalizeProxyBodyResult(result) {
    if (!Array.isArray(result) || result.length < 3) return result;
    var base64 = result.length > 4 && Number(result[4] || 0) === 1;
    if (!base64) return result;
    try {
        var text = String(result[2] === undefined || result[2] === null ? "" : result[2]).trim();
        var marker = text.toLowerCase().indexOf("base64,");
        if (marker >= 0) text = text.slice(marker + 7);
        text = text.replace(/\s+/g, "");
        result[2] = android.util.Base64.decode(String(text), android.util.Base64.DEFAULT);
    } catch (ignoreProxyBase64Error) {}
    return result;
}

function normalizeProxyImageResult(params, result) {
    result = normalizeProxyBodyResult(result);
    if (!Array.isArray(result) || result.length < 3) return result;
    var type = String((params || {}).type || "").toLowerCase();
    var operation = String((params || {}).do || "").toLowerCase();
    var isImageRequest = type === "img" || type === "image" || operation === "img" || operation === "image";
    if (!isImageRequest) return result;

    var status = Number(result[0] || 200);
    if (status < 200 || status >= 300) return result;
    var contentType = String(result[1] || "").split(";", 1)[0].toLowerCase();
    var body = result[2];
    var detected = proxyImageMagic(body);
    if (detected) {
        if (!/^image\//.test(contentType) || contentType === "image/octet-stream") result[1] = detected;
        return result;
    }
    if (proxyBodyIsEmpty(body) || proxyBodyLooksLikeError(body)) {
        return [502, "text/plain; charset=utf-8", "PY_IMAGE_ERROR: localProxy returned a non-image response"];
    }
    // 自定义 AES/XOR 解密源可能返回未知二进制，但仍标记为图片；保留原字节。
    if (!contentType || contentType === "application/octet-stream") result[1] = "image/jpeg";
    return result;
}

function forceLoopbackProxyHost(value) {
    var text = String(value || "");
    return text.replace(/^(https?:\/\/)(?:\[[^\]]+\]|[^\/:?#]+)(:\d+)(?=\/|\?|#|$)/i, "$1" + "127.0.0.1" + "$2");
}

function getLocalProxyUrl() {
    if (localProxyUrl) return localProxyUrl;
    localProxyUrl = forceLoopbackProxyHost(startProxyServer($.toString(function(ruleTitle, corePagePath, buildVersion) {
        var proxyStep = "start";
        try {
            var first = function(value) { return Array.isArray(value) ? value[0] : value; };
            var decode = function(value) {
                var text = String(first(value) || "");
                try { return decodeURIComponent(text); } catch (ignoreDecodeError) { return text; }
            };
            var sourceId = MY_PARAMS.source ? decode(MY_PARAMS.source) : "";
            var sourceProxyUrl = MY_PARAMS.__hiker_proxy ? decode(MY_PARAMS.__hiker_proxy) : "";
            var params = {};
            for (var key in MY_PARAMS) {
                if (key !== "source" && key !== "__hiker_proxy" && key !== "pyproxy") params[key] = decode(MY_PARAMS[key]);
            }
            // The proxy thread has no current rule, so page/module requires can
            // fail with "rule not found". 优先用带规则名的 require 拿到主页面已
            // 缓存的 py_core 模块（复用其 runtimeModule/instanceCache/Chaquopy），
            // 失败再直接执行本地安装的模块文件并保留回调原有导出对象。
            proxyStep = "load-core-source";
            var ruleName = String(ruleTitle || "PY影视壳");
            var core = null;
            var requireOk = false;
            var requireRuleOk = false;
            // 优先 require 与主线程相同的版本化核心模块实例，
            // 直接复用其已初始化的 runtimeModule/Chaquopy；带 ?rule= 会生成新实例。
            try {
                proxyStep = "require-core";
                var required = $.require(corePagePath, false);
                requireOk = !!(required && typeof required.callLocalProxy === "function");
                if (requireOk) {
                    core = required;
                }
            } catch (ignoreCoreRequireError) {}
            if (!core) {
                try {
                    proxyStep = "require-core-rule";
                    var requiredWithRule = $.require(corePagePath + "?rule=" + ruleName, false);
                    requireRuleOk = !!(requiredWithRule && typeof requiredWithRule.callLocalProxy === "function");
                    if (requireRuleOk) {
                        core = requiredWithRule;
                    }
                } catch (ignoreCoreRequireRuleError) {}
            }
            if (!core) {
                var corePath = "hiker://files/data/" + ruleName + "/subpage/py_core.js";
                var previousExports = $.exports;
                try {
                    proxyStep = "eval-core";
                    $.exports = {};
                    var coreText = "";
                    try { coreText = String(readFile(corePath) || ""); } catch (ignoreCoreReadFileError) {}
                    if (!coreText) {
                        var proxyCorePath = String(corePath);
                        try { proxyCorePath = String(getPath(proxyCorePath)); } catch (ignoreCoreGetPathError) {}
                        if (startsWith(proxyCorePath, "file://")) proxyCorePath = proxyCorePath.slice(7);
                        try {
                            var coreInput = new java.io.FileInputStream(proxyCorePath);
                            var coreOutput = new java.io.ByteArrayOutputStream();
                            var coreBuffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
                            try {
                                var coreLength;
                                while ((coreLength = coreInput.read(coreBuffer)) !== -1) {
                                    if (coreLength > 0) coreOutput.write(coreBuffer, 0, coreLength);
                                }
                            } finally {
                                coreInput.close();
                            }
                            coreText = String(new java.lang.String(coreOutput.toByteArray(), "UTF-8"));
                        } catch (ignoreCoreJavaReadError) {}
                    }
                    if (!coreText) coreText = request(corePath);
                    if (!coreText) throw new Error("PY 核心模块为空");
                    eval(coreText);
                    core = $.exports;
                } finally {
                    $.exports = previousExports;
                }
            }
            if (!core || typeof core.callLocalProxy !== "function") throw new Error("PY 核心模块加载失败");
            proxyStep = "call-local-proxy";
            var localProxyResult;
            if (params.__direct_img && core.fetchDirectProxyImage) {
                localProxyResult = core.fetchDirectProxyImage(params);
            } else {
                try {
                    localProxyResult = core.callLocalProxy(sourceId, params, sourceProxyUrl);
                } catch (localProxyError) {
                    var probe = {requireOk: requireOk, requireRuleOk: requireRuleOk};
                    try {
                        var ctxLoader = java.lang.Thread.currentThread().getContextClassLoader();
                        probe.ctxLoader = ctxLoader ? String(ctxLoader.getClass().getName()) : "null";
                        probe.ctxLoaderCanSee = ctxLoader ? !!java.lang.Class.forName("com.chaquo.python.Python", true, ctxLoader) : false;
                    } catch (ignoreProbeCtx) { probe.ctxLoader = "ERR: " + String(ignoreProbeCtx).slice(0, 120); }
                    localProxyResult = [502, "text/plain; charset=utf-8", "PY_PROXY_ERROR: " + (core.errorText ? core.errorText(localProxyError) : String(localProxyError)) + " | probe=" + JSON.stringify(probe)];
                }
            }
            localProxyResult = core.normalizeProxyBodyResult ? core.normalizeProxyBodyResult(localProxyResult) : localProxyResult;
            var result = core.normalizeProxyImageResult ? core.normalizeProxyImageResult(params, localProxyResult) : localProxyResult;
            var proxyType = String((params || {}).type || "").toLowerCase();
            var proxyOperation = String((params || {}).do || "").toLowerCase();
            if ((proxyType === "img" || proxyType === "image" || proxyOperation === "img" || proxyOperation === "image") && Number(result && result[0]) === 502) {
                var fallback = core.directProxyImageFallback ? core.directProxyImageFallback(sourceId, params) : null;
                if (fallback) result = fallback;
            }
            if (!Array.isArray(result) || result.length < 3) {
                return {
                    statusCode: 500,
                    body: "Invalid localProxy response",
                    headers: {"Content-Type": "text/plain; charset=utf-8"}
                };
            }
            var headers = {"Content-Type": result[1] || "application/octet-stream"};
            var blockedHeaders = {"connection": true, "keep-alive": true, "proxy-authenticate": true,
                "proxy-authorization": true, "te": true, "trailer": true, "transfer-encoding": true,
                "upgrade": true, "content-length": true, "content-encoding": true};
            Object.keys(result[3] || {}).forEach(function(headerName) {
                var lowerName = String(headerName || "").toLowerCase();
                if (!lowerName || lowerName === "content-type" || blockedHeaders[lowerName]) return;
                headers[headerName] = result[3][headerName];
            });
            var body = result[2];
            try {
                if (body && body.getClass && String(body.getClass().getName()) === "[B") {
                    body = new java.io.ByteArrayInputStream(body);
                }
            } catch (ignoreBinaryStreamError) {}
            return {statusCode: Number(result[0] || 200), body: body, headers: headers};
        } catch (error) {
            return {
                statusCode: 500,
                body: "PY_PROXY_ERROR[" + proxyStep + "]: " + (error && error.toString ? error.toString() : String(error)),
                headers: {"Content-Type": "text/plain; charset=utf-8"}
            };
        }
    }, RULE_TITLE, CORE_PAGE_PATH, BUILD_VERSION)));
    return localProxyUrl;
}

function sourceProxyRoot(sourceId) {
    var base = getLocalProxyUrl();
    var separator = base.indexOf("?") >= 0 ? "&" : "?";
    return base + separator + "source=" + encodeURIComponent(String(sourceId || ""));
}

function recursiveSourceProxyUrl(sourceId, rootOverride) {
    var root = String(rootOverride || sourceProxyRoot(sourceId));
    root = root.replace(/([?&])__hiker_proxy=[^&#]*&?/i, function(_, prefix) {
        return prefix === "?" ? "?" : "";
    }).replace(/[?&]$/, "");
    var separator = root.indexOf("?") >= 0 ? "&" : "?";
    return root + separator + "__hiker_proxy=" + encodeURIComponent(root);
}

function moduleName(source) {
    return "hiker_" + BUILD_VERSION + "_" + String(source.id).replace(/[^a-zA-Z0-9_]/g, "_");
}

function loadSpiderObject(source) {
    var runtime = getRuntime();
    var path = localFilePath(source.path);
    var module = runtime.runPy(path, moduleName(source), true);
    return runtime.instantiateSpider(module);
}

function localRuntimeStamp(path) {
    var localPath = String(path || "");
    try { localPath = localFilePath(localPath); } catch (ignoreLocalStampPathError) {}
    try {
        var file = new java.io.File(localPath);
        return String(file.lastModified() || 0) + ":" + String(file.length() || 0);
    } catch (ignoreLocalStampError) {
        return "0:0";
    }
}

function sourceRuntimeCacheKey(source) {
    var revision = [
        String(source && source.path || ""),
        String(source && source.ext || ""),
        localRuntimeStamp(source && source.path || "")
    ].join("@");
    return String(source && source.id || "") + "@spider@" + md5(revision);
}

function loadDependency(runtime, source, dependency) {
    var dependencyName = String(dependency || "");
    if (!dependencyName) return null;
    var dependencyPath = startsWith(dependencyName, "http") ? dependencyName : source.path.replace(/[^/]+$/, dependencyName + ".py");
    if (!startsWith(dependencyName, "http") && !fileExist(dependencyPath)) {
        var dependencyFileName = dependencyName.replace(/^.*[\\/]/, "") + ".py";
        var dependencySource = listSources().find(function(item) {
            return String(item.fileName || "").toLowerCase() === dependencyFileName.toLowerCase();
        });
        if (dependencySource) dependencyPath = dependencySource.path;
    }
    if (!startsWith(dependencyName, "http") && !fileExist(dependencyPath)) {
        throw new Error("缺少依赖文件: " + dependencyName + ".py");
    }
    var cacheKey = String(source.id || "") + "@dependency@" + md5(
        String(dependencyPath || "") + "@" + localRuntimeStamp(dependencyPath)
    );
    if (dependencyCache.has(cacheKey)) return dependencyCache.get(cacheKey);
    var sharedDependency = runtime.getRuntimeObject("dependency", cacheKey);
    if (sharedDependency) {
        dependencyCache.set(cacheKey, sharedDependency);
        return sharedDependency;
    }
    var modulePath = startsWith(dependencyPath, "http") ? dependencyPath : localFilePath(dependencyPath);
    var module = runtime.runPy(modulePath, moduleName(source) + "_dep_" + md5(dependencyPath).slice(0, 8), true);
    var instance = runtime.instantiateSpider(module);
    dependencyCache.set(cacheKey, instance);
    runtime.putRuntimeObject("dependency", cacheKey, instance);
    return instance;
}

function createSpider(source, proxyUrlOverride) {
    var cacheKey = sourceRuntimeCacheKey(source);
    if (instanceCache.has(cacheKey)) {
        var cachedSpider = instanceCache.get(cacheKey);
        try {
            cachedSpider.put("_HikerProxyUrl", proxyUrlOverride !== undefined
                ? String(proxyUrlOverride || "")
                : recursiveSourceProxyUrl(source.id));
        } catch (ignoreCachedProxyError) {}
        return cachedSpider;
    }
    var runtime = getRuntime();
    var sharedSpider = runtime.getRuntimeObject("spider", cacheKey);
    if (sharedSpider) {
        instanceCache.set(cacheKey, sharedSpider);
        try {
            sharedSpider.put("_HikerProxyUrl", proxyUrlOverride !== undefined
                ? String(proxyUrlOverride || "")
                : recursiveSourceProxyUrl(source.id));
        } catch (ignoreSharedProxyError) {}
        return sharedSpider;
    }
    var spider = loadSpiderObject(source);
    try {
        var proxyUrl = proxyUrlOverride !== undefined
            ? String(proxyUrlOverride || "")
            : recursiveSourceProxyUrl(source.id);
        spider.put("_HikerProxyUrl", proxyUrl);
    } catch (ignoreProxyError) {}
    try {
        runtime.callFunc(spider, "setExtendInfo", source.ext || "");
    } catch (ignoreExtendError) {}

    var modules = [];
    try {
        var dependencies = runtime.callFunc(spider, "getDependence") || [];
        for (var i = 0; i < dependencies.length; i++) {
            var dependency = loadDependency(runtime, source, dependencies[i]);
            if (dependency) modules.push(dependency);
        }
    } catch (ignoreDependencyError) {}

    var initCandidates = modules.length ? [[modules], [source.ext || ""], []] : [[source.ext || ""], [[]], []];
    try {
        runtime.callFuncCompatible(spider, ["init"], initCandidates);
    } catch (initError) {
        if (errorText(initError).indexOf("No compatible function") < 0) throw initError;
    }
    instanceCache.set(cacheKey, spider);
    runtime.putRuntimeObject("spider", cacheKey, spider);
    return spider;
}

function resetSourceRuntime(sourceId) {
    var sourceKey = String(sourceId || "");
    var prefix = sourceKey + "@";
    instanceCache.forEach(function(_, key) {
        if (startsWith(String(key), prefix)) instanceCache.delete(key);
    });
    dependencyCache.forEach(function(_, key) {
        if (startsWith(String(key), prefix)) dependencyCache.delete(key);
    });
    detailCache.forEach(function(_, key) {
        if (startsWith(String(key), prefix)) detailCache.delete(key);
    });
    genericListCache.forEach(function(_, key) {
        if (startsWith(String(key), prefix)) genericListCache.delete(key);
    });
    imageHeaderCache.delete(sourceKey);
    imageDecoderConfigCache.delete(sourceKey);
    warmHomeResultCache.delete(sourceKey);
    if (runtimeMatchesBuild(runtimeModule)) {
        try { runtimeModule.clearRuntimeObjects(prefix); } catch (ignoreRuntimeObjectClearError) {}
        try { runtimeModule.unloadPy(moduleName({id: sourceKey}), true); } catch (ignorePythonModuleUnloadError) {}
    }
    try { getExternalRuntime().clear(sourceId); } catch (ignoreExternalResetError) {}
    clearCategoryPrefetch(sourceId);
    clearHomeClasses(sourceId);
    clearHomeFilters(sourceId);
    clearVodRawForSource(sourceId);
    try { deleteFile(CATEGORY_PREFETCH_PATH); } catch (ignorePrefetchClearError) {}
}

// 切源轻量准备：只加载/初始化 Python 模块和 Spider，不访问源站网络。
// 源选择页可立即返回；主页先渲染控制栏，再执行唯一一次首页请求。
function prepareSource(sourceId) {
    var source = getSource(sourceId);
    if (isExternalSource(source)) return getExternalRuntime().prepare(source);
    createSpider(source);
    return {sourceId: source.id, sourceName: source.name || source.id};
}

// 兼容旧回调的缓存预热入口。这里只恢复已有首页缓存，不创建 Spider、
// 不初始化 Chaquopy，也不访问源站，避免切源点击阻塞 UI 线程。
function warmSource(sourceId) {
    var source = getSource(sourceId);
    var classes = [];
    var home = consumePrefetchedCategory(sourceId, "", "1", {}, CATEGORY_PREFETCH_STALE_TTL_MS);
    if (home) classes = Array.isArray(home.class) ? home.class : [];
    if (classes.length) cacheHomeClasses(sourceId, classes);
    if (home) {
        warmHomeResultCache.set(String(sourceId), {savedAt: Date.now(), result: clone(home)});
        if (home.filters && Object.keys(home.filters).length) {
            try { cacheHomeFilters(sourceId, home.filters); } catch (ignoreWarmHomeFiltersError) {}
        }
    }
    return {
        sourceId: source.id,
        sourceName: source.name || source.id,
        classes: classes.length,
        cached: !!home
    };
}

function consumeWarmHome(sourceId) {
    var key = String(sourceId || "");
    var entry = warmHomeResultCache.get(key);
    warmHomeResultCache.delete(key);
    if (!entry || Date.now() - Number(entry.savedAt || 0) > 30000) return null;
    return clone(entry.result || null);
}

function stableCacheString(value) {
    if (value === null || value === undefined) return "null";
    if (Array.isArray(value)) {
        return "[" + value.map(function(item) { return stableCacheString(item); }).join(",") + "]";
    }
    if (typeof value === "object") {
        return "{" + Object.keys(value).sort().map(function(key) {
            return JSON.stringify(String(key)) + ":" + stableCacheString(value[key]);
        }).join(",") + "}";
    }
    return JSON.stringify(value);
}

function categoryVariantKey(tid, extend) {
    return String(tid || "") + "@" + md5(stableCacheString(extend || {}));
}

function categoryPrefetchPrefix(sourceId) {
    return "category_prefetch_" + md5(String(sourceId || "")) + "_";
}

function categoryPrefetchPath(sourceId, tid, extend) {
    return DATA_ROOT + "/" + categoryPrefetchPrefix(sourceId) + md5(categoryVariantKey(tid, extend)) + ".json";
}

function categoryMemoryKey(sourceId, tid, page, extend) {
    return String(sourceId || "") + "@" + String(page || "1") + "@" + categoryVariantKey(tid, extend);
}

function pruneCategoryPrefetchCache() {
    var now = Date.now();
    if (now - lastCategoryPrefetchPruneAt < CATEGORY_PREFETCH_PRUNE_INTERVAL_MS) return;
    lastCategoryPrefetchPruneAt = now;
    try {
        var directory = new java.io.File(normalizeFolderPath(DATA_ROOT));
        var listed = directory.listFiles();
        if (!listed) return;
        var files = [];
        for (var index = 0; index < listed.length; index++) {
            var file = listed[index];
            var name = String(file.getName());
            if (startsWith(name, "category_prefetch_") && endsWith(name, ".json")) files.push(file);
        }
        files.sort(function(left, right) { return Number(right.lastModified()) - Number(left.lastModified()); });
        var keptBytes = 0;
        for (var position = 0; position < files.length; position++) {
            var current = files[position];
            var length = Number(current.length() || 0);
            var expired = now - Number(current.lastModified() || 0) > CATEGORY_PREFETCH_STALE_TTL_MS;
            var overLimit = position >= CATEGORY_PREFETCH_MAX_FILES || keptBytes + length > CATEGORY_PREFETCH_MAX_BYTES;
            if (expired || overLimit) {
                try { current.delete(); } catch (ignoreCategoryCacheFileDeleteError) {}
            } else {
                keptBytes += length;
            }
        }
    } catch (ignoreCategoryCachePruneError) {}
}

function savePrefetchedCategory(sourceId, tid, page, result, extend) {
    if (String(page || "1") !== "1") return false;
    result = result || {};
    if (!Array.isArray(result.list) || !result.list.length) return false;
    var snapshot = {};
    Object.keys(result).forEach(function(key) { snapshot[key] = result[key]; });
    snapshot.list = result.list.slice(0, CATEGORY_PREFETCH_MAX_ITEMS);
    var payload = {
        version: CATEGORY_PREFETCH_VERSION,
        sourceId: String(sourceId || ""),
        tid: String(tid || ""),
        variant: categoryVariantKey(tid, extend),
        page: "1",
        savedAt: Date.now(),
        result: snapshot
    };
    var encoded = JSON.stringify(payload);
    while (encoded.length > 512 * 1024 && snapshot.list.length > 12) {
        snapshot.list = snapshot.list.slice(0, Math.max(12, Math.floor(snapshot.list.length / 2)));
        encoded = JSON.stringify(payload);
    }
    if (encoded.length > 512 * 1024) return false;
    var memoryKey = categoryMemoryKey(sourceId, tid, page, extend);
    categoryResultMemoryCache.set(memoryKey, {savedAt: payload.savedAt, result: clone(snapshot)});
    writeFile(categoryPrefetchPath(sourceId, tid, extend), encoded);
    pruneCategoryPrefetchCache();
    return true;
}

function readPrefetchedCategory(sourceId, tid, page, maxAgeMs, extend) {
    var memoryKey = categoryMemoryKey(sourceId, tid, page, extend);
    var memoryEntry = categoryResultMemoryCache.get(memoryKey);
    if (memoryEntry && Date.now() - Number(memoryEntry.savedAt || 0) <= Number(maxAgeMs || 0)) {
        return clone(memoryEntry.result || {});
    }
    var path = categoryPrefetchPath(sourceId, tid, extend);
    if (String(page || "1") !== "1" || !fileExist(path)) return null;
    var entry = readJson(path, null);
    var structurallyValid = !!entry &&
        (Number(entry.version || 0) === CATEGORY_PREFETCH_VERSION || Number(entry.version || 0) === 3) &&
        String(entry.page || "") === "1" &&
        String(entry.sourceId || "") === String(sourceId || "") &&
        String(entry.tid || "") === String(tid || "") &&
        String(entry.variant || "") === categoryVariantKey(tid, extend) &&
        Number(entry.savedAt || 0) > 0 &&
        entry.result && Array.isArray(entry.result.list) && entry.result.list.length;
    if (!structurallyValid || Date.now() - Number(entry.savedAt || 0) > Number(maxAgeMs || 0)) {
        if (!structurallyValid || Date.now() - Number(entry.savedAt || 0) > CATEGORY_PREFETCH_STALE_TTL_MS) {
            try { deleteFile(path); } catch (ignorePrefetchDeleteError) {}
        }
        return null;
    }
    categoryResultMemoryCache.set(memoryKey, {savedAt: Number(entry.savedAt || 0), result: clone(entry.result || {})});
    return clone(entry.result || {});
}

function clearCategoryPrefetch(sourceId) {
    var sourceKey = String(sourceId || "");
    var memoryPrefix = sourceKey ? sourceKey + "@" : "";
    categoryResultMemoryCache.forEach(function(_, key) {
        if (!memoryPrefix || startsWith(String(key), memoryPrefix)) categoryResultMemoryCache.delete(key);
    });
    try {
        var directory = new java.io.File(normalizeFolderPath(DATA_ROOT));
        var listed = directory.listFiles();
        var filePrefix = sourceKey ? categoryPrefetchPrefix(sourceKey) : "category_prefetch_";
        for (var index = 0; listed && index < listed.length; index++) {
            var current = listed[index];
            var name = String(current.getName() || "");
            if (startsWith(name, filePrefix) && endsWith(name, ".json")) {
                try { current.delete(); } catch (ignoreCategoryPrefetchDeleteError) {}
            }
        }
    } catch (ignoreCategoryPrefetchScanError) {}
}

// 分类标签点击时先在旧页面中完成请求，再局部替换列表。
// 预取结果按 sourceId+tid 分文件，避免快速切换时后完成的请求覆盖另一标签。
function prefetchCategory(sourceId, tid, requestKey, requestToken) {
    var selectedTid = String(tid || "");
    var cacheTid = selectedTid;
    if (selectedTid) {
        var cachedHomeClasses = getHomeClasses(sourceId);
        var firstHomeTid = String(cachedHomeClasses[0] && cachedHomeClasses[0].type_id || "");
        if (firstHomeTid && firstHomeTid === selectedTid) cacheTid = "";
    }
    var cached = consumePrefetchedCategory(sourceId, cacheTid, "1", {});
    if (!cached && cacheTid !== selectedTid) cached = consumePrefetchedCategory(sourceId, selectedTid, "1", {});
    if (cached) return cached;
    var stale = readPrefetchedCategory(sourceId, cacheTid, "1", CATEGORY_PREFETCH_STALE_TTL_MS, {});
    if (!stale && cacheTid !== selectedTid) {
        stale = readPrefetchedCategory(sourceId, selectedTid, "1", CATEGORY_PREFETCH_STALE_TTL_MS, {});
    }
    var result;
    try {
        result = selectedTid
            ? categorySource(sourceId, selectedTid, "1", true, {})
            : homeSource(sourceId, true);
    } catch (liveCategoryError) {
        if (stale) return stale;
        throw liveCategoryError;
    }
    // 第一个标题代表首次进入时的真实首页。有些 PY（如色播聚合）
    // homeContent() 只返回分类树，列表实际由第一个 categoryContent()
    // 提供；从其他标签回点第一个标题时必须复用首次加载的回退链。
    if (!selectedTid && !normalizeVodList(result && result.list || []).length) {
        var homeClasses = Array.isArray(result && result.class) ? result.class : [];
        if (!homeClasses.length) homeClasses = getHomeClasses(sourceId);
        var firstTid = String(homeClasses[0] && homeClasses[0].type_id || "");
        if (firstTid) {
            var firstCategoryResult = categorySource(sourceId, firstTid, "1", true, {}) || {};
            if (normalizeVodList(firstCategoryResult.list || []).length) result = firstCategoryResult;
        }
    }
    var requestCurrent = !requestKey || String(getMyVar(requestKey, "")) === String(requestToken || "");
    // categorySource/homeSource already persist non-empty first pages. The
    // explicit save is only needed when the home fallback substituted the
    // first category result for the empty home route.
    if (requestCurrent && !selectedTid) savePrefetchedCategory(sourceId, selectedTid, "1", result, {});
    return clone(result || {});
}

function consumePrefetchedCategory(sourceId, tid, page, extend, maxAgeMs) {
    var ttl = Number(maxAgeMs || CATEGORY_PREFETCH_TTL_MS);
    if (!isFinite(ttl) || ttl <= 0) ttl = CATEGORY_PREFETCH_TTL_MS;
    return readPrefetchedCategory(sourceId, tid, page, ttl, extend || {});
}

function cachedCategorySource(sourceId, tid, page, filterable, extend) {
    var normalizedExtend = extend || {};
    var cached = consumePrefetchedCategory(sourceId, tid, page, normalizedExtend);
    if (cached) return cached;
    var stale = readPrefetchedCategory(sourceId, tid, page, CATEGORY_PREFETCH_STALE_TTL_MS, normalizedExtend);
    try {
        return categorySource(sourceId, tid, page, filterable, normalizedExtend);
    } catch (liveCategoryError) {
        if (stale) return stale;
        throw liveCategoryError;
    }
}

function callSource(sourceId, method, args) {
    var source = getSource(sourceId);
    if (isExternalSource(source)) {
        return decodeJsonResult(getExternalRuntime().callCompatible(source, [method], [args || []]));
    }
    var runtime = getRuntime();
    var spider = createSpider(source);
    return decodeJsonResult(runtime.callFunc.apply(null, [spider, method].concat(args || [])));
}

function callSourceCompatible(sourceId, methods, candidates) {
    var source = getSource(sourceId);
    if (isExternalSource(source)) {
        return decodeJsonResult(getExternalRuntime().callCompatible(source, methods, candidates));
    }
    var runtime = getRuntime();
    var spider = createSpider(source);
    return decodeJsonResult(runtime.callFuncCompatible(spider, methods, candidates));
}

function callLocalProxy(sourceId, params, proxyUrl) {
    try {
        var source = getSource(sourceId);
        if (isExternalSource(source)) {
            return decodeJsonResult(getExternalRuntime().callCompatible(source, ["localProxy", "proxy"], [[params || {}]]));
        }
        var runtime = getRuntime();
        // 空 proxyUrl 表示沿用已缓存 Spider 的代理地址；不要用空字符串覆盖
        // 首次加载时由 createSpider 写入的 _HikerProxyUrl。
        var normalizedProxyUrl = String(proxyUrl || "").trim();
        if (normalizedProxyUrl) normalizedProxyUrl = recursiveSourceProxyUrl(source.id, normalizedProxyUrl);
        var spider = normalizedProxyUrl
            ? createSpider(source, normalizedProxyUrl)
            : createSpider(source);
        return decodeJsonResult(runtime.callFuncCompatible(spider, ["localProxy", "proxy"], [[params || {}]]));
    } catch (proxyError) {
        throw new Error("localProxy " + sourceId + ": " + errorText(proxyError));
    }
}

function sourceImageHeaders(sourceId, referer) {
    var cacheKey = String(sourceId || "");
    var cached = imageHeaderCache.get(cacheKey);
    if (!cached) {
        cached = {};
        try {
            cached = callSourceCompatible(sourceId, ["getImageHeaders"], [
                [String(referer || ""), String(referer || "")],
                [String(referer || "")],
                []
            ]) || {};
        } catch (ignoreImageHeaderError) {}
        if (typeof cached === "string") {
            try { cached = JSON.parse(cached); } catch (ignoreHeaderJsonError) { cached = {}; }
        }
        if (!cached || typeof cached !== "object" || Array.isArray(cached)) cached = {};
        imageHeaderCache.set(cacheKey, clone(cached));
    }
    var headers = {};
    Object.keys(cached).forEach(function(key) {
        var lower = String(key).toLowerCase();
        if (["user-agent", "cookie", "origin", "authorization", "x-requested-with"].indexOf(lower) >= 0) {
            headers[key] = String(cached[key]);
        }
    });
    var ref = String(referer || "");
    if (/^https?:\/\//i.test(ref)) {
        headers.Referer = ref;
    } else {
        Object.keys(cached).some(function(key) {
            if (String(key).toLowerCase() !== "referer") return false;
            headers.Referer = String(cached[key]);
            return true;
        });
    }
    // 仅保留合法 URL Referer，防止 vod_id 等非 URL 值被误设为 Referer 导致代理 502
    var finalRef = String(headers.Referer || "");
    if (finalRef && !/^https?:\/\//i.test(finalRef)) {
        delete headers.Referer;
    }
    return headers;
}

function imageHost(value) {
    var matched = /^https?:\/\/([^\/?#]+)/i.exec(String(value || ""));
    return matched ? String(matched[1]).replace(/:\d+$/, "").toLowerCase() : "";
}

function upgradeImageHttps(value) {
    var original = String(value || "");
    if (!/^http:\/\//i.test(original)) return original;
    var authorityMatch = /^http:\/\/([^\/?#]+)/i.exec(original);
    var authority = authorityMatch ? String(authorityMatch[1] || "") : "";
    var host = imageHost(original);
    if (!host || authority.indexOf(":") >= 0) return original;
    if (host === "localhost" || endsWith(host, ".localhost") || endsWith(host, ".local") || endsWith(host, ".lan")) return original;
    if (/^(?:\d{1,3}\.){3}\d{1,3}$/.test(host) || host.indexOf(".") < 0) return original;
    return original.replace(/^http:\/\//i, "https://");
}

function imageNetworkRoute(value) {
    var original = String(value || "");
    var host = imageHost(original);
    if (!host) return null;
    for (var index = 0; index < BUILTIN_IMAGE_NETWORK_ROUTES.length; index++) {
        var rule = BUILTIN_IMAGE_NETWORK_ROUTES[index] || {};
        var hosts = Array.isArray(rule.hosts) ? rule.hosts : [rule.host || ""];
        var matched = hosts.some(function(candidate) {
            candidate = String(candidate || "").replace(/^\*\./, "").toLowerCase();
            return candidate && (host === candidate || endsWith(host, "." + candidate));
        });
        var ip = String(rule.healthyIp || "").trim();
        if (!matched || !/^(?:\d{1,3}\.){3}\d{1,3}$/.test(ip)) continue;
        var routed = original.replace(/^(https?:\/\/)[^\/?#]+/i, "$1" + ip);
        return {target: routed, fallback: original, host: host};
    }
    return null;
}

function normalizeImageDecoderRules(raw) {
    if (typeof raw === "string") {
        try { raw = JSON.parse(raw); } catch (ignoreDecoderJsonError) { raw = {}; }
    }
    if (Array.isArray(raw)) return raw;
    if (!raw || typeof raw !== "object") return [];
    if (Array.isArray(raw.rules)) return raw.rules;
    if (raw.type || raw.algorithm || raw.transformation) return [raw];
    return [];
}

function sourceImageDecoderRules(sourceId) {
    var cacheKey = String(sourceId || "");
    if (imageDecoderConfigCache.has(cacheKey)) return clone(imageDecoderConfigCache.get(cacheKey));
    var rules = [];
    try {
        rules = normalizeImageDecoderRules(callSourceCompatible(sourceId, [
            "getImageConfig",
            "getImageConfigs",
            "imageConfig"
        ], [[], [""]]));
    } catch (ignoreImageConfigError) {}
    imageDecoderConfigCache.set(cacheKey, clone(rules));
    return rules;
}

function imageDecoderSourceText(sourceId) {
    try {
        var source = getSource(sourceId) || {};
        return [source.name, source.path, source.api, source.id].map(function(value) {
            return String(value || "").toLowerCase();
        }).join("\n");
    } catch (ignoreDecoderSourceError) {
        return String(sourceId || "").toLowerCase();
    }
}

function imageDecoderRuleMatches(rule, value, sourceId) {
    rule = rule || {};
    var host = imageHost(value);
    var hasMatcher = false;
    var sourceNames = rule.sourceNames || rule.sourceName || rule.sources;
    if (sourceNames) {
        hasMatcher = true;
        if (!Array.isArray(sourceNames)) sourceNames = [sourceNames];
        var sourceText = imageDecoderSourceText(sourceId);
        if (!sourceNames.some(function(candidate) {
            candidate = String(candidate || "").toLowerCase();
            return !!candidate && sourceText.indexOf(candidate) >= 0;
        })) return false;
    }
    var hosts = rule.hosts || rule.host;
    if (hosts) {
        hasMatcher = true;
        if (!Array.isArray(hosts)) hosts = [hosts];
        var hostMatched = hosts.some(function(candidate) {
            candidate = String(candidate || "").replace(/^\*\./, "").toLowerCase();
            return !!candidate && (host === candidate || endsWith(host, "." + candidate));
        });
        if (!hostMatched) return false;
    }
    var contains = rule.urlContains || rule.contains;
    if (contains) {
        hasMatcher = true;
        if (!Array.isArray(contains)) contains = [contains];
        if (!contains.some(function(part) { return String(value).indexOf(String(part)) >= 0; })) return false;
    }
    if (rule.urlPattern || rule.pattern) {
        hasMatcher = true;
        try {
            if (!(new RegExp(String(rule.urlPattern || rule.pattern), "i")).test(String(value))) return false;
        } catch (ignoreDecoderPatternError) { return false; }
    }
    return hasMatcher || !!(rule.type || rule.algorithm || rule.transformation);
}

function normalizedImageDecoderProfile(rule) {
    rule = rule || {};
    var type = String(rule.type || rule.algorithm || "cipher").toLowerCase();
    var transformation = String(rule.transformation || "");
    if (!transformation && /aes/.test(type)) {
        transformation = type.indexOf("ecb") >= 0 ? "AES/ECB/PKCS5Padding" : "AES/CBC/PKCS5Padding";
        type = "cipher";
    }
    transformation = transformation.replace(/PKCS7Padding/ig, "PKCS5Padding");
    return {
        id: String(rule.id || "source-image-decoder"),
        type: type,
        transformation: transformation,
        key: String(rule.key || rule.secret || ""),
        iv: String(rule.iv || ""),
        keyEncoding: String(rule.keyEncoding || rule.encoding || "utf8").toLowerCase(),
        ivEncoding: String(rule.ivEncoding || rule.encoding || "utf8").toLowerCase(),
        xorKey: String(rule.xorKey || rule.key || ""),
        xorKeyEncoding: String(rule.xorKeyEncoding || rule.keyEncoding || rule.encoding || "utf8").toLowerCase(),
        xorLength: Number(rule.xorLength || rule.length || 0),
        offset: Number(rule.offset || rule.prefixLength || 0),
        candidates: Array.isArray(rule.candidates) ? clone(rule.candidates) : [],
        headers: rule.headers && typeof rule.headers === "object" && !Array.isArray(rule.headers) ? clone(rule.headers) : {}
    };
}

function imageDecoderProfile(sourceId, value) {
    var rules = sourceImageDecoderRules(sourceId).concat(BUILTIN_IMAGE_DECODERS);
    for (var i = 0; i < rules.length; i++) {
        if (imageDecoderRuleMatches(rules[i], value, sourceId)) return normalizedImageDecoderProfile(rules[i]);
    }
    return null;
}

function blackMaterialEncryptedImageUrl(value, headers) {
    var cacheSeparatedUrl = value + (String(value).indexOf("?") >= 0 ? "&" : "?") + "pyimg=" + IMAGE_PIPELINE_VERSION;
    return $(cacheSeparatedUrl, headers || {}).image(function() {
        var original = null;
        try {
            var output = new java.io.ByteArrayOutputStream();
            var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
            var length;
            while ((length = input.read(buffer)) > 0) output.write(buffer, 0, length);
            original = output.toByteArray();

            var cipher = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
            var key = new javax.crypto.spec.SecretKeySpec(
                new java.lang.String("f5d965df75336270").getBytes("UTF-8"),
                "AES"
            );
            var iv = new javax.crypto.spec.IvParameterSpec(
                new java.lang.String("97b60394abc2fbe1").getBytes("UTF-8")
            );
            var decoded;
            try {
                cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key, iv);
                decoded = cipher.doFinal(original);
            } catch (paddingError) {
                var alignedLength = Math.floor(Number(original.length || 0) / 16) * 16;
                if (alignedLength < 16) throw paddingError;
                cipher = javax.crypto.Cipher.getInstance("AES/CBC/NoPadding");
                cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key, iv);
                decoded = cipher.doFinal(java.util.Arrays.copyOf(original, alignedLength));
            }
            var start = -1;
            for (var index = 0; index + 2 < decoded.length; index++) {
                if ((Number(decoded[index]) & 255) === 255 && (Number(decoded[index + 1]) & 255) === 216 && (Number(decoded[index + 2]) & 255) === 255) {
                    start = index;
                    break;
                }
            }
            if (start >= 0) {
                var end = decoded.length;
                for (var tail = decoded.length - 2; tail >= start; tail--) {
                    if ((Number(decoded[tail]) & 255) === 255 && (Number(decoded[tail + 1]) & 255) === 217) {
                        end = tail + 2;
                        break;
                    }
                }
                decoded = java.util.Arrays.copyOfRange(decoded, start, end);
            }
            return new java.io.ByteArrayInputStream(decoded);
        } catch (imageDecodeError) {
            return original
                ? new java.io.ByteArrayInputStream(original)
                : input;
        }
    });
}

function encryptedImageUrl(value, headers, profile) {
    if (profile && profile.id === "black-material-aes-cbc-v1") {
        return blackMaterialEncryptedImageUrl(value, headers);
    }
    return $(value, headers || {}).image(function(profileJson) {
        function readAll(stream) {
            var output = new java.io.ByteArrayOutputStream();
            var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
            var length;
            while ((length = stream.read(buffer)) !== -1) {
                if (length > 0) output.write(buffer, 0, length);
            }
            return output.toByteArray();
        }
        function streamOf(bytes) {
            return new java.io.ByteArrayInputStream(bytes);
        }
        function byteAt(bytes, index) {
            return Number(bytes[index]) & 255;
        }
        function starts(bytes, signature) {
            if (!bytes || bytes.length < signature.length) return false;
            for (var index = 0; index < signature.length; index++) {
                if (byteAt(bytes, index) !== signature[index]) return false;
            }
            return true;
        }
        function ascii(bytes, start, count) {
            var text = "";
            for (var index = start; index < start + count && index < bytes.length; index++) {
                text += String.fromCharCode(byteAt(bytes, index));
            }
            return text;
        }
        function isImage(bytes) {
            if (!bytes || bytes.length < 4) return false;
            if (starts(bytes, [255, 216, 255])) return true;
            if (starts(bytes, [137, 80, 78, 71, 13, 10, 26, 10])) return true;
            if (ascii(bytes, 0, 4) === "GIF8") return true;
            if (ascii(bytes, 0, 4) === "RIFF" && ascii(bytes, 8, 4) === "WEBP") return true;
            if (starts(bytes, [66, 77]) || starts(bytes, [0, 0, 1, 0])) return true;
            if (starts(bytes, [73, 73, 42, 0]) || starts(bytes, [77, 77, 0, 42])) return true;
            if (ascii(bytes, 4, 4) === "ftyp") {
                var brand = ascii(bytes, 8, 4).toLowerCase();
                if (["avif", "avis", "heic", "heix", "hevc", "mif1", "msf1"].indexOf(brand) >= 0) return true;
            }
            var prefix = ascii(bytes, 0, Math.min(bytes.length, 512)).replace(/^\uFEFF/, "").replace(/^\s+/, "").toLowerCase();
            return prefix.indexOf("<svg") === 0 || (prefix.indexOf("<?xml") === 0 && prefix.indexOf("<svg") >= 0);
        }
        function base64Bytes(text, urlSafe) {
            return android.util.Base64.decode(
                String(text),
                urlSafe ? android.util.Base64.URL_SAFE : android.util.Base64.DEFAULT
            );
        }
        function materialBytes(text, encoding) {
            text = String(text || "");
            encoding = String(encoding || "utf8").toLowerCase();
            if (encoding === "hex") {
                var clean = text.replace(/[^0-9a-f]/ig, "");
                var result = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, Math.floor(clean.length / 2));
                for (var index = 0; index < result.length; index++) {
                    var value = parseInt(clean.slice(index * 2, index * 2 + 2), 16) & 255;
                    result[index] = value > 127 ? value - 256 : value;
                }
                return result;
            }
            if (encoding === "base64" || encoding === "b64") return base64Bytes(text, /[-_]/.test(text));
            return new java.lang.String(text).getBytes("UTF-8");
        }
        function unwrap(bytes) {
            var current = bytes;
            if (starts(current, [31, 139])) {
                try { current = readAll(new java.util.zip.GZIPInputStream(streamOf(current))); } catch (ignoreGzipError) {}
            }
            if (isImage(current) || current.length < 64 || current.length > 10485760) return current;
            try {
                var text = String(new java.lang.String(current, "UTF-8")).trim();
                var comma = text.indexOf(",");
                if (/^data:image\//i.test(text) && comma >= 0) text = text.slice(comma + 1);
                text = text.replace(/\s+/g, "");
                if (text.length >= 64 && /^[A-Za-z0-9+\/_-]+={0,2}$/.test(text)) {
                    var decoded = base64Bytes(text, /[-_]/.test(text));
                    if (isImage(decoded)) return decoded;
                }
            } catch (ignoreBase64Error) {}
            return current;
        }
        function runCipher(bytes, currentProfile, transformation) {
            var cipher = javax.crypto.Cipher.getInstance(transformation);
            var algorithm = String(transformation).split("/")[0] || "AES";
            var key = new javax.crypto.spec.SecretKeySpec(
                materialBytes(currentProfile.key, currentProfile.keyEncoding),
                algorithm
            );
            if (/\/ECB\//i.test(transformation)) {
                cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key);
            } else {
                var iv = new javax.crypto.spec.IvParameterSpec(materialBytes(currentProfile.iv, currentProfile.ivEncoding));
                cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key, iv);
            }
            return cipher.doFinal(bytes);
        }
        function trimEmbeddedImage(bytes) {
            if (isImage(bytes)) return bytes;
            var jpegStart = -1;
            for (var index = 0; index + 2 < bytes.length; index++) {
                if (byteAt(bytes, index) === 255 && byteAt(bytes, index + 1) === 216 && byteAt(bytes, index + 2) === 255) {
                    jpegStart = index;
                    break;
                }
            }
            if (jpegStart >= 0) {
                var jpegEnd = bytes.length;
                for (var jpegIndex = bytes.length - 2; jpegIndex >= jpegStart; jpegIndex--) {
                    if (byteAt(bytes, jpegIndex) === 255 && byteAt(bytes, jpegIndex + 1) === 217) {
                        jpegEnd = jpegIndex + 2;
                        break;
                    }
                }
                return java.util.Arrays.copyOfRange(bytes, jpegStart, jpegEnd);
            }
            var pngSignature = [137, 80, 78, 71, 13, 10, 26, 10];
            for (var pngStart = 0; pngStart + pngSignature.length <= bytes.length; pngStart++) {
                var pngMatched = true;
                for (var pngIndex = 0; pngIndex < pngSignature.length; pngIndex++) {
                    if (byteAt(bytes, pngStart + pngIndex) !== pngSignature[pngIndex]) { pngMatched = false; break; }
                }
                if (pngMatched) return java.util.Arrays.copyOfRange(bytes, pngStart, bytes.length);
            }
            return bytes;
        }
        function decodeBhDataUrl(bytes) {
            var current = bytes;
            if (starts(current, [31, 139])) current = readAll(new java.util.zip.GZIPInputStream(streamOf(current)));
            current = java.util.Arrays.copyOf(current, current.length);
            var limit = Math.min(current.length, 4096);
            for (var index = 0; index < limit; index++) {
                var value = byteAt(current, index) ^ 18;
                current[index] = value > 127 ? value - 256 : value;
            }
            var marker = [98, 97, 115, 101, 54, 52, 44];
            var start = -1;
            for (var markerStart = 0; markerStart + marker.length <= current.length; markerStart++) {
                var matched = true;
                for (var markerIndex = 0; markerIndex < marker.length; markerIndex++) {
                    if (byteAt(current, markerStart + markerIndex) !== marker[markerIndex]) { matched = false; break; }
                }
                if (matched) { start = markerStart + marker.length; break; }
            }
            if (start < 0) return bytes;
            var clean = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, current.length - start);
            var count = 0;
            for (var byteIndex = start; byteIndex < current.length; byteIndex++) {
                var character = byteAt(current, byteIndex);
                if (character === 10 || character === 13 || character === 32 || character === 9) continue;
                clean[count++] = current[byteIndex];
            }
            return android.util.Base64.decode(
                java.util.Arrays.copyOf(clean, count),
                android.util.Base64.DEFAULT
            );
        }
        function applyProfile(bytes, currentProfile) {
            var type = String(currentProfile.type || "cipher").toLowerCase();
            if (type === "base64") return base64Bytes(String(new java.lang.String(bytes, "UTF-8")).trim(), false);
            if (type === "gzip") return readAll(new java.util.zip.GZIPInputStream(streamOf(bytes)));
            if (type === "bh-data-url") return decodeBhDataUrl(bytes);
            if (type === "strip-prefix") {
                var offset = Math.max(0, Math.min(bytes.length, Number(currentProfile.offset || 0)));
                return java.util.Arrays.copyOfRange(bytes, offset, bytes.length);
            }
            if (type === "xor") {
                var xorKey = materialBytes(currentProfile.xorKey, currentProfile.xorKeyEncoding);
                if (!xorKey.length) return bytes;
                var result = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, bytes.length);
                var xorLength = Number(currentProfile.xorLength || 0);
                var xorLimit = xorLength > 0 ? Math.min(bytes.length, xorLength) : bytes.length;
                for (var index = 0; index < bytes.length; index++) {
                    var value = byteAt(bytes, index);
                    if (index < xorLimit) value = value ^ byteAt(xorKey, index % xorKey.length);
                    result[index] = value > 127 ? value - 256 : value;
                }
                return result;
            }
            if (type === "auto-cipher") {
                var candidates = Array.isArray(currentProfile.candidates) ? currentProfile.candidates : [];
                for (var candidateIndex = 0; candidateIndex < candidates.length; candidateIndex++) {
                    var candidate = candidates[candidateIndex] || {};
                    var candidateTransformation = String(candidate.transformation || "AES/CBC/PKCS5Padding").replace(/PKCS7Padding/ig, "PKCS5Padding");
                    try {
                        var decoded = trimEmbeddedImage(runCipher(bytes, candidate, candidateTransformation));
                        if (isImage(decoded)) return decoded;
                    } catch (candidatePaddingError) {
                        if (/PKCS5Padding/i.test(candidateTransformation)) {
                            try {
                                var noPadding = trimEmbeddedImage(runCipher(bytes, candidate, candidateTransformation.replace(/PKCS5Padding/i, "NoPadding")));
                                if (isImage(noPadding)) return noPadding;
                            } catch (ignoreCandidateNoPaddingError) {}
                        }
                    }
                }
                return bytes;
            }
            var transformation = String(currentProfile.transformation || "AES/CBC/PKCS5Padding").replace(/PKCS7Padding/ig, "PKCS5Padding");
            try {
                return runCipher(bytes, currentProfile, transformation);
            } catch (paddingError) {
                if (/PKCS5Padding/i.test(transformation)) {
                    return runCipher(bytes, currentProfile, transformation.replace(/PKCS5Padding/i, "NoPadding"));
                }
                throw paddingError;
            }
        }

        var original = readAll(input);
        try {
            var normalized = unwrap(original);
            if (isImage(normalized)) return streamOf(normalized);
            var currentProfile = JSON.parse(String(profileJson || "{}"));
            var transformed = trimEmbeddedImage(unwrap(applyProfile(original, currentProfile)));
            return streamOf(isImage(transformed) ? transformed : original);
        } catch (imageDecodeError) {
            return streamOf(original);
        }
    }, JSON.stringify(profile || {}));
}

// 一起草的封面是整图 XOR 0x88 密文。优先在海阔异步图片线程直接解密，
// 避免 Glide 访问 127.0.0.1 本地代理后被 Android 全局代理接管。只有签名
// 过期或上游返回异常时，才直接调用源 localProxy 刷新 vid 对应的 auth_key。
function togetherProxyEncryptedImageUrl(sourceId, proxyValue, target, headers, profile) {
    var params = proxyUrlParameters(proxyValue);
    var cacheSeparatedUrl = imagePipelineCacheUrl(target);
    return $(cacheSeparatedUrl, headers || {}).image(function(source, paramsJson, corePagePath, ruleTitle) {
        function readAll(stream) {
            var output = new java.io.ByteArrayOutputStream();
            var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
            var length;
            while ((length = stream.read(buffer)) !== -1) {
                if (length > 0) output.write(buffer, 0, length);
            }
            return output.toByteArray();
        }
        function streamOf(bytes) {
            return new java.io.ByteArrayInputStream(bytes);
        }
        function byteAt(bytes, index) {
            return Number(bytes[index]) & 255;
        }
        function isImage(bytes) {
            if (!bytes || bytes.length < 12) return false;
            if (byteAt(bytes, 0) === 255 && byteAt(bytes, 1) === 216 && byteAt(bytes, 2) === 255) return true;
            if (byteAt(bytes, 0) === 137 && byteAt(bytes, 1) === 80 && byteAt(bytes, 2) === 78 && byteAt(bytes, 3) === 71) return true;
            var head4 = String.fromCharCode(byteAt(bytes, 0), byteAt(bytes, 1), byteAt(bytes, 2), byteAt(bytes, 3));
            var tail4 = String.fromCharCode(byteAt(bytes, 8), byteAt(bytes, 9), byteAt(bytes, 10), byteAt(bytes, 11));
            return head4 === "GIF8" || (head4 === "RIFF" && tail4 === "WEBP");
        }
        function decodeTogether(bytes) {
            if (isImage(bytes)) return bytes;
            if (!bytes || !bytes.length) return null;
            var decoded = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, bytes.length);
            for (var index = 0; index < bytes.length; index++) {
                var value = byteAt(bytes, index) ^ 136;
                decoded[index] = value > 127 ? value - 256 : value;
            }
            return isImage(decoded) ? decoded : null;
        }

        var original = null;
        if (input) {
            try {
                original = readAll(input);
                var decoded = decodeTogether(original);
                if (decoded) return streamOf(decoded);
            } catch (ignoreTogetherDirectDecodeError) {}
        }

        try {
            var core = null;
            try { core = $.require(String(corePagePath) + "?rule=" + String(ruleTitle)); } catch (ignoreTogetherPageRequireError) {}
            if (!core || typeof core.callLocalProxy !== "function") {
                core = $.require("hiker://files/data/" + String(ruleTitle) + "/subpage/py_core.js");
            }
            var proxyParams = JSON.parse(String(paramsJson || "{}"));
            var result = core.callLocalProxy(String(source), proxyParams, "");
            if (core.normalizeProxyBodyResult) result = core.normalizeProxyBodyResult(result);
            if (Array.isArray(result) && Number(result[0] || 0) >= 200 && Number(result[0] || 0) < 300) {
                var body = result[2];
                try {
                    if (body && body.getClass && String(body.getClass().getName()) === "[B") return streamOf(body);
                } catch (ignoreTogetherProxyByteArrayError) {}
                try {
                    if (body && body.read && body.close) return body;
                } catch (ignoreTogetherProxyStreamError) {}
            }
        } catch (ignoreTogetherProxyFallbackError) {}
        return original ? streamOf(original) : input;
    }, String(sourceId || ""), JSON.stringify(params || {}), CORE_PAGE_PATH, RULE_TITLE);
}

function imagePipelineCacheUrl(value) {
    var text = String(value || "");
    return text + (text.indexOf("#") >= 0 ? "&" : "#") + "pyimg=" + IMAGE_PIPELINE_VERSION;
}

// PickTV 直接把 PY 图片交给 OkHttp-backed Glide，并完整保留请求头。海阔
// 的图片 OkHttpStreamFetcher 在主请求失败/非 2xx 时仍会执行 @js，且此时
// input 为 null。因此这里用同一机制实现通用的“HTTPS 候选 → 原 HTTP →
// 显式直连”回退，不经过壳子的本地 HTTP 图片代理，也不逐域打补丁。
function adaptiveDirectImageUrl(value, headers) {
    var originalUrl = String(value || "");
    var primaryUrl = upgradeImageHttps(originalUrl);
    var cacheSeparatedUrl = imagePipelineCacheUrl(primaryUrl);
    return $(cacheSeparatedUrl, headers || {}).image(function(original, primary, headerJson) {
        if (input) return input;

        var requestHeaders = {};
        try { requestHeaders = JSON.parse(String(headerJson || "{}")); } catch (ignoreHeaderJsonError) {}

        function fetchStream(target) {
            try {
                return fetch(String(target), {
                    headers: requestHeaders,
                    inputStream: true,
                    timeout: 6000
                });
            } catch (ignoreFetchFallbackError) {
                return null;
            }
        }

        function directStream(target) {
            var connection = null;
            try {
                connection = new java.net.URL(String(target)).openConnection(java.net.Proxy.NO_PROXY);
                if (/^https:\/\//i.test(String(target))) {
                    try {
                        var trustManagers = [new javax.net.ssl.X509TrustManager({
                            getAcceptedIssuers: function() { return []; },
                            checkClientTrusted: function() {},
                            checkServerTrusted: function() {}
                        })];
                        var sslContext = javax.net.ssl.SSLContext.getInstance("TLS");
                        sslContext.init(null, trustManagers, new java.security.SecureRandom());
                        if (connection.setSSLSocketFactory) connection.setSSLSocketFactory(sslContext.getSocketFactory());
                        if (connection.setHostnameVerifier) {
                            connection.setHostnameVerifier(new javax.net.ssl.HostnameVerifier({
                                verify: function() { return true; }
                            }));
                        }
                    } catch (ignoreDirectSslError) {}
                }
                connection.setConnectTimeout(6000);
                connection.setReadTimeout(10000);
                if (connection.setInstanceFollowRedirects) connection.setInstanceFollowRedirects(true);
                Object.keys(requestHeaders || {}).forEach(function(key) {
                    var headerValue = requestHeaders[key];
                    if (headerValue !== undefined && headerValue !== null && String(headerValue) !== "") {
                        try { connection.setRequestProperty(String(key), String(headerValue)); } catch (ignoreDirectHeaderError) {}
                    }
                });
                var status = connection.getResponseCode ? Number(connection.getResponseCode()) : 200;
                if (status >= 200 && status < 300) return connection.getInputStream();
            } catch (ignoreDirectFallbackError) {
            }
            try { if (connection && connection.disconnect) connection.disconnect(); } catch (ignoreDirectDisconnectError) {}
            return null;
        }

        var stream = null;
        // HTTPS 候选失败时，先让原 HTTP 继续使用设备现有代理/DNS；这能
        // 保留必须经代理访问且只支持 HTTP 的旧 CDN。
        if (String(original) !== String(primary)) {
            stream = fetchStream(original);
            if (stream) return stream;
        }
        // 设备代理链路异常时再显式直连。HTTPS 原图（例如 MuMu 某些 CDN）
        // 也能走到这里，不需要把新域名加入排除列表。
        stream = directStream(primary);
        if (stream) return stream;
        if (String(original) !== String(primary)) {
            stream = directStream(original);
            if (stream) return stream;
        }
        return input;
    }, originalUrl, primaryUrl, JSON.stringify(headers || {}));
}

function passthroughImageUrl(value, headers) {
    return adaptiveDirectImageUrl(value, headers);
}

function proxyUrlParameters(value) {
    var text = String(value || "");
    var queryIndex = text.indexOf("?");
    if (queryIndex < 0) return {};
    var params = {};
    text.slice(queryIndex + 1).split("#", 1)[0].split("&").forEach(function(part) {
        if (!part) return;
        var split = part.indexOf("=");
        var rawKey = split >= 0 ? part.slice(0, split) : part;
        var rawValue = split >= 0 ? part.slice(split + 1) : "";
        var key;
        var item;
        try { key = decodeURIComponent(rawKey); } catch (ignoreProxyKeyDecodeError) { key = rawKey; }
        try { item = decodeURIComponent(rawValue); } catch (ignoreProxyValueDecodeError) { item = rawValue; }
        if (params[key] === undefined) params[key] = item;
    });
    return params;
}

function proxyImageTarget(value) {
    var text = String(value || "");
    if (!localProxyUrlMatches(text)) return "";
    var params = proxyUrlParameters(text);
    var type = String(params.type || params.do || "").toLowerCase();
    var encodedTarget = params.url || params.u || params.uri || "";
    var decodedTarget = decodeProxyImageUrl(encodedTarget);
    // 部分 PY 源直接使用 getProxyUrl() + "&url="，不带 type=img。
    // 这类 URL 在列表图片场景仍可确定为图片目标，直接走壳子图片桥，
    // 避免独立代理线程再次启动 Python 导致 502。
    var implicitImage = !!decodedTarget &&
        /\.(?:jpe?g|png|webp|gif|avif|bmp|heic)(?:[?#].*)?$/i.test(decodedTarget);
    if (type !== "img" && type !== "image" && type !== "bh_img" && type !== "bhimg" && !implicitImage) return "";
    // directImageProxyUrl 用 __direct_img 参数承载真实图片地址
    if (params.__direct_img) return String(params.__direct_img);
    return decodedTarget;
}

function proxyEndpoint(value) {
    var text = String(value || "").trim();
    var marker = text.search(/[?#]/);
    return (marker >= 0 ? text.slice(0, marker) : text).replace(/\/+$/, "").toLowerCase();
}

function localProxyUrlMatches(value) {
    var text = String(value || "");
    if (!/^https?:\/\//i.test(text)) return false;
    // 影视源基类的固定地址可直接识别；不要仅为判断 URL 就启动壳代理。
    if (/^https?:\/\/(?:127\.0\.0\.1|localhost|10\.0\.2\.15):52020\/proxy(?:[/?#]|$)/i.test(text)) return true;
    var base = "";
    try { base = String(getLocalProxyUrl() || ""); } catch (ignoreLocalProxyMatchError) {}
    if (base && proxyEndpoint(text) === proxyEndpoint(base)) return true;
    return false;
}

function proxyImageIsImplicit(value) {
    var text = String(value || "");
    if (!localProxyUrlMatches(text)) return false;
    var params = proxyUrlParameters(text);
    return params.type === undefined && params.do === undefined;
}

function imageUrlWithHeaders(value, inputHeaders) {
    var headers = {};
    Object.keys(inputHeaders || {}).forEach(function(key) {
        headers[key] = inputHeaders[key];
    });
    if (!Object.keys(headers).length) return value;
    function takeHeader(name) {
        var found = "";
        Object.keys(headers).some(function(key) {
            if (String(key).toLowerCase() !== String(name).toLowerCase()) return false;
            found = String(headers[key] || "");
            delete headers[key];
            return true;
        });
        return found;
    }
    var marker = "";
    var ref = takeHeader("Referer");
    var ua = takeHeader("User-Agent");
    var cookie = takeHeader("Cookie");
    if (ref) marker += "@Referer=" + ref;
    if (ua) marker += "@User-Agent=" + ua;
    if (cookie) marker += "@Cookie=" + cookie;
    if (Object.keys(headers).length) marker += "@headers=" + JSON.stringify(headers);
    if (!marker) return value;
    var jsAt = value.indexOf("@js=");
    return jsAt >= 0 ? value.slice(0, jsAt) + marker + value.slice(jsAt) : value + marker;
}

function applyImageProfileHeaders(headers, profile) {
    var output = {};
    Object.keys(headers || {}).forEach(function(key) { output[key] = headers[key]; });
    Object.keys((profile && profile.headers) || {}).forEach(function(key) {
        if (profile.headers[key] !== undefined && profile.headers[key] !== null && String(profile.headers[key]) !== "") {
            output[key] = profile.headers[key];
        }
    });
    return output;
}

function imageUrl(sourceId, url, referer) {
    var value = String(url || "");
    if (!value) return "";
    if (startsWith(value, "proxy://")) value = normalizeProxyUrl(value, sourceId);
    if (/^(?:data:|hiker:\/\/|file:\/\/)/i.test(value)) return value;
    if (localProxyUrlMatches(value)) {
        var directTarget = proxyImageTarget(value);
        if (directTarget) {
            var proxyParams = proxyUrlParameters(value);
            var proxyReferer = String(proxyParams.ref || proxyParams.referer || "");
            var directHeaders = sourceImageHeaders(sourceId, proxyReferer || referer || directTarget);
            if (proxyReferer && /^https?:\/\//i.test(proxyReferer)) directHeaders.Referer = proxyReferer;
            if (proxyParams.ua || proxyParams.userAgent) {
                directHeaders["User-Agent"] = String(proxyParams.ua || proxyParams.userAgent);
            }
            if (proxyImageIsImplicit(value)) {
                // Some physical-phone Hiker builds return 502 for the local
                // proxy URL used by implicit PY images. Give Glide the real
                // CDN URL and preserve the source UA/Referer as native markers.
                return adaptiveDirectImageUrl(directTarget, directHeaders);
            }
            var directProfile = imageDecoderProfile(sourceId, directTarget);
            if (directProfile) {
                directHeaders = applyImageProfileHeaders(directHeaders, directProfile);
                if (directProfile.id === "py-together-xor88-v1") {
                    return togetherProxyEncryptedImageUrl(sourceId, value, directTarget, directHeaders, directProfile);
                }
                try { return encryptedImageUrl(directTarget, directHeaders, directProfile); } catch (ignoreProxyDecoderError) {}
            }
            // 显式 type=image/img 通常表示源的 localProxy 还负责 XOR/AES 解密、
            // Cookie 或签名刷新。保留原代理 URL；代理回调失败后再走直连兜底。
        }
        // 海阔部分版本将本地代理发布为 10.0.2.15；Glide 对该别名偶发不发起请求，
        // 统一使用设备回环地址，查询参数仍保留原始代理地址供 PY 二次请求使用。
        if (/^https?:\/\/10\.0\.2\.15(?::|\/)/i.test(value)) {
            value = value.replace(/^https?:\/\/10\.0\.2\.15/i, "http://127.0.0.1");
        }
        var separator = value.indexOf("?") >= 0 ? "&" : "?";
        if (!/[?&]__hiker_proxy=/.test(value)) {
            value += separator + "__hiker_proxy=" + encodeURIComponent(sourceProxyRoot(sourceId));
            separator = "&";
        }
        if (!/[?&]pyproxy=/.test(value)) value += separator + "pyproxy=" + IMAGE_PIPELINE_VERSION;
        return value;
    }
    if (/@(?:headers|Referer|User-Agent|Cookie|js)=/i.test(value)) return value;
    if (!/^https?:\/\//i.test(value)) return value;

    var headers = sourceImageHeaders(sourceId, referer || value);
    var profile = imageDecoderProfile(sourceId, value);
    if (profile) {
        headers = applyImageProfileHeaders(headers, profile);
        try { return encryptedImageUrl(value, headers, profile); } catch (ignoreEncryptedImageError) {}
    }
    var networkRoute = imageNetworkRoute(value);
    if (networkRoute) {
        headers.Host = networkRoute.host;
        return directImageProxyUrl(sourceId, networkRoute.target, headers, networkRoute.fallback);
    }
    return adaptiveDirectImageUrl(value, headers);
}

// 首页 movie_3 在部分 Android 真机上会静默跳过普通 HTTPS 图片请求，
// 而二级竖图仍能正常显示。仅对 imageUrl 未做任何特殊适配的直连图片
// 增加海阔官方 InputStream 透传，保留代理图、解密图和带 header 图的原链路。
function listImageUrl(sourceId, url, referer) {
    var original = String(url || "");
    var adapted = imageUrl(sourceId, original, referer);
    if (!adapted || adapted !== original) return adapted;
    if (!/^https?:\/\//i.test(adapted)) return adapted;
    if (/^https?:\/\/(?:127\.0\.0\.1|localhost|10\.0\.2\.15)(?::|\/)/i.test(adapted)) return adapted;
    if (/@(?:headers|Referer|User-Agent|Cookie|js)=/i.test(adapted)) return adapted;
    return passthroughImageUrl(adapted, sourceImageHeaders(sourceId, referer || adapted));
}

function decodedText(value) {
    var text = String(value || "").trim().replace(/\\\//g, "/");
    try { return decodeURIComponent(text); } catch (ignoreDecodeError) { return text; }
}

function vodMatchKeys(vod) {
    var id = decodedText(firstValue(vod || {}, ["vod_id", "vodId", "id", "video_id", "url", "link", "href"], ""));
    var keys = [];
    function add(value) {
        value = String(value || "").replace(/#.*$/, "").replace(/\/$/, "");
        if (value && keys.indexOf(value) < 0) keys.push(value);
    }
    add(id);
    var withoutQuery = id.replace(/[?#].*$/, "");
    add(withoutQuery);
    if (/^https?:\/\//i.test(withoutQuery)) {
        add(withoutQuery.replace(/^https?:\/\/[^/]+/i, ""));
    }
    return keys;
}

function vodNameKey(vod) {
    return decodedText(firstValue(vod || {}, ["vod_name", "vodName", "name", "title", "text"], ""))
        .replace(/<[^>]+>/g, " ")
        .replace(/\s+/g, " ")
        .trim()
        .toLowerCase();
}

function vodListStats(list) {
    var stats = {total: 0, names: 0, pics: 0};
    (list || []).forEach(function(vod) {
        stats.total++;
        var name = firstValue(vod || {}, ["vod_name", "vodName", "name", "title", "text"], "");
        if (!detailNameNeedsFallback(name, firstValue(vod || {}, ["vod_id", "id", "url"], ""))) stats.names++;
        if (String(firstValue(vod || {}, ["vod_pic", "vodPic", "pic", "pic_url", "img", "image", "cover", "poster", "thumb"], "")).trim()) stats.pics++;
    });
    return stats;
}

function vodListNeedsGeneric(list) {
    var stats = vodListStats(list);
    if (!stats.total) return true;
    return stats.pics < Math.ceil(stats.total / 2) || stats.names < Math.ceil(stats.total * 0.75);
}

function mergeVodFields(primary, fallback) {
    var merged = Object.assign({}, primary || {});
    Object.keys(fallback || {}).forEach(function(key) {
        var current = merged[key];
        var replaceName = key === "vod_name" && detailNameNeedsFallback(current, merged.vod_id);
        var replacePic = key === "vod_pic" && !String(current || "").trim();
        if (replaceName || replacePic || current === undefined || current === null || String(current) === "") {
            merged[key] = fallback[key];
        }
    });
    return normalizeVod(merged, 0);
}

function genericListResult(sourceId, tid, page) {
    var route = String(tid || "");
    var currentPage = String(page || 1);
    var cacheKey = String(sourceId || "") + "@" + route + "@" + currentPage;
    var cached = genericListCache.get(cacheKey);
    if (cached && Date.now() - Number(cached.savedAt || 0) <= GENERIC_LIST_CACHE_TTL_MS) return clone(cached.value);
    var result = normalizePageResult(callSourceCompatible(sourceId, ["genericVideoList"], [
        [route, currentPage]
    ]), sourceId);
    genericListCache.set(cacheKey, {savedAt: Date.now(), value: clone(result)});
    return result;
}

function mergeVodListWithGeneric(list, genericList) {
    var original = (list || []).map(function(vod, index) { return normalizeVod(vod, index); });
    if (original.length && !vodListNeedsGeneric(original)) return original;
    var generic = (genericList || []).map(function(vod, index) { return normalizeVod(vod, index); });
    if (!generic.length) return original;
    if (!original.length) return generic;

    var entries = original.map(function(vod, index) {
        return {vod: vod, index: index, keys: vodMatchKeys(vod), name: vodNameKey(vod), used: false};
    });
    var matchedInGenericOrder = [];
    generic.forEach(function(fallbackVod) {
        var fallbackKeys = vodMatchKeys(fallbackVod);
        var fallbackName = vodNameKey(fallbackVod);
        var match = entries.find(function(entry) {
            if (entry.used) return false;
            var idMatched = entry.keys.some(function(key) { return fallbackKeys.indexOf(key) >= 0; });
            return idMatched || (fallbackName && entry.name === fallbackName);
        });
        if (!match) return;
        match.used = true;
        match.merged = mergeVodFields(match.vod, fallbackVod);
        matchedInGenericOrder.push(match.merged);
    });

    if (!matchedInGenericOrder.length) return original;
    var mergedOriginalOrder = entries.map(function(entry) { return entry.merged || entry.vod; });
    var originalStats = vodListStats(original);
    var mergedStats = vodListStats(mergedOriginalOrder);
    var matchRatio = matchedInGenericOrder.length / Math.max(1, original.length);
    var nearComplete = original.length <= 3
        ? matchedInGenericOrder.length === original.length
        : matchRatio >= 0.75;
    if (nearComplete && vodListStats(matchedInGenericOrder).pics > originalStats.pics) {
        return matchedInGenericOrder;
    }
    return mergedStats.pics > originalStats.pics || mergedStats.names > originalStats.names
        ? mergedOriginalOrder
        : original;
}

function enrichVodListFromGeneric(sourceId, list, tid, page) {
    if ((list || []).length && !vodListNeedsGeneric(list)) {
        return (list || []).map(function(vod, index) { return normalizeVod(vod, index); });
    }
    var generic = genericListResult(sourceId, tid, page).list || [];
    return mergeVodListWithGeneric(list, generic);
}

function homeSource(sourceId, filterable) {
    var result = normalizeHomeResult(callSourceCompatible(sourceId, ["homeContent", "getHomeContent"], [
        [filterable !== false],
        [false],
        []
    ]), sourceId);
    // 二级筛选树随首页结果一起缓存，供二级子分类标签栏使用。
    if (result.filters && Object.keys(result.filters).length) {
        try { cacheHomeFilters(sourceId, result.filters); } catch (ignoreHomeFiltersSaveError) {}
    }
    if (result.list.length && vodListNeedsGeneric(result.list)) {
        var firstClass = result.class[0] || {};
        try { result.list = enrichVodListFromGeneric(sourceId, result.list, firstClass.type_id || "", "1"); } catch (ignoreHomeEnrichError) {}
    }
    savePrefetchedCategory(sourceId, "", "1", result);
    return result;
}

var HOME_CLASS_TTL_MS = 6 * 60 * 60 * 1000;

function homeClassStateKey(sourceId) {
    return "py_home_classes@" + BUILD_VERSION + "@" + String(sourceId || "");
}

function getHomeClasses(sourceId) {
    var cacheKey = String(sourceId || "");
    var cached = homeClassCache.get(cacheKey);
    if (cached && Date.now() - Number(cached.savedAt || 0) <= HOME_CLASS_TTL_MS) {
        return clone(cached.classes);
    }
    // 跨页面状态：getMyVar 保存的分类树，避免切标签时重复 homeSource。
    try {
        var stored = JSON.parse(String(getMyVar(homeClassStateKey(cacheKey), "") || "{}"));
        if (stored && Array.isArray(stored.classes) && stored.classes.length &&
            Date.now() - Number(stored.savedAt || 0) <= HOME_CLASS_TTL_MS) {
            homeClassCache.set(cacheKey, {savedAt: Number(stored.savedAt || Date.now()), classes: clone(stored.classes)});
            return clone(stored.classes);
        }
    } catch (ignoreHomeClassStateError) {}
    try {
        var cachedHome = readPrefetchedCategory(cacheKey, "", "1", HOME_CLASS_TTL_MS, {});
        var cachedClasses = cachedHome && Array.isArray(cachedHome.class) ? cachedHome.class : [];
        if (cachedClasses.length) {
            cacheHomeClasses(cacheKey, cachedClasses);
            return clone(cachedClasses);
        }
    } catch (ignoreHomeClassMigrationError) {}
    return [];
}

function cacheHomeClasses(sourceId, classes) {
    var cacheKey = String(sourceId || "");
    var normalized = Array.isArray(classes) ? classes : [];
    if (!normalized.length) return;
    var entry = {savedAt: Date.now(), classes: clone(normalized)};
    homeClassCache.set(cacheKey, entry);
    try { putMyVar(homeClassStateKey(cacheKey), JSON.stringify(entry)); } catch (ignoreHomeClassSaveError) {}
}

function clearHomeClasses(sourceId) {
    var cacheKey = String(sourceId || "");
    homeClassCache.delete(cacheKey);
    try { putMyVar(homeClassStateKey(cacheKey), ""); } catch (ignoreHomeClassClearError) {}
}

// 二级筛选缓存：homeContent 返回的 filters（每个一级分类的子分类）。
// 与分类树分开缓存，避免污染 homeClassCache 的结构。
var HOME_FILTERS_TTL_MS = 6 * 60 * 60 * 1000;
var HOME_FILTERS_CACHE_VERSION = 1;
var homeFiltersCache = new Map();

function homeFiltersStateKey(sourceId) {
    return "py_home_filters@" + BUILD_VERSION + "@" + String(sourceId || "");
}

function homeFiltersFilePrefix() {
    return "home_filters_" + BUILD_VERSION + "_";
}

function homeFiltersFilePath(sourceId) {
    return DATA_ROOT + "/" + homeFiltersFilePrefix() + md5(String(sourceId || "")) + ".json";
}

function validHomeFiltersEntry(entry, sourceId) {
    return !!entry && Number(entry.version || 0) === HOME_FILTERS_CACHE_VERSION &&
        String(entry.buildVersion || "") === String(BUILD_VERSION) &&
        String(entry.sourceId || "") === String(sourceId || "") &&
        entry.filters && typeof entry.filters === "object" && !Array.isArray(entry.filters) &&
        Object.keys(entry.filters).length > 0 && Number(entry.savedAt || 0) > 0 &&
        Date.now() - Number(entry.savedAt || 0) <= HOME_FILTERS_TTL_MS;
}

function getHomeFilters(sourceId) {
    var cacheKey = String(sourceId || "");
    var cached = homeFiltersCache.get(cacheKey);
    if (cached && Date.now() - Number(cached.savedAt || 0) <= HOME_FILTERS_TTL_MS) {
        return clone(cached.filters || {});
    }
    try {
        var stored = JSON.parse(String(getMyVar(homeFiltersStateKey(cacheKey), "") || "{}"));
        if (validHomeFiltersEntry(stored, cacheKey)) {
            homeFiltersCache.set(cacheKey, {savedAt: Number(stored.savedAt || Date.now()), filters: clone(stored.filters)});
            return clone(stored.filters);
        }
    } catch (ignoreHomeFiltersStateError) {}
    try {
        var persisted = readJson(homeFiltersFilePath(cacheKey), null);
        if (validHomeFiltersEntry(persisted, cacheKey)) {
            var persistedEntry = {savedAt: Number(persisted.savedAt), filters: clone(persisted.filters)};
            homeFiltersCache.set(cacheKey, persistedEntry);
            try { putMyVar(homeFiltersStateKey(cacheKey), JSON.stringify(persisted)); } catch (ignoreHomeFiltersRestoreError) {}
            return clone(persisted.filters);
        }
        if (persisted) {
            try { deleteFile(homeFiltersFilePath(cacheKey)); } catch (ignoreExpiredHomeFiltersDeleteError) {}
        }
    } catch (ignoreHomeFiltersFileError) {}
    try {
        var cachedHome = readPrefetchedCategory(cacheKey, "", "1", HOME_FILTERS_TTL_MS, {});
        var cachedFilters = cachedHome && cachedHome.filters && typeof cachedHome.filters === "object"
            ? cachedHome.filters : {};
        if (Object.keys(cachedFilters).length) {
            cacheHomeFilters(cacheKey, cachedFilters);
            return clone(cachedFilters);
        }
    } catch (ignoreHomeFiltersMigrationError) {}
    return {};
}

function cacheHomeFilters(sourceId, filters) {
    var cacheKey = String(sourceId || "");
    var normalized = filters && typeof filters === "object" ? filters : {};
    if (!Object.keys(normalized).length) return;
    var entry = {
        version: HOME_FILTERS_CACHE_VERSION,
        buildVersion: String(BUILD_VERSION),
        sourceId: cacheKey,
        savedAt: Date.now(),
        filters: clone(normalized)
    };
    homeFiltersCache.set(cacheKey, {savedAt: entry.savedAt, filters: clone(entry.filters)});
    try { putMyVar(homeFiltersStateKey(cacheKey), JSON.stringify(entry)); } catch (ignoreHomeFiltersSaveError) {}
    try { writeJson(homeFiltersFilePath(cacheKey), entry); } catch (ignoreHomeFiltersFileSaveError) {}
}

function clearHomeFilters(sourceId) {
    var cacheKey = String(sourceId || "");
    homeFiltersCache.delete(cacheKey);
    try { putMyVar(homeFiltersStateKey(cacheKey), ""); } catch (ignoreHomeFiltersClearError) {}
    try { deleteFile(homeFiltersFilePath(cacheKey)); } catch (ignoreHomeFiltersFileClearError) {}
}

function clearAllHomeFiltersFiles() {
    try {
        var directory = new java.io.File(normalizeFolderPath(DATA_ROOT));
        var listed = directory.listFiles();
        if (!listed) return;
        var prefix = homeFiltersFilePrefix();
        for (var index = 0; index < listed.length; index++) {
            var file = listed[index];
            var name = String(file.getName());
            if (startsWith(name, prefix) && endsWith(name, ".json")) {
                try { file.delete(); } catch (ignoreHomeFiltersFileDeleteError) {}
            }
        }
    } catch (ignoreAllHomeFiltersFilesClearError) {}
}

function homeVideoSource(sourceId, tid, page) {
    var originalError = null;
    var result = {list: []};
    var currentPage = String(page || "1");
    try {
        var candidates = currentPage === "1" ? [[]] : [[currentPage]];
        result = normalizePageResult(callSourceCompatible(sourceId, ["homeVideoContent", "getHomeVideoContent"], candidates), sourceId);
    } catch (error) {
        originalError = error;
    }
    if (result.list.length) {
        try { result.list = enrichVodListFromGeneric(sourceId, result.list, tid || "", currentPage); } catch (ignoreHomeVideoEnrichError) {}
    } else {
        try { result = genericListResult(sourceId, tid || "", currentPage); } catch (ignoreGenericHomeVideoError) {}
    }
    if (!result.list.length && originalError) throw originalError;
    return result;
}

function categorySource(sourceId, tid, page, filterable, extend) {
    var originalError = null;
    var result = {list: []};
    try {
        result = normalizePageResult(callSourceCompatible(sourceId, ["categoryContent"], [
            [String(tid || ""), String(page || 1), filterable !== false, extend || {}]
        ]), sourceId);
    } catch (error) {
        originalError = error;
    }
    if (result.list.length) {
        try { result.list = enrichVodListFromGeneric(sourceId, result.list, tid, page); } catch (ignoreCategoryEnrichError) {}
    } else {
        try {
            result = genericListResult(sourceId, tid, page);
        } catch (ignoreGenericListError) {}
    }
    if (!result.list.length && originalError) throw originalError;
    if (String(page || "1") === "1") {
        savePrefetchedCategory(sourceId, tid, "1", result, extend || {});
    }
    return result;
}

function firstPlayId(vod) {
    var raw = String(vod && vod.vod_play_url || "");
    var first = raw.split("$$$")[0].split("#")[0];
    var separator = first.indexOf("$");
    return separator >= 0 ? first.slice(separator + 1) : first;
}

function isImageMediaUrl(url) {
    return /\.(?:jpe?g|png|webp|gif|bmp|avif)(?:$|[?#&])/i.test(String(url || ""));
}

function isDirectMediaUrl(url) {
    // 允许媒体 URL 尾部带斜杠（如 get_file/..._2160m.mp4/）：很多源在 mp4/m3u8 后
    // 追加 /，若按严格结尾判断会误判为非直链，触发 generic 兜底覆盖多分辨率剧集。
    return /\.(?:m3u8|mp4|flv|mkv|avi|mov|webm)(?:$|[?#&/])/i.test(String(url || ""));
}

function detailNameNeedsFallback(name, vodId) {
    var text = String(name || "").trim();
    return !text || /^https?:\/\//i.test(text) || text === String(vodId || "") || /^未命名(?:\s*\d+)?$/i.test(text);
}

function detailPlayNeedsFallback(vod, vodId) {
    var playId = firstPlayId(vod);
    if (!playId || isImageMediaUrl(playId)) return true;
    if (String(playId) === String(vodId || "")) return true;
    return /^https?:\/\//i.test(playId) && !isDirectMediaUrl(playId) && /(?:\/$|\.(?:html?|php)(?:$|[?#]))/i.test(playId);
}

function detailSource(sourceId, vodId, hints) {
    hints = hints || {};
    var cacheKey = String(sourceId || "") + "@" + md5(String(vodId || ""));
    var originalError = null;
    var result = {list: []};

    try {
        result = normalizePageResult(callSourceCompatible(sourceId, ["detailContent"], [
            [[String(vodId || "")]],
            [String(vodId || "")]
        ]));
    } catch (error) {
        originalError = error;
    }

    var current = result.list[0] || null;
    var currentName = current ? String(current.vod_name || "") : "";
    var hasListTitle = !!String(hints.name || "").trim();
    var hasListPic = !!String(hints.pic || "").trim();
    var needsFallback = !current ||
        (detailNameNeedsFallback(currentName, vodId) && !hasListTitle) ||
        detailPlayNeedsFallback(current, vodId) ||
        (!String(current.vod_pic || "") && !hasListPic);
    if (needsFallback) {
        try {
            var fallback = normalizePageResult(callSourceCompatible(sourceId, ["genericVideoDetail"], [
                [String(vodId || "")]
            ]));
            var genericVod = fallback.list[0] || null;
            if (!current && genericVod) {
                result.list = [genericVod];
            } else if (current && genericVod) {
                var replacePlay = detailPlayNeedsFallback(current, vodId) && !detailPlayNeedsFallback(genericVod, vodId);
                Object.keys(genericVod).forEach(function(key) {
                    var emptyName = key === "vod_name" && detailNameNeedsFallback(current[key], vodId);
                    var playField = replacePlay && (key === "vod_play_url" || key === "vod_play_from");
                    if (emptyName || playField || current[key] === undefined || current[key] === null || String(current[key]) === "") {
                        current[key] = genericVod[key];
                    }
                });
            }
        } catch (ignoreGenericDetailError) {}
    }

    // 列表缓存兜底：源 detailContent 依赖自身内存缓存（如 March self.items）
    // 且详情阶段缓存丢失时，用列表页缓存过的原始 vod 数据构造兜底详情，
    // 保证"有标题、有封面、有播放地址"的基本可用性。
    var currentAfter = result.list[0] || null;
    if (!currentAfter || detailPlayNeedsFallback(currentAfter, vodId)) {
        try {
            var rawVod = getVodRawCached(sourceId, vodId);
            if (rawVod) {
                var fallbackVod = normalizeVod(rawVod, 0);
                // 源列表项通常含 url/play_url 字段，构造可用的播放地址
                if (!fallbackVod.vod_play_url) {
                    var rawUrl = String(rawVod.url || rawVod.play_url || rawVod.playUrl || rawVod.video_url || "");
                    if (rawUrl) fallbackVod.vod_play_url = "播放$" + rawUrl;
                }
                if (!fallbackVod.vod_play_from) fallbackVod.vod_play_from = "官方线路";
                if (!currentAfter) {
                    result.list = [fallbackVod];
                } else {
                    var replaceRawPlay = detailPlayNeedsFallback(currentAfter, vodId) && fallbackVod.vod_play_url;
                    Object.keys(fallbackVod).forEach(function(key) {
                        var emptyField = currentAfter[key] === undefined || currentAfter[key] === null || String(currentAfter[key]) === "";
                        var playField = replaceRawPlay && (key === "vod_play_url" || key === "vod_play_from");
                        if (emptyField || playField) currentAfter[key] = fallbackVod[key];
                    });
                }
            }
        } catch (ignoreRawVodFallbackError) {}
    }

    if (result.list.length) {
        detailCache.set(cacheKey, {savedAt: Date.now(), value: clone(result)});
        return result;
    }

    var cached = detailCache.get(cacheKey);
    if (cached && Date.now() - Number(cached.savedAt || 0) <= 30 * 60 * 1000) {
        return clone(cached.value);
    }
    if (originalError) throw originalError;
    return result;
}

function searchSource(sourceId, keyword, page) {
    var originalError = null;
    var result = {list: []};
    try {
        result = normalizePageResult(callSourceCompatible(sourceId, ["searchContentPage", "searchContent"], [
            [String(keyword || ""), false, String(page || 1)],
            [String(keyword || ""), false]
        ]), sourceId);
    } catch (error) {
        originalError = error;
    }
    if (result.list.length) {
        try {
            result.list = enrichVodListFromGeneric(sourceId, result.list, "search/" + encodeURIComponent(String(keyword || "")), page);
        } catch (ignoreSearchEnrichError) {}
    } else {
        try {
            result = genericListResult(sourceId, "search/" + encodeURIComponent(String(keyword || "")), page);
        } catch (ignoreGenericSearchError) {}
    }
    if (!result.list.length && originalError) throw originalError;
    return result;
}

function inspectSource(source) {
    if (isExternalSource(source)) return getExternalRuntime().inspect(source);
    var runtime = getRuntime();
    var spider = createSpider(source);
    var name = "";
    try {
        name = String(runtime.callFunc(spider, "getName") || "");
    } catch (ignoreNameError) {}
    return {name: name || source.fileName || source.id};
}

function compatibilityReport(sourceId) {
    var source = typeof sourceId === "object" ? sourceId : getSource(sourceId);
    if (isExternalSource(source)) return getExternalRuntime().inspect(source).report;
    var report = getRuntime().inspectSourceFile(source.path) || {};
    report.imports = Array.isArray(report.imports) ? report.imports : [];
    report.missing = Array.isArray(report.missing) ? report.missing : [];
    report.warnings = Array.isArray(report.warnings) ? report.warnings : [];
    return report;
}

function checkSource(sourceId) {
    var source = typeof sourceId === "object" ? sourceId : getSource(sourceId);
    if (isExternalSource(source)) return getExternalRuntime().inspect(source);
    var report = compatibilityReport(source);
    if (report.syntaxError) throw new Error("PY 语法错误: " + report.syntaxError);
    var inspected = inspectSource(source);
    return {name: inspected.name, report: report};
}

// 把海阔图片地址中的 @Referer/@User-Agent/@Cookie/@headers 标记还原为
// Java URLConnection 请求头。@js 属于图片组件执行逻辑，连通性抽检只取它前面的
// 真实 URL；已知加密格式仍由下方统一解密管线检查。
function parseHikerImageRequest(value, sourceId, fallbackReferer) {
    var text = String(value || "").trim();
    var headers = sourceImageHeaders(sourceId, fallbackReferer || text);
    var matches = [];
    var pattern = /@(Referer|User-Agent|Cookie|headers|js)=/ig;
    var matched;
    while ((matched = pattern.exec(text)) !== null) {
        matches.push({index: matched.index, valueIndex: pattern.lastIndex, name: String(matched[1] || "")});
        if (String(matched[1] || "").toLowerCase() === "js") break;
    }
    var requestUrl = matches.length ? text.slice(0, matches[0].index) : text;
    for (var i = 0; i < matches.length; i++) {
        var marker = matches[i];
        var name = String(marker.name || "");
        if (name.toLowerCase() === "js") break;
        var end = i + 1 < matches.length ? matches[i + 1].index : text.length;
        var markerValue = text.slice(marker.valueIndex, end);
        if (name.toLowerCase() === "headers") {
            try {
                var extraHeaders = JSON.parse(markerValue || "{}");
                Object.keys(extraHeaders || {}).forEach(function(key) {
                    headers[key] = String(extraHeaders[key]);
                });
            } catch (ignoreImageMarkerHeaderError) {}
        } else if (markerValue) {
            headers[name] = markerValue;
        }
    }
    return {url: requestUrl, headers: headers, hasJs: /@js=/i.test(text)};
}

function proxyImageVerifyParams(value, sourceId, target) {
    var params = {};
    var text = String(value || "");
    var queryIndex = text.indexOf("?");
    if (queryIndex >= 0) {
        text.slice(queryIndex + 1).split("#", 1)[0].split("&").forEach(function(part) {
            if (!part) return;
            var split = part.indexOf("=");
            var rawKey = split >= 0 ? part.slice(0, split) : part;
            var rawValue = split >= 0 ? part.slice(split + 1) : "";
            var key;
            var item;
            try { key = decodeURIComponent(rawKey); } catch (ignoreVerifyProxyKeyError) { key = rawKey; }
            try { item = decodeURIComponent(rawValue); } catch (ignoreVerifyProxyValueError) { item = rawValue; }
            if (params[key] === undefined) params[key] = item;
        });
    }
    var headers = sourceImageHeaders(sourceId, target);
    try {
        var proxyHeaders = JSON.parse(String(params.__img_headers || "{}"));
        Object.keys(proxyHeaders || {}).forEach(function(key) { headers[key] = String(proxyHeaders[key]); });
    } catch (ignoreVerifyProxyHeaderError) {}
    return {
        __direct_img: target,
        __img_headers: JSON.stringify(headers),
        __img_fallback: String(params.__img_fallback || ""),
        __img_route: String(params.__img_route || "")
    };
}

function verifySourceImageCandidate(sourceId, vod) {
    var rawPic = String(vod && vod.vod_pic || "");
    // 与首页/分类真实渲染保持一致，vod_id 也按 UI 原样传入。
    var url = listImageUrl(sourceId, rawPic, String(vod && vod.vod_id || ""));
    if (/^(?:data:|hiker:\/\/|file:\/\/)/i.test(url)) {
        return {ok: true, skipped: true, reason: "本地图片无需检测", url: url.slice(0, 60)};
    }
    var requestSpec = parseHikerImageRequest(url, sourceId, rawPic);
    var fetchUrl = String(requestSpec.url || "");
    if (requestSpec.hasJs) {
        return {ok: true, skipped: true, reason: "图片由壳内解码", url: fetchUrl.slice(0, 60)};
    }
    if (!/^https?:\/\//i.test(fetchUrl)) {
        return {ok: true, skipped: true, reason: "非常规图片地址", url: fetchUrl.slice(0, 60)};
    }
    var isLocalProxy = localProxyUrlMatches(fetchUrl);
    try {
        if (isLocalProxy) {
            // 本地代理 URL：从查询参数提取直连目标，用与图片桥一致的参数等效验证。
            var target = proxyImageTarget(fetchUrl);
            if (target) {
                var result = fetchDirectProxyImage(proxyImageVerifyParams(fetchUrl, sourceId, target));
                if (Array.isArray(result) && result.length >= 3) {
                    var proxyStatus = Number(result[0]);
                    var proxyMime = String(result[1] || "");
                    var proxyBody = result[2];
                    var proxyOk = proxyStatus >= 200 && proxyStatus < 300 && /^image\//i.test(proxyMime);
                    return proxyOk
                        ? {ok: true, mime: proxyMime, bytes: Number(proxyBody && proxyBody.length || 0), url: target.slice(0, 80)}
                        : {ok: false, error: String(result[2] || "图片解码失败").slice(0, 160), url: target.slice(0, 80)};
                }
            }
            return {ok: false, error: "代理图片参数无法解析", url: fetchUrl.slice(0, 80)};
        }

        var connection = null;
        var inputStream = null;
        try {
            connection = new java.net.URL(fetchUrl).openConnection();
            applyInsecureSsl(connection);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(20000);
            if (connection.setInstanceFollowRedirects) connection.setInstanceFollowRedirects(true);
            Object.keys(requestSpec.headers || {}).forEach(function(key) {
                var value = requestSpec.headers[key];
                if (value !== undefined && value !== null && String(value) !== "") {
                    try { connection.setRequestProperty(String(key), String(value)); } catch (ignoreCheckImageHeaderError) {}
                }
            });
            var status = connection.getResponseCode ? Number(connection.getResponseCode()) : 200;
            inputStream = status >= 400 && connection.getErrorStream ? connection.getErrorStream() : connection.getInputStream();
            if (!inputStream) return {ok: false, error: "HTTP " + status + " 无响应体", url: fetchUrl.slice(0, 80)};
            var output = new java.io.ByteArrayOutputStream();
            var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
            var length;
            while ((length = inputStream.read(buffer)) !== -1) {
                if (length > 0) output.write(buffer, 0, length);
                if (output.size() > 64 * 1024 * 1024) {
                    try { if (inputStream) inputStream.close(); } catch (ignoreCheckImageInputCloseError) {}
                    return {ok: false, error: "图片超过 64MB", url: fetchUrl.slice(0, 80)};
                }
            }
            var body = output.toByteArray();
            // 与 fetchDirectProxyImage 一致：data URL 解码 + AES 自动解密。
            var decoded = bhDataUrlDecode(body);
            if (decoded) body = decoded;
            else body = autoDecodeImageBytes(body);
            var mime = proxyImageMagic(body);
            if (status >= 200 && status < 300 && mime) {
                return {ok: true, mime: mime, bytes: Number(body && body.length || 0), url: fetchUrl.slice(0, 80)};
            }
            var head = "";
            for (var index = 0; index < Math.min(Number(body && body.length || 0), 32); index++) {
                var hex = (Number(body[index]) & 255).toString(16);
                head += hex.length < 2 ? "0" + hex : hex;
            }
            return {ok: false, error: "HTTP " + status + " 非图片内容 head=" + head.slice(0, 24), url: fetchUrl.slice(0, 80)};
        } catch (imageFetchError) {
            return {ok: false, error: errorText(imageFetchError).slice(0, 160), url: fetchUrl.slice(0, 80)};
        } finally {
            try { if (inputStream) inputStream.close(); } catch (ignoreCheckImageInputCloseError) {}
            try { if (connection && connection.disconnect) connection.disconnect(); } catch (ignoreCheckImageDisconnectError) {}
        }
    } catch (imageVerifyError) {
        return {ok: false, error: errorText(imageVerifyError).slice(0, 160), url: fetchUrl.slice(0, 80)};
    }
}

// 图片完整性检测最多抽样三张不同封面。任一张通过即说明图片链路可用，
// 避免第一张过期/防盗链单图把整个正常源误报为 HTTP 404。
function verifySourceImage(sourceId, list) {
    var listItems = Array.isArray(list) ? list : [];
    var candidates = [];
    var seen = {};
    for (var i = 0; i < listItems.length && candidates.length < 3; i++) {
        var candidate = listItems[i] || {};
        var rawPic = String(candidate.vod_pic || "");
        if (!rawPic || seen[rawPic]) continue;
        seen[rawPic] = true;
        candidates.push(candidate);
    }
    if (!candidates.length) return {ok: true, skipped: true, reason: "列表没有封面图"};

    var failures = [];
    var skipped = [];
    for (var index = 0; index < candidates.length; index++) {
        var result = verifySourceImageCandidate(sourceId, candidates[index]);
        result.sampled = candidates.length;
        result.sampleIndex = index + 1;
        if (result.ok && !result.skipped) return result;
        if (result.skipped) skipped.push(result);
        else failures.push(result);
    }
    if (!failures.length) {
        return {ok: true, skipped: true, reason: skipped[0] && skipped[0].reason || "图片无需检测", sampled: candidates.length};
    }
    var messages = failures.map(function(item) { return String(item.error || "未知响应"); });
    return {
        ok: false,
        sampled: candidates.length,
        error: "抽检" + failures.length + "张未通过：" + messages.join("；").slice(0, 220),
        url: failures[0] && failures[0].url || ""
    };
}

function checkSourceConnectivity(sourceId) {
    var startedAt = Date.now();
    var source = getSource(sourceId);
    checkSource(source);
    var lastError = null;
    var home = {class: [], list: []};

    // 图片验证：复用真实列表图片管线，最多抽样三张，任意一张成功即通过。
    function buildResult(stage, list) {
        var imageResult = verifySourceImage(source.id, list);
        var detail = "列表 " + Number(list && list.length || 0) + " 条";
        if (!imageResult.skipped && imageResult.ok) {
            detail += " · 图片正常";
            if (imageResult.mime) detail += "(" + imageResult.mime + ")";
        } else if (!imageResult.skipped) {
            // 列表已由真实壳入口加载成功时，独立封面探针只作为附加诊断。
            // 防盗链、短期 URL 或 Glide/壳内解码差异产生的 404 不应误导为源异常。
            detail += " · 图片链路待确认";
        } else if (imageResult.reason) {
            detail += " · " + imageResult.reason;
        }
        return {
            ok: true,
            sourceId: source.id,
            sourceName: source.name,
            stage: stage,
            count: Number(list && list.length || 0),
            elapsed: Date.now() - startedAt,
            imageOk: imageResult.ok,
            imageError: imageResult.error || "",
            detail: detail
        };
    }

    // 检测必须复用页面真实入口。部分 PY 源的原始 home/category 方法会返回
    // HTTP 404，但壳子的通用列表兜底仍能正常加载；直接探测原始方法会误报。
    try {
        home = homeSource(source.id, true) || home;
        if (home.list.length) {
            return buildResult("首页", home.list);
        }
    } catch (error) {
        lastError = error;
    }

    try {
        var cachedClasses = home.class && home.class.length ? home.class : getHomeClasses(source.id);
        var firstHomeClass = cachedClasses[0] || {};
        var homeVideo = homeVideoSource(source.id, firstHomeClass.type_id || "", "1") || {list: []};
        if (homeVideo.list.length) {
            return buildResult("推荐", homeVideo.list);
        }
    } catch (error) {
        lastError = error;
    }

    var firstClass = (home.class && home.class[0]) || (getHomeClasses(source.id)[0]) || {};
    if (firstClass.type_id !== undefined && firstClass.type_id !== null && String(firstClass.type_id) !== "") {
        try {
            var category = categorySource(source.id, String(firstClass.type_id), "1", true, {}) || {list: []};
            if (category.list.length) {
                return buildResult("分类", category.list);
            }
        } catch (error) {
            lastError = error;
        }
    }

    return {
        ok: false,
        sourceId: source.id,
        sourceName: source.name,
        stage: "源站",
        count: 0,
        elapsed: Date.now() - startedAt,
        error: lastError ? errorText(lastError) : "源站没有返回内容"
    };
}

function removeSources(sourceIds) {
    var ids = Array.isArray(sourceIds) ? sourceIds.map(function(sourceId) { return String(sourceId || ""); }) : [];
    var idMap = {};
    ids.forEach(function(sourceId) { if (sourceId) idMap[sourceId] = true; });
    var records = getAllSourceRecords().filter(function(source) { return !!idMap[source.id]; });
    if (!records.length) return 0;
    records.forEach(function(source) { removeSource(source.id); });
    return records.length;
}

function isSourceEnabled(source) {
    return source && source.enabled !== false;
}

function setSourceEnabled(sourceId, enabled) {
    var record = findSourceRecord(sourceId);
    if (!record) throw new Error("视频源不存在");
    record.source.enabled = !!enabled;
    saveSourceRecord(record);
    if (!enabled && getActiveSourceId() === String(sourceId)) {
        var firstEnabled = getAllSourceRecords().find(function(item) { return item.id !== sourceId && isSourceEnabled(item); });
        setActiveSourceId(firstEnabled ? firstEnabled.id : "");
    }
    resetSourceRuntime(sourceId);
    return record.source;
}

// 从 PY 源代码中提取源站域名（用于去重检测）。
// 优先级：self.host / host / baseUrl / base_url / self._host 等赋值语句；
// 找不到则取源码中出现次数最多的 http(s) 域名。
function sourceDomain(source) {
    var domain = "";
    if (isExternalSource(source)) {
        var externalAddress = String(source.api || source.remoteUrl || source.path || source.ext || "");
        var externalMatch = externalAddress.match(/^https?:\/\/([^\/?#]+)/i);
        return externalMatch ? String(externalMatch[1]).replace(/:\d+$/, "").toLowerCase() : "";
    }
    try {
        var code = request(source.path) || "";
        var patterns = [
            /(?:self\.)?(?:host|baseUrl|base_url|BASE_URL|HOST)\s*=\s*["'](https?:\/\/[^"']+)["']/i,
            /["'](https?:\/\/[^"']+)["']\s*(?:,\s*)?#\s*(?:主站|域名|host)/i
        ];
        for (var i = 0; i < patterns.length; i++) {
            var m = code.match(patterns[i]);
            if (m) { domain = m[1]; break; }
        }
        if (!domain) {
            var hosts = {};
            var all = code.match(/https?:\/\/[a-zA-Z0-9.\-]+/g) || [];
            all.forEach(function(url) {
                var host = String(url).replace(/^https?:\/\//i, "").split("/")[0].toLowerCase();
                if (hosts[host]) hosts[host]++;
                else hosts[host] = 1;
            });
            var best = "";
            var bestCount = 0;
            for (var host in hosts) {
                if (hosts[host] > bestCount) { best = host; bestCount = hosts[host]; }
            }
            domain = best;
        }
    } catch (ignoreDomainError) {}
    return String(domain || "").replace(/^https?:\/\//i, "").split("/")[0].toLowerCase();
}

// 去重检测：按源站域名分组，返回 { domain: [sourceId, ...] }，仅包含域名相同的组
function detectDuplicateDomains() {
    var index = getIndex();
    var groups = {};
    index.sources.forEach(function(source) {
        var domain = sourceDomain(source);
        if (!domain) return;
        if (!groups[domain]) groups[domain] = [];
        groups[domain].push(String(source.id));
    });
    var result = {};
    for (var domain in groups) {
        if (groups[domain].length > 1) result[domain] = groups[domain];
    }
    return result;
}

// 源管理统计：{total, enabled, disabled, duplicate}
function getSourceStats() {
    var index = getIndex();
    var total = index.sources.length;
    var enabled = 0;
    var disabled = 0;
    var duplicateIds = {};
    var duplicates = detectDuplicateDomains();
    for (var domain in duplicates) {
        duplicates[domain].forEach(function(id) { duplicateIds[id] = true; });
    }
    index.sources.forEach(function(source) {
        if (isSourceEnabled(source)) enabled++;
        else disabled++;
    });
    return {
        total: total,
        enabled: enabled,
        disabled: disabled,
        duplicate: Object.keys(duplicateIds).length
    };
}

function safeShareFileName(name, fallback) {
    var value = String(name || fallback || "source.py")
        .replace(/[\\\/:*?"<>|\u0000-\u001f]/g, "_")
        .replace(/^\s+|\s+$/g, "");
    if (!value) value = String(fallback || "source.py");
    if (!/\.py$/i.test(value)) value += ".py";
    return value;
}

function uniqueShareFileName(name, usedNames) {
    var candidate = name;
    var lower = candidate.toLowerCase();
    var suffix = 2;
    while (usedNames[lower]) {
        candidate = name.replace(/\.py$/i, "_" + suffix + ".py");
        lower = candidate.toLowerCase();
        suffix++;
    }
    usedNames[lower] = true;
    return candidate;
}

function shareRealPath(path) {
    var real = String(getPath(path) || path || "");
    return real.replace(/^file:\/\//, "");
}

function isLocalShareSource(source) {
    var kind = sourceRuntimeKind(source);
    if (kind !== "py" && kind !== "drpy" && kind !== "js") return false;
    if (source.managedLocal === false) return false;
    return !!source.path && fileExist(source.path);
}

function sourceShareSite(source) {
    var kind = sourceRuntimeKind(source);
    var site = {
        key: String(source.id || "source"),
        name: String(source.name || source.fileName || source.id || "视频源"),
        api: String(source.api || source.path || "")
    };
    if (kind === "t4") site.type = 4;
    else if (kind === "cms") site.type = Number(source.cmsType === undefined ? 1 : source.cmsType);
    else if (kind === "drpy" || kind === "js") {
        site.type = 3;
        site.ext = String(source.remoteUrl || source.path || source.ext || "");
    } else {
        site.type = 3;
        site.api = String(source.remoteUrl || source.path || site.api);
        site.ext = String(source.ext || "");
    }
    if (source.ext !== undefined && source.ext !== "" && site.ext === undefined) site.ext = source.ext;
    return site;
}

function createSourcesShare(sourceIds) {
    var ids = Array.isArray(sourceIds) ? sourceIds.map(function(sourceId) { return String(sourceId || ""); }) : [];
    var idMap = {};
    ids.forEach(function(sourceId) { if (sourceId) idMap[sourceId] = true; });
    var selected = getIndex().sources.filter(function(source) { return !!idMap[source.id]; });
    if (!selected.length) throw new Error("请先选择要分享的视频源");

    var stamp = String(Date.now());
    if (selected.length === 1) {
        var single = selected[0];
        var localSingle = isLocalShareSource(single);
        var kind = sourceRuntimeKind(single);
        var fallbackExt = kind === "drpy" || kind === "js" ? ".js" : ".py";
        var singleName = safeShareFileName(single.fileName || single.name, single.id + fallbackExt);
        if (!localSingle) singleName = safeShareFileName(single.name, single.id) + ".json";
        var singlePath = SHARE_ROOT + "/PY影视源_" + singleName;
        writeFile(singlePath, localSingle
            ? request(single.path)
            : JSON.stringify({sites: [sourceShareSite(single)]}, null, 2));
        if (!fileExist(singlePath)) throw new Error("分享文件生成失败");
        return {path: singlePath, count: 1, type: localSingle ? kind : "config", names: [single.name]};
    }

    var sharePath = SHARE_ROOT + "/PY影视源_共" + selected.length + "个_" + stamp + ".zip";
    var output = null;
    var usedNames = {};
    var manifest = {version: 2, type: "video_sources", count: selected.length, createdAt: Date.now(), sources: []};
    var externalSites = [];
    try {
        var realPath = shareRealPath(sharePath);
        var shareFile = new java.io.File(realPath);
        var parent = shareFile.getParentFile();
        if (parent && !parent.exists()) parent.mkdirs();
        output = new java.util.zip.ZipOutputStream(new java.io.BufferedOutputStream(new java.io.FileOutputStream(shareFile)));
        selected.forEach(function(source) {
            var kind = sourceRuntimeKind(source);
            if (!isLocalShareSource(source)) {
                var site = sourceShareSite(source);
                externalSites.push(site);
                manifest.sources.push({id: source.id, name: source.name, runtime: kind, config: site});
                return;
            }
            var fallbackExt = kind === "drpy" || kind === "js" ? ".js" : ".py";
            var fileName = uniqueShareFileName(safeShareFileName(source.fileName || source.name, source.id + fallbackExt), usedNames);
            var code = String(request(source.path) || "");
            var bytes = new java.lang.String(code).getBytes("UTF-8");
            output.putNextEntry(new java.util.zip.ZipEntry(fileName));
            output.write(bytes, 0, bytes.length);
            output.closeEntry();
            manifest.sources.push({id: source.id, name: source.name, runtime: kind, fileName: fileName, md5: source.md5 || md5(code)});
        });
        if (externalSites.length) {
            var configBytes = new java.lang.String(JSON.stringify({sites: externalSites}, null, 2)).getBytes("UTF-8");
            output.putNextEntry(new java.util.zip.ZipEntry("外部视频源配置.json"));
            output.write(configBytes, 0, configBytes.length);
            output.closeEntry();
        }
        var manifestBytes = new java.lang.String(JSON.stringify(manifest, null, 2)).getBytes("UTF-8");
        output.putNextEntry(new java.util.zip.ZipEntry("PY影视源清单.json"));
        output.write(manifestBytes, 0, manifestBytes.length);
        output.closeEntry();
    } finally {
        if (output) try { output.close(); } catch (ignoreCloseShareError) {}
    }
    if (!fileExist(sharePath) || new java.io.File(shareRealPath(sharePath)).length() <= 0) {
        throw new Error("分享压缩包生成失败");
    }
    return {
        path: sharePath,
        count: selected.length,
        type: "zip",
        names: selected.map(function(source) { return source.name; })
    };
}

function normalizeInputPath(path) {
    var value = String(path || "");
    if (startsWith(value, "hiker://") || startsWith(value, "file://")) return value;
    return "file://" + value;
}

function cleanSelectedName(path) {
    var name = String(path || "").split(/[\\/]/).pop() || "source.py";
    name = name.replace(/^_fileSelect_/, "");
    return name;
}

function importSource(selectedPath) {
    var fileName = cleanSelectedName(selectedPath);
    if (!/\.py$/i.test(fileName)) throw new Error("请选择 .py 文件");
    var code = request(normalizeInputPath(selectedPath));
    if (code && code.charCodeAt(0) === 0xfeff) code = code.slice(1);
    if (!/class\s+Spider\s*[(:]/.test(code || "")) throw new Error("没有找到 Spider 类");

    var digest = md5(code);
    var id = "py_" + digest.slice(0, 16);
    var target = SOURCE_ROOT + "/" + id + ".py";
    writeFile(target, code);
    var source = {
        id: id,
        name: fileName.replace(/\.py$/i, ""),
        fileName: fileName,
        path: target,
        ext: "",
        builtIn: false,
        importedAt: Date.now(),
        md5: digest
    };
    try {
        var checked = checkSource(source);
        source.name = checked.name || source.name;
        source.warnings = checked.report.warnings || [];
        // 缺失依赖明确报出，便于用户判断源为何无法打开
        var missingDeps = (checked.report.missing || []).filter(function(moduleName) {
            return !/^(re|json|sys|os|time|base64|hashlib|urllib|requests|Crypto|pyquery|bs4|lxml|base|t4|app|hiker|fastjson|java|com|org)$/i.test(String(moduleName));
        });
        if (missingDeps.length) {
            source.warnings = (source.warnings || []).concat("可能缺失依赖: " + missingDeps.join(", "));
        }
    } catch (error) {
        try { deleteFile(target); } catch (ignoreDeleteError) {}
        throw new Error("PY 加载失败: " + errorText(error));
    }

    var index = getIndex();
    var oldIndex = index.sources.findIndex(function(item) { return item.id === id; });
    if (oldIndex >= 0) {
        var oldSource = index.sources[oldIndex] || {};
        if (oldSource.customName) {
            source.originalName = oldSource.originalName || source.name;
            source.customName = String(oldSource.customName);
            source.name = source.customName;
        }
        index.sources[oldIndex] = source;
    } else index.sources.push(source);
    index.current = id;
    saveIndex(index);
    return source;
}

function displayFileName(location, fallback) {
    var value = String(location || "").replace(/[?#].*$/, "");
    var name = value.split(/[\\/]/).pop() || fallback || "视频源";
    try { name = decodeURIComponent(name); } catch (ignoreNameDecodeError) {}
    return name.replace(/^_fileSelect_/, "");
}

function upsertLineSource(source, makeCurrent) {
    var store = getLineSourceIndex();
    var oldIndex = store.sources.findIndex(function(item) { return String(item.id) === String(source.id); });
    if (oldIndex >= 0) {
        var oldSource = store.sources[oldIndex] || {};
        source.enabled = oldSource.enabled !== false;
        if (oldSource.customName) {
            source.originalName = oldSource.originalName || source.name;
            source.customName = oldSource.customName;
            source.name = oldSource.customName;
        }
        store.sources[oldIndex] = Object.assign({}, oldSource, source);
    } else {
        source.enabled = true;
        store.sources.push(source);
    }
    if (makeCurrent || !store.current) store.current = source.id;
    saveLineSourceIndex(store);
    if (makeCurrent) setActiveSourceId(source.id);
    resetSourceRuntime(source.id);
    return findSourceRecord(source.id).source;
}

function upsertImportedSource(source, makeCurrent) {
    if (source && source.lineId) return upsertLineSource(source, makeCurrent);
    var index = getIndex();
    var oldIndex = index.sources.findIndex(function(item) { return String(item.id) === String(source.id); });
    if (oldIndex >= 0) {
        var oldSource = index.sources[oldIndex] || {};
        source.enabled = oldSource.enabled !== false;
        if (oldSource.customName) {
            source.originalName = oldSource.originalName || source.name;
            source.customName = oldSource.customName;
            source.name = oldSource.customName;
        }
        index.sources[oldIndex] = Object.assign({}, oldSource, source);
    } else {
        source.enabled = true;
        index.sources.push(source);
    }
    if (makeCurrent || !index.current) index.current = source.id;
    saveIndex(index);
    if (makeCurrent) setActiveSourceId(source.id);
    resetSourceRuntime(source.id);
    return findSourceRecord(source.id).source;
}

function importPyCode(code, name, metadata) {
    metadata = metadata || {};
    code = String(code || "");
    if (code && code.charCodeAt(0) === 0xfeff) code = code.slice(1);
    if (!/class\s+Spider\s*[(:]/.test(code)) throw new Error("没有找到 Spider 类");
    var digest = md5(code);
    var id = "py_" + digest.slice(0, 16);
    var fileName = String(name || "source.py").replace(/\.py$/i, "") + ".py";
    var target = SOURCE_ROOT + "/" + id + ".py";
    writeFile(target, code);
    var source = {
        id: id,
        name: fileName.replace(/\.py$/i, ""),
        fileName: fileName,
        path: target,
        runtime: "py",
        api: metadata.api || metadata.remoteUrl || "",
        ext: metadata.ext || "",
        lineId: metadata.lineId || "",
        remoteUrl: metadata.remoteUrl || "",
        builtIn: false,
        importedAt: Date.now(),
        md5: digest,
        managedLocal: true
    };
    try {
        var checked = checkSource(source);
        source.name = checked.name || source.name;
        source.warnings = checked.report.warnings || [];
    } catch (error) {
        try { deleteFile(target); } catch (ignoreDeleteImportedPyError) {}
        throw new Error("PY 加载失败: " + errorText(error));
    }
    return upsertImportedSource(source, !!metadata.makeCurrent);
}

function importJsCode(code, name, metadata) {
    metadata = metadata || {};
    code = String(code || "");
    if (code && code.charCodeAt(0) === 0xfeff) code = code.slice(1);
    if (!/(?:var|let|const)\s+rule\s*=|export\s+default\s*\{|\btitle\s*:\s*["']/i.test(code)) {
        throw new Error("JS 中没有找到 Drpy rule 定义");
    }
    code = code.replace(/export\s+default\s*(\{[\s\S]*\})\s*;?\s*$/, "var rule = $1;");
    var digest = md5(code);
    var id = "js_" + digest.slice(0, 16);
    var fileName = String(name || "source.js").replace(/\.js$/i, "") + ".js";
    var target = SOURCE_ROOT + "/" + id + ".js";
    writeFile(target, code);
    var source = {
        id: id,
        name: fileName.replace(/\.js$/i, ""),
        fileName: fileName,
        path: target,
        runtime: "drpy",
        api: metadata.api || "drpy2.js",
        ext: metadata.ext || "",
        lineId: metadata.lineId || "",
        remoteUrl: metadata.remoteUrl || "",
        builtIn: false,
        importedAt: Date.now(),
        md5: digest,
        managedLocal: true
    };
    try {
        var checked = checkSource(source);
        source.name = checked.name || source.name;
    } catch (error) {
        try { deleteFile(target); } catch (ignoreDeleteImportedJsError) {}
        throw new Error("JS 加载失败: " + errorText(error));
    }
    return upsertImportedSource(source, !!metadata.makeCurrent);
}

function defaultConfigIndex() {
    return {version: 1, current: "", lines: []};
}

function getConfigIndex() {
    var index = readJson(CONFIG_INDEX_PATH, defaultConfigIndex());
    if (!index || typeof index !== "object") index = defaultConfigIndex();
    if (!Array.isArray(index.lines)) index.lines = [];
    return index;
}

function saveConfigIndex(index) {
    index = index || defaultConfigIndex();
    index.version = 1;
    if (!Array.isArray(index.lines)) index.lines = [];
    writeJson(CONFIG_INDEX_PATH, index);
    return index;
}

function configEntries(json) {
    var candidates = json && (json.urls || json.data || json.list || json.items) || [];
    return Array.isArray(candidates) ? candidates.filter(function(item) { return item && item.url; }) : [];
}

function saveConfigLine(name, url, parentId) {
    var location = String(url || "").trim();
    if (!location) return null;
    var index = getConfigIndex();
    var id = "cfg_" + md5(location).slice(0, 16);
    var line = {
        id: id,
        name: String(name || displayFileName(location, "配置线路")).replace(/\.(?:json|js)$/i, ""),
        url: location,
        parentId: parentId || "",
        updatedAt: Date.now()
    };
    var oldIndex = index.lines.findIndex(function(item) { return item.id === id; });
    if (oldIndex >= 0) index.lines[oldIndex] = Object.assign({}, index.lines[oldIndex], line);
    else index.lines.push(line);
    if (!index.current) index.current = id;
    saveConfigIndex(index);
    return line;
}

function readImportLocation(location) {
    var path = String(location || "").trim();
    if (!path) throw new Error("导入地址为空");
    if (!/^(?:https?:\/\/|hiker:\/\/|file:\/\/)/i.test(path)) path = normalizeInputPath(path);
    var candidates = [path, path];
    if (/^https:\/\/raw\.githubusercontent\.com\//i.test(path)) {
        candidates.push("https://gh-proxy.com/" + path);
        candidates.push("https://ghfast.top/" + path);
        candidates.push("https://ghproxy.net/" + path);
        var rawMatch = path.match(/^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/(?:refs\/heads\/)?([^/]+)\/(.+)$/i);
        if (rawMatch) candidates.push("https://cdn.jsdelivr.net/gh/" + rawMatch[1] + "/" + rawMatch[2] + "@" + rawMatch[3] + "/" + rawMatch[4]);
    }
    var text = "";
    for (var i = 0; i < candidates.length; i++) {
        try {
            var requestPath = candidates[i];
            if (/^https?:\/\//i.test(requestPath)) {
                var cacheKey = "py_cfg_" + Date.now() + "_" + i;
                requestPath += (requestPath.indexOf("?") >= 0 ? "&" : "?") + "__hiker_no_cache=" + cacheKey;
            }
            text = request(requestPath, {
                timeout: 15000,
                headers: {
                    "User-Agent": "Mozilla/5.0 (Android) AppleWebKit/537.36",
                    "Accept": "application/json,text/plain,*/*",
                    "Cache-Control": "no-cache"
                }
            });
            if (text && String(text).trim()) break;
        } catch (ignoreConfigRequestError) {
            text = "";
        }
    }
    if (!text || !String(text).trim()) throw new Error("没有读取到配置内容");
    return {path: path, text: String(text)};
}

function addStructuredSource(site, lineId, report, position) {
    site = site || {};
    var name = String(site.name || site.title || site.key || "视频源");
    var api = String(site.api || "");
    var ext = site.ext === undefined ? "" : site.ext;
    var type = Number(site.type);
    var siteIndex = Number(position);
    if (!isFinite(siteIndex)) siteIndex = 0;
    var siteIdentity = [lineId || "", siteIndex, site.key || "", name, api, type, JSON.stringify(ext)].join("@");
    var source;
    try {
        if (/\.py(?:$|[?#])/i.test(api) || (typeof ext === "string" && /\.py(?:$|[?#])/i.test(ext))) {
            var pyLocation = /\.py(?:$|[?#])/i.test(api) ? api : String(ext);
            var pyData = readImportLocation(pyLocation);
            source = importPyCode(pyData.text, name + ".py", {remoteUrl: pyLocation, api: api, ext: api === pyLocation ? ext : "", lineId: lineId});
        } else if (type === 4) {
            var t4Id = "t4_" + md5("t4@" + siteIdentity).slice(0, 16);
            source = upsertImportedSource({id: t4Id, name: name, fileName: name, path: api, runtime: "t4", api: api, ext: ext, lineId: lineId, importedAt: Date.now(), managedLocal: false}, false);
        } else if (type === 0 || type === 1 || type === 2) {
            var cmsId = "cms_" + md5("cms@" + siteIdentity).slice(0, 16);
            source = upsertImportedSource({id: cmsId, name: name, fileName: name, path: api, runtime: "cms", api: api, ext: ext, cmsType: type, lineId: lineId, importedAt: Date.now(), managedLocal: false}, false);
        } else if (/drpy/i.test(api) || (typeof ext === "string" && /\.js(?:$|[?#])/i.test(ext))) {
            var jsLocation = typeof ext === "string" && ext ? ext : api;
            var jsData = readImportLocation(jsLocation);
            source = importJsCode(jsData.text, name + ".js", {remoteUrl: jsLocation, api: api || "drpy2.js", ext: site.ext && typeof site.ext !== "string" ? site.ext : "", lineId: lineId});
        } else {
            // CatVod type=3 的 csp_* 依赖 custom_spider.jar；当前壳没有 jar 运行器，明确跳过。
            report.skipped++;
            return null;
        }
        report.imported++;
        report.names.push(source.name);
    } catch (error) {
        report.failed++;
        report.failures.push(name + "：" + errorText(error));
    }
}

function importConfigLives(lives, lineName) {
    if (!Array.isArray(lives) || !lives.length) return 0;
    var existing = readJson(LIVE_INDEX_PATH, []);
    if (!Array.isArray(existing)) existing = [];
    var added = 0;
    lives.forEach(function(group, groupIndex) {
        group = group || {};
        var name = String(group.name || group.group || lineName || ("直播线路 " + (groupIndex + 1)));
        var remoteUrl = String(group.url || group.ext || "");
        var channels = [];
        (Array.isArray(group.channels) ? group.channels : []).forEach(function(channel) {
            channel = channel || {};
            var urls = Array.isArray(channel.urls) ? channel.urls : [channel.url || ""];
            urls.filter(Boolean).forEach(function(url, urlIndex) {
                channels.push({
                    group: String(group.group || name),
                    name: String(channel.name || ("频道 " + (channels.length + 1))) + (urlIndex ? " " + (urlIndex + 1) : ""),
                    url: String(url)
                });
            });
        });
        if (!remoteUrl && !channels.length) return;
        var id = "live_" + md5(remoteUrl || JSON.stringify(channels)).slice(0, 16);
        var item = {id: id, name: name, url: remoteUrl, channels: channels, updatedAt: Date.now(), fromConfig: true};
        var old = existing.findIndex(function(value) { return String(value.id) === id; });
        if (old >= 0) existing[old] = Object.assign({}, existing[old], item);
        else { existing.push(item); added++; }
    });
    writeJson(LIVE_INDEX_PATH, existing);
    return added;
}

function importLocation(location, preferredName, options) {
    options = options || {};
    var loaded = readImportLocation(location);
    var text = loaded.text.trim();
    var fileName = displayFileName(loaded.path, preferredName || "视频源");
    var report = {location: loaded.path, imported: 0, skipped: 0, failed: 0, lines: 0, live: 0, names: [], failures: []};
    if (/class\s+Spider\s*[(:]/.test(text) || /\.py(?:$|[?#])/i.test(loaded.path)) {
        var py = importPyCode(text, preferredName || fileName, {remoteUrl: loaded.path, makeCurrent: options.makeCurrent});
        report.imported = 1;
        report.names.push(py.name);
        return report;
    }
    var json = null;
    try { json = JSON.parse(text); } catch (ignoreConfigJsonError) {}
    if (!json) {
        var js = importJsCode(text, preferredName || fileName, {remoteUrl: loaded.path, makeCurrent: options.makeCurrent});
        report.imported = 1;
        report.names.push(js.name);
        return report;
    }
    var repositories = configEntries(json);
    if (repositories.length && !Array.isArray(json.sites)) {
        var parentId = "repo_" + md5(loaded.path).slice(0, 16);
        repositories.forEach(function(item) {
            if (saveConfigLine(item.name || item.title, item.url, parentId)) report.lines++;
        });
        return report;
    }
    var line = saveConfigLine(preferredName || json.name || fileName, loaded.path, options.parentId || "");
    var sites = Array.isArray(json.sites) ? json.sites : (Array.isArray(json.sources) ? json.sources : []);
    if (line) {
        // 同一线路重导入只替换该线路自己的源库，不触碰 py_sources.json。
        var lineStore = getLineSourceIndex();
        var oldLineSources = lineStore.sources.filter(function(source) { return String(source.lineId || "") === String(line.id); });
        lineStore.sources = lineStore.sources.filter(function(source) { return String(source.lineId || "") !== String(line.id); });
        if (String(lineStore.current || "") && oldLineSources.some(function(source) { return String(source.id) === String(lineStore.current); })) {
            lineStore.current = "";
        }
        saveLineSourceIndex(lineStore);
        oldLineSources.forEach(function(source) { resetSourceRuntime(source.id); });
    }
    sites.forEach(function(site, siteIndex) { addStructuredSource(site, line ? line.id : "", report, siteIndex); });
    report.live = importConfigLives(json.lives || [], line ? line.name : (preferredName || fileName));
    if (line) {
        var lineStoreAfter = getLineSourceIndex();
        var firstLineSource = lineStoreAfter.sources.find(function(source) { return String(source.lineId || "") === String(line.id) && isSourceEnabled(source); });
        lineStoreAfter.current = firstLineSource ? firstLineSource.id : "";
        saveLineSourceIndex(lineStoreAfter);
        if (firstLineSource) setActiveSourceId(firstLineSource.id);
        var configIndex = getConfigIndex();
        configIndex.current = line.id;
        saveConfigIndex(configIndex);
    }
    report.lines = line ? 1 : 0;
    return report;
}

function activateConfigLine(lineId) {
    var index = getConfigIndex();
    var line = index.lines.find(function(item) { return String(item.id) === String(lineId); });
    if (!line) throw new Error("配置线路不存在");
    var report = importLocation(line.url, line.name, {parentId: line.parentId || ""});
    index = getConfigIndex();
    index.current = line.id;
    saveConfigIndex(index);
    return report;
}

// 配置线路手动排序：置顶/上移/下移/置底（与 moveSource/moveLiveSource 语义一致）。
function moveConfigLine(lineId, direction) {
    var id = String(lineId || "");
    var mode = String(direction || "");
    if (["top", "up", "down", "bottom"].indexOf(mode) < 0) throw new Error("不支持的移动方式");
    var index = getConfigIndex();
    var position = index.lines.findIndex(function(item) { return String(item.id) === id; });
    if (position < 0) throw new Error("配置线路不存在");
    var target = position;
    if (mode === "top") target = 0;
    else if (mode === "up") target = Math.max(0, position - 1);
    else if (mode === "down") target = Math.min(index.lines.length - 1, position + 1);
    else if (mode === "bottom") target = index.lines.length - 1;
    if (target !== position) {
        var line = index.lines.splice(position, 1)[0];
        index.lines.splice(target, 0, line);
        saveConfigIndex(index);
    }
    return clone(index.lines);
}

function removeConfigLine(lineId) {
    var index = getConfigIndex();
    var before = (index.lines || []).length;
    index.lines = (index.lines || []).filter(function(item) { return String(item.id) !== String(lineId); });
    var removed = before - index.lines.length;
    if (!removed) throw new Error("配置线路不存在");
    if (String(index.current) === String(lineId)) index.current = index.lines.length ? index.lines[0].id : "";
    var lineStore = getLineSourceIndex();
    var removedSources = lineStore.sources.filter(function(source) { return String(source.lineId || "") === String(lineId); });
    lineStore.sources = lineStore.sources.filter(function(source) { return String(source.lineId || "") !== String(lineId); });
    if (removedSources.some(function(source) { return String(source.id) === String(lineStore.current); })) {
        var nextLineId = String(index.current || "");
        var nextLineSource = lineStore.sources.find(function(source) { return String(source.lineId || "") === nextLineId; }) || lineStore.sources[0];
        lineStore.current = nextLineSource ? String(nextLineSource.id) : "";
    }
    saveConfigIndex(index);
    saveLineSourceIndex(lineStore);
    removedSources.forEach(function(source) { resetSourceRuntime(source.id); });
    var activeId = getActiveSourceId();
    if (removedSources.some(function(source) { return String(source.id) === String(activeId); })) {
        var fallback = getIndex().sources.find(isSourceEnabled);
        setActiveSourceId(fallback ? fallback.id : "");
    }
    return removed;
}

function getSourceStatusCache() {
    var value = readJson(SOURCE_STATUS_PATH, {version: 1, sources: {}});
    if (!value || typeof value !== "object") value = {version: 1, sources: {}};
    if (!value.sources || typeof value.sources !== "object" || Array.isArray(value.sources)) value.sources = {};
    return value;
}

function saveSourceStatus(sourceId, status) {
    var cache = getSourceStatusCache();
    cache.sources[String(sourceId)] = Object.assign({}, status || {}, {savedAt: Date.now()});
    writeJson(SOURCE_STATUS_PATH, cache);
    return cache.sources[String(sourceId)];
}

function setSourceExtend(sourceId, extend) {
    var record = findSourceRecord(sourceId);
    if (!record) throw new Error("视频源不存在");
    record.source.ext = String(extend || "");
    saveSourceRecord(record);
    resetSourceRuntime(sourceId);
    return record.source;
}

function removeSource(sourceId) {
    var record = findSourceRecord(sourceId);
    if (!record) return false;
    record.index.sources.splice(record.position, 1);
    if (record.index.current === sourceId) {
        var fallback = record.index.sources.find(isSourceEnabled);
        record.index.current = fallback ? fallback.id : "";
    }
    saveSourceRecord(record);
    if (getActiveSourceId() === String(sourceId)) {
        var activeFallback = getAllSourceRecords().find(isSourceEnabled);
        setActiveSourceId(activeFallback ? activeFallback.id : "");
    }
    if (record.source.managedLocal !== false && /^(?:hiker:\/\/|file:\/\/)/i.test(String(record.source.path || ""))) {
        try { deleteFile(record.source.path); } catch (ignoreDeleteError) {}
    }
    resetSourceRuntime(sourceId);
    return true;
}

function clearRuntimeCache() {
    try { clearCategoryPrefetch(""); } catch (ignoreAllCategoryPrefetchClearError) {}
    categoryResultMemoryCache.clear();
    homeClassCache.forEach(function(_, sourceId) {
        try { putMyVar(homeClassStateKey(sourceId), ""); } catch (ignoreHomeClassStateClearError) {}
    });
    homeFiltersCache.forEach(function(_, sourceId) {
        try { putMyVar(homeFiltersStateKey(sourceId), ""); } catch (ignoreHomeFiltersStateClearError) {}
    });
    clearAllHomeFiltersFiles();
    instanceCache.clear();
    dependencyCache.clear();
    detailCache.clear();
    imageHeaderCache.clear();
    imageDecoderConfigCache.clear();
    genericListCache.clear();
    homeClassCache.clear();
    homeFiltersCache.clear();
    warmHomeResultCache.clear();
    vodListRawCache.clear();
    vodRawCacheLoaded = true;
    if (runtimeMatchesBuild(runtimeModule)) {
        try { runtimeModule.clearRuntimeObjects(""); } catch (ignoreRuntimeObjectsClearError) {}
        try { runtimeModule.clearPyModules(); } catch (ignorePythonModulesClearError) {}
    }
    try { writeJson(VOD_RAW_CACHE_KEY, []); } catch (ignoreVodRawCacheClearError) {}
    try { deleteFile(CATEGORY_PREFETCH_PATH); } catch (ignorePrefetchClearError) {}
    try { getExternalRuntime().clear(); } catch (ignoreExternalClearError) {}
}

// 海阔的 select / lazyRule / confirm / input / fileSelect 回调会脱离当前页面执行。
// 部分设备首次导入时，回调里的 $.require() 会返回当前页或缓存中的不完整对象。
// 返回可随回调参数序列化的自包含加载器；缺方法时隔离 $.exports 并执行本地核心文件。
function callbackCoreLoaderSource() {
    return "(function(requiredMethods){" +
        "var buildVersion=" + JSON.stringify(BUILD_VERSION) + ";" +
        "var pagePath=" + JSON.stringify(CORE_PAGE_PATH) + ";" +
        "var corePath='hiker://files/data/PY影视壳/subpage/py_core.js';" +
        "var methods=Array.isArray(requiredMethods)?requiredMethods:[];" +
        "function ready(candidate){if(!candidate)return false;for(var i=0;i<methods.length;i++){if(typeof candidate[methods[i]]!=='function')return false;}return true;}" +
        "function sharedCore(){var slots=[];try{if(typeof globalThis!=='undefined'&&globalThis)slots.push(globalThis);}catch(ignoreGlobalThisError){}try{if(typeof window!=='undefined'&&window)slots.push(window);}catch(ignoreWindowError){}try{if(typeof top!=='undefined'&&top)slots.push(top);}catch(ignoreTopError){}for(var s=0;s<slots.length;s++){try{var entry=slots[s].__pyCoreModule;if(entry&&String(entry.version||'')===buildVersion&&ready(entry.module))return entry.module;}catch(ignoreSlotError){}}return null;}" +
        "var core=sharedCore();" +
        "if(!ready(core)){try{core=$.require(pagePath);}catch(ignorePageRequireError){}}" +
        "if(!ready(core)){try{core=$.require(corePath);}catch(ignoreFileRequireError){}}" +
        "if(!ready(core)){try{core=$.require(corePath,true);}catch(ignoreFileReloadError){}}" +
        "if(!ready(core)){" +
            "var previousExports=$.exports;" +
            "try{" +
                "$.exports={};" +
                "var code='';" +
                "try{if(typeof readFile==='function')code=String(readFile(corePath)||'');}catch(ignoreReadError){}" +
                "if(!code)code=String(request(corePath)||'');" +
                "if(!code)throw new Error('PY 核心模块为空');" +
                "eval(code);" +
                "core=$.exports;" +
            "}finally{$.exports=previousExports;}" +
        "}" +
        "if(!ready(core)){var missing=[];for(var j=0;j<methods.length;j++){if(!core||typeof core[methods[j]]!=='function')missing.push(methods[j]);}throw new Error('PY 核心模块缺少方法 '+missing.join('、'));}" +
        "return core;" +
    "})";
}

function getLiveIndexPath() {
    return LIVE_INDEX_PATH;
}

function getLiveSources() {
    var sources = readJson(LIVE_INDEX_PATH, []);
    return clone(Array.isArray(sources) ? sources : []);
}

function saveLiveSources(sources) {
    var normalized = Array.isArray(sources) ? sources.filter(function(source) {
        return source && source.id;
    }) : [];
    writeJson(LIVE_INDEX_PATH, normalized);
    return clone(normalized);
}

function renameLiveSource(sourceId, displayName) {
    var id = String(sourceId || "");
    var name = String(displayName || "").replace(/\s+/g, " ").trim();
    if (!name) throw new Error("名称不能为空");
    if (name.length > 80) throw new Error("名称不能超过 80 个字符");
    var sources = getLiveSources();
    var source = sources.find(function(item) { return String(item.id) === id; });
    if (!source) throw new Error("直播源不存在");
    source.name = name;
    saveLiveSources(sources);
    return clone(source);
}

function sortLiveSources(mode) {
    mode = String(mode || "");
    if (mode !== "updated_desc" && mode !== "name") throw new Error("不支持的排序方式");
    var sources = getLiveSources().map(function(source, position) {
        return {source: source, position: position};
    });
    sources.sort(function(left, right) {
        if (mode === "updated_desc") {
            var leftTime = Number(left.source.updatedAt || 0);
            var rightTime = Number(right.source.updatedAt || 0);
            if (leftTime !== rightTime) return rightTime - leftTime;
        } else {
            var nameOrder = sourceNameCompare(left.source.name, right.source.name);
            if (nameOrder !== 0) return nameOrder;
        }
        return left.position - right.position;
    });
    return saveLiveSources(sources.map(function(item) { return item.source; }));
}

function moveLiveSource(sourceId, direction) {
    var id = String(sourceId || "");
    var mode = String(direction || "");
    if (["top", "up", "down", "bottom"].indexOf(mode) < 0) throw new Error("不支持的移动方式");
    var sources = getLiveSources();
    var position = sources.findIndex(function(source) { return String(source.id) === id; });
    if (position < 0) throw new Error("直播源不存在");
    var target = position;
    if (mode === "top") target = 0;
    else if (mode === "up") target = Math.max(0, position - 1);
    else if (mode === "down") target = Math.min(sources.length - 1, position + 1);
    else if (mode === "bottom") target = sources.length - 1;
    if (target !== position) {
        var source = sources.splice(position, 1)[0];
        sources.splice(target, 0, source);
        saveLiveSources(sources);
    }
    return clone(sources);
}

function updateLiveSource(sourceId, patch) {
    // 直播源编辑：支持改名/改 URL/改 UA。改 URL 后需要重新解析频道，
    // 解析由调用方（live_manager.js）负责，这里只持久化字段并清掉旧频道缓存。
    // URL 字段接受 "名称||URL||UA" 完整格式（与添加直播源一致），自动拆段。
    var id = String(sourceId || "");
    var patchObject = patch && typeof patch === "object" ? patch : {};
    if (!id) throw new Error("直播源不存在");
    var sources = getLiveSources();
    var source = sources.find(function(item) { return String(item.id) === id; });
    if (!source) throw new Error("直播源不存在");
    var changed = false;
    if (patchObject.name !== undefined) {
        var name = String(patchObject.name || "").replace(/\s+/g, " ").trim();
        if (!name) throw new Error("名称不能为空");
        if (name.length > 80) throw new Error("名称不能超过 80 个字符");
        source.name = name;
        changed = true;
    }
    if (patchObject.url !== undefined) {
        var rawUrl = String(patchObject.url || "").trim();
        if (!rawUrl) throw new Error("URL 不能为空");
        var urlValue = rawUrl;
        if (rawUrl.indexOf("||") >= 0) {
            // 完整格式：名称||URL||UA
            var segments = rawUrl.split("||").map(function(part) { return String(part || "").trim(); });
            if (segments[0]) {
                source.name = segments[0].replace(/\s+/g, " ").trim();
                changed = true;
            }
            urlValue = segments[1] || "";
            if (segments[2] !== undefined) {
                source.ua = segments[2];
                changed = true;
            }
        }
        if (!urlValue) throw new Error("URL 不能为空");
        if (!/^[a-zA-Z][\w+.-]*:\/\//i.test(urlValue)) throw new Error("URL 格式不正确");
        source.url = urlValue;
        source.channels = [];
        source.pageInfo = null;
        source.parserVersion = 0;
        source.updatedAt = Date.now();
        changed = true;
    }
    if (patchObject.ua !== undefined) {
        source.ua = String(patchObject.ua || "");
        changed = true;
    }
    if (changed) {
        source.updatedAt = Date.now();
        saveLiveSources(sources);
    }
    return clone(source);
}

function removeLiveSources(sourceIds) {
    var removeMap = {};
    (Array.isArray(sourceIds) ? sourceIds : [sourceIds]).forEach(function(id) {
        id = String(id || "");
        if (id) removeMap[id] = true;
    });
    var sources = getLiveSources();
    var remaining = sources.filter(function(source) { return !removeMap[String(source.id)]; });
    var removed = sources.length - remaining.length;
    if (removed) saveLiveSources(remaining);
    return {removed: removed, sources: clone(remaining)};
}

function importUrl() {
    return "fileSelect://(function(){try{" +
        "var selected=(typeof input!=='undefined'&&input)?input:((typeof MY_PATH!=='undefined')?MY_PATH:'');" +
        "var loadCore=" + callbackCoreLoaderSource() + ";" +
        "var core=loadCore(['importSource']);" +
        "var source=core.importSource(selected);" +
        "refreshPage(false);" +
        "return 'toast://已导入：'+source.name;" +
        "}catch(error){return 'toast://'+(error&&error.toString?error.toString():String(error));}})()";
}

function normalizeHeaders(value, count) {
    var headers = value || {};
    if (typeof headers === "string") {
        try { headers = JSON.parse(headers); } catch (ignoreHeaderError) { headers = {}; }
    }
    if (Array.isArray(headers)) return headers;
    var result = [];
    for (var i = 0; i < count; i++) result.push(headers);
    return result;
}

function normalizeProxyUrl(url, sourceId) {
    var value = String(url || "");
    if (startsWith(value, "proxy://")) {
        var suffix = value.slice(8).replace(/^\?/, "");
        var rebuilt = recursiveSourceProxyUrl(sourceId) + (suffix ? "&" + suffix : "");
        return rebuilt.replace(/^https?:\/\/10\.0\.2\.15/i, "http://127.0.0.1");
    }
    // 识别 PY 源生成的海阔内置本地代理 URL（127.0.0.1/localhost/10.0.2.15:52020/proxy 或带
    // do/hikerSkey/url/u 参数的代理地址）。这类 URL 直接交给播放器/Glide 会请求海阔内置
    // 代理（52020），在自定义壳下常超时导致灰图或播放失败；统一重建为壳子代理 URL，
    // 保证请求路由到 startProxyServer 回调并调用 PY 源自己的 localProxy()。
    if (localProxyUrlMatches(value)) {
        var rebuilt = rebuildLocalProxyUrl(value, sourceId);
        if (rebuilt) return rebuilt;
    }
    return value;
}

function rebuildLocalProxyUrl(value, sourceId) {
    var text = String(value || "");
    var queryIndex = text.indexOf("?");
    if (queryIndex < 0) return "";
    var params = {};
    text.slice(queryIndex + 1).split("&").forEach(function(part) {
        if (!part) return;
        var split = part.indexOf("=");
        var rawKey = split >= 0 ? part.slice(0, split) : part;
        var rawValue = split >= 0 ? part.slice(split + 1) : "";
        var key;
        var item;
        try { key = decodeURIComponent(rawKey); } catch (ignoreRebuildKeyError) { key = rawKey; }
        try { item = decodeURIComponent(rawValue); } catch (ignoreRebuildValueError) { item = rawValue; }
        if (params[key] === undefined) params[key] = item;
    });
    var hasProxyTarget = !!(params.url || params.u || params.uri);
    var proxyType = String(params.type || params.do || "").toLowerCase();
    var proxyLike = proxyType === "img" || proxyType === "image" || proxyType === "m3u8" ||
        proxyType === "ts" || proxyType === "media" || proxyType === "cache" ||
        /\/proxy\b/i.test(text) || /hikerSkey=/.test(text) || hasProxyTarget;
    if (!proxyLike) return "";
    if (params.__direct_img) {
        // 已经是壳子代理直连 URL：只做 host 归一化
        return text.replace(/^https?:\/\/10\.0\.2\.15/i, "http://127.0.0.1");
    }
    var extra = [];
    Object.keys(params).forEach(function(key) {
        if (key === "source" || key === "__hiker_proxy" || key === "pyproxy") return;
        extra.push(key + "=" + encodeURIComponent(String(params[key])));
    });
    var root = sourceProxyRoot(sourceId);
    var rebuilt = recursiveSourceProxyUrl(sourceId, root) +
        (extra.length ? "&" + extra.join("&") : "");
    return rebuilt.replace(/^https?:\/\/10\.0\.2\.15/i, "http://127.0.0.1");
}

// AVTOP10 一类源会把 Surrit 的固定 360p/480p/720p 子清单交给 pl3 中转。
// 长影片的固定子清单可达数十万到上百万字节，播放器要先下载并解析完整
// 清单，连续切换视频时更容易长时间停在 0 kB/s。对应 master playlist 很小，
// 且能让 ExoPlayer 按当前网络自适应选档；这里只改写明确的 pl3+surrit 组合，
// 仍保留原固定清晰度作为第二线路，不绕过源本身要求的中转。
function surritAdaptiveUrl(value) {
    var text = String(value || "");
    if (!/^https?:\/\/pl3\.v{8}\.top\/api\/play(?:[?#]|$)/i.test(text)) return "";
    var targetMatch = /([?&](?:url|u|uri)=)([^&#]+)/i.exec(text);
    if (!targetMatch) return "";
    var rawTarget = String(targetMatch[2] || "");
    var decodedTarget = rawTarget;
    for (var attempt = 0; attempt < 2; attempt++) {
        try {
            var decoded = decodeURIComponent(decodedTarget);
            if (decoded === decodedTarget) break;
            decodedTarget = decoded;
        } catch (ignoreSurritDecodeError) {
            break;
        }
    }
    var masterTarget = decodedTarget.replace(
        /(https?:\/\/surrit\.com\/[0-9a-f-]{20,})\/(?:360p|480p|720p)\/video\.m3u8/i,
        "$1/playlist.m3u8"
    );
    if (masterTarget === decodedTarget) return "";
    var replacement = /%[0-9a-f]{2}/i.test(rawTarget) ? encodeURIComponent(masterTarget) : masterTarget;
    var targetOffset = Number(targetMatch.index || 0) + String(targetMatch[1] || "").length;
    return text.slice(0, targetOffset) + replacement + text.slice(targetOffset + rawTarget.length);
}

function stabilizePlaybackLines(urls, names, headers, label, flag) {
    var inputUrls = Array.isArray(urls) ? urls : [urls];
    var inputNames = Array.isArray(names) ? names : [];
    var inputHeaders = normalizeHeaders(headers, inputUrls.length);
    var output = {urls: [], names: [], headers: []};
    var seen = {};

    function add(url, name, header) {
        var key = String(url || "");
        if (!key || seen[key]) return;
        seen[key] = true;
        output.urls.push(key);
        output.names.push(String(name || "播放"));
        output.headers.push(header && typeof header === "object" ? header : {});
    }

    inputUrls.forEach(function(url, index) {
        var currentUrl = String(url || "");
        var currentName = String(inputNames[index] || (index === 0 ? (label || flag || "播放") : "线路 " + (index + 1)));
        var currentHeader = inputHeaders[index] || inputHeaders[0] || {};
        var masterUrl = surritAdaptiveUrl(currentUrl);
        if (masterUrl && masterUrl !== currentUrl) {
            add(masterUrl, "自适应（推荐）", currentHeader);
            add(currentUrl, /^原始\s/.test(currentName) ? currentName : "原始 " + currentName, currentHeader);
        } else {
            add(currentUrl, currentName, currentHeader);
        }
    });
    return output;
}

// 韩国 KBJ 的 hls4 清单目前会返回广告/图片分片。对该源只调整默认顺序，
// 保留 hls4 等线路供用户手动切换，避免修改其他源的线路策略。
function prioritizeKbjPlaybackLines(sourceId, lines) {
    var sourceName = "";
    try {
        var source = getSource(sourceId);
        sourceName = source ? String(source.name || source.title || "") : "";
    } catch (ignoreKbjSourceError) {}
    var allText = sourceName + " " + (lines && lines.names ? lines.names.join(" ") : "") +
        " " + (lines && lines.urls ? lines.urls.join(" ") : "");
    if (!/(?:韩国\s*KBJ|sexkbj\.top|sexkbj\.com)/i.test(allText) || !lines || lines.urls.length < 2) {
        return lines;
    }
    var order = [];
    for (var i = 0; i < lines.urls.length; i++) {
        var text = String(lines.names[i] || "") + " " + String(lines.urls[i] || "");
        order.push({index: i, preferred: /(?:^|[^a-z0-9])hls2(?:[^a-z0-9]|$)/i.test(text) ? 0 : 1});
    }
    order.sort(function(a, b) { return a.preferred - b.preferred || a.index - b.index; });
    var result = {urls: [], names: [], headers: []};
    order.forEach(function(item) {
        result.urls.push(lines.urls[item.index]);
        result.names.push(lines.names[item.index]);
        result.headers.push(lines.headers[item.index] || {});
    });
    return result;
}

// KBJ 的 HLS2 只需要固定媒体 headers，源 localProxy 没有额外解密逻辑。
// 直接还原远程清单可让 ExoPlayer 沿用手机代理访问 CDN，同时避开系统
// HTTP 代理或 VPN/TUN 接管 127.0.0.1:52020 后返回 502 的设备差异。
function unwrapKbjHls2Proxy(sourceId, flag, lines) {
    if (!lines || !Array.isArray(lines.urls)) return lines;
    var sourceName = "";
    try {
        var source = getSource(sourceId);
        sourceName = source ? String(source.name || source.title || "") : "";
    } catch (ignoreKbjDirectSourceError) {}
    var result = {urls: [], names: [], headers: []};
    var changed = false;
    for (var i = 0; i < lines.urls.length; i++) {
        var currentUrl = String(lines.urls[i] || "");
        var params = proxyUrlParameters(currentUrl);
        var target = decodeProxyImageUrl(params.url || params.u || params.uri || "");
        var ref = decodeProxyImageUrl(params.ref || params.referer || "");
        var marker = sourceName + " " + String(flag || "") + " " + String(lines.names[i] || "") +
            " " + currentUrl + " " + target + " " + ref;
        var isKbj = /(?:韩国\s*KBJ|sexkbj\.top|sexkbj\.com)/i.test(marker);
        var isHls2 = /(?:^|[^a-z0-9])hls2(?:[^a-z0-9]|$)/i.test(marker);
        if (isKbj && isHls2 && localProxyUrlMatches(currentUrl) && /^https?:\/\//i.test(target)) {
            var directHeaders = {};
            Object.keys((lines.headers && lines.headers[i]) || {}).forEach(function(key) {
                directHeaders[key] = lines.headers[i][key];
            });
            if (ref) directHeaders.Referer = ref;
            directHeaders.Origin = "https://sexkbj.top";
            directHeaders.Accept = "*/*";
            result.urls.push(target);
            result.names.push(String(lines.names[i] || "HLS2"));
            result.headers.push(directHeaders);
            changed = true;
        } else {
            result.urls.push(currentUrl);
            result.names.push(String(lines.names[i] || "播放"));
            result.headers.push((lines.headers && lines.headers[i]) || {});
        }
    }
    result._skipMasterProbe = changed;
    return result;
}

function masterVariants(masterUrl, master) {
    // 解析 master m3u8 的 #EXT-X-STREAM-INF 变体；name 格式对齐 Supjav：
    // "RESOLUTION BANDWIDTH=xxx"（如 "1920x1080 BANDWIDTH=2905792"）
    master = String(master || "");
    var lines = master.split(/\r?\n/);
    var out = [];
    var curName = "";
    for (var i = 0; i < lines.length; i++) {
        var line = String(lines[i] || "").trim();
        if (!line) continue;
        if (/^#EXT-X-STREAM-INF/i.test(line)) {
            var r = line.match(/RESOLUTION=([^,\s]+)/i);
            var b = line.match(/BANDWIDTH=(\d+)/i);
            curName = (r ? r[1] : "") + (b ? " BANDWIDTH=" + b[1] : "");
            continue;
        }
        if (line.charAt(0) == "#") continue;
        out.push({ name: curName, url: absolutePlayUrl(line, masterUrl) });
        curName = "";
    }
    return out;
}

function absolutePlayUrl(line, baseUrl) {
    line = String(line || "").trim();
    if (/^https?:\/\//i.test(line)) return line;
    if (/^\/\//i.test(line)) return "https:" + line;
    if (/^\//i.test(line)) {
        var origin = /^https?:\/\/[^/]+/i.exec(baseUrl);
        return (origin ? origin[0] : "") + line;
    }
    var base = String(baseUrl || "").replace(/[?#].*$/, "");
    base = base.slice(0, base.lastIndexOf("/") + 1);
    return base + line.replace(/^\.\//, "");
}

function resolveMasterPlaylistVariants(sourceId, url, headers) {
    // 单条线路时，若 m3u8 是 master（含 #EXT-X-STREAM-INF 变体），解析各清晰度
    // 作为独立线路返回；解析失败或非 master 时返回 null，调用方保持原线路。
    var value = String(url || "");
    var inspectedValue = value;
    for (var decodeAttempt = 0; decodeAttempt < 2; decodeAttempt++) {
        try {
            var decodedValue = decodeURIComponent(inspectedValue);
            if (decodedValue === inspectedValue) break;
            inspectedValue = decodedValue;
        } catch (ignoreMasterUrlDecodeError) {
            break;
        }
    }
    if (!/\.m3u8(?:$|[?#&@;])/i.test(inspectedValue)) return null;
    // 本地代理 master 的同步探测会在点击播放时递归进入 Python 代理，并可能阻塞 8 秒。
    // 让播放器按正常 HLS 流程请求它；远端直链仍保留多分辨率拆分。
    if (localProxyUrlMatches(value)) return null;
    try {
        var text = String(request(value, {
            timeout: 8000,
            headers: headers || {}
        }) || "");
        if (!text || text.indexOf("#EXT-X-STREAM-INF") < 0) return null;
        var variants = masterVariants(value, text);
        if (!variants.length) return null;
        // 去重并按分辨率名保持顺序；只有 ≥2 个清晰度变体才拆分为多线路，
        // 单条线路（含单变体 master）保持原样，播放页不弹窗。
        var seen = {};
        var unique = [];
        variants.forEach(function(variant) {
            var key = variant.name + "@" + variant.url;
            if (seen[key]) return;
            seen[key] = true;
            unique.push(variant);
        });
        return unique.length > 1 ? unique : null;
    } catch (ignoreVariantError) {
        return null;
    }
}

function playbackQualityKey(name) {
    var text = String(name || "").replace(/\s+/g, " ").trim();
    var numeric = /(?:^|[^0-9])(2160|1920|1440|1280|1080|842|720|640|576|540|480|360|240)\s*[pP](?:$|[^0-9])/i.exec(text);
    if (numeric) return numeric[1] + "P";
    if (/(?:^|[^a-z0-9])(?:4k|uhd)(?:$|[^a-z0-9])/i.test(text)) return "2160P";
    if (/(?:^|[^a-z0-9])2k(?:$|[^a-z0-9])/i.test(text)) return "1440P";
    if (/(?:^|[^a-z0-9])fhd(?:$|[^a-z0-9])/i.test(text)) return "1080P";
    if (text.indexOf("蓝光") >= 0) return "蓝光";
    if (text.indexOf("超清") >= 0) return "超清";
    if (text.indexOf("高清") >= 0) return "高清";
    if (text.indexOf("标清") >= 0) return "标清";
    return "";
}

function resolvePlay(sourceId, flag, playId, label, detailId, routeEpisodes) {
    var originalError = null;
    var response = null;
    try {
        response = callSourceCompatible(sourceId, ["playerContent"], [
            [flag || "", String(playId || ""), []],
            [flag || "", String(playId || "")]
        ]);
    } catch (error) {
        originalError = error;
        try {
            response = callSourceCompatible(sourceId, ["genericPlayerContent"], [
                [String(playId || ""), String(detailId || "")],
                [String(playId || "")]
            ]);
        } catch (ignoreInitialGenericPlayerError) {}
    }
    if (!response && originalError) throw originalError;
    if (typeof response === "string") {
        try { response = JSON.parse(response); } catch (ignoreJsonError) {
            response = {parse: 0, url: response};
        }
    }
    response = response || {};
    // 漫画图文：playerContent 返回 pics:// 多图地址（海阔多图阅读器协议）。
    // 海阔播放器/阅读器需要 url 直接是 pics:// 链接，不能被包装成 {urls,names,headers}；
    // 这里原样透出，让海阔识别为多图模式（下拉自动下一章）。
    var picDirect = String(response.url || response.playUrl || playId || "");
    if (picDirect.indexOf("pics://") === 0 || String(response.urls || "").indexOf("pics://") === 0) {
        return picDirect;
    }
    // 小说正文：playerContent 返回 novel://{json}（七猫等 hipy 小说源协议）。
    // 跳转 py_reader 子页面，由 reader.js 用 rich_text 渲染正文（海阔原生
    // 阅读器界面：点击/音量翻页、进度记忆），而非 webview 网页。
    if (picDirect.indexOf("novel://") === 0 || String(response.urls || "").indexOf("novel://") === 0 ||
        picDirect.indexOf("marchnovel://") === 0 ||
        /^data:text\/html(?:;[^,]*)?,/i.test(picDirect)) {
        var readerParams = {
            sourceId: String(sourceId || ""),
            flag: String(flag || ""),
            chapterId: String(playId || picDirect || ""),
            title: String(label || "小说正文")
        };
        var readerQuery = [];
        for (var readerKey in readerParams) {
            if (readerParams[readerKey]) readerQuery.push(readerKey + "=" + encodeURIComponent(readerParams[readerKey]));
        }
        return "hiker://page/py_reader_v1840?" + readerQuery.join("&");
    }
    // 小说/网页阅读：playerContent 返回 localProxy://（PY 壳 52020 代理提供
    // HTML 正文）时，海阔需以 webview 加载单个 URL，不能被包装成
    // {urls,names,headers} 多线路（会导致"未知链接"）。转成 proxy:// 由
    // normalizeProxyUrl 重建为 52020 代理 URL，原样透出单条。
    if (picDirect.indexOf("localProxy://") === 0 || picDirect.indexOf("marchnovel://") === 0 ||
        String(response.urls || "").indexOf("localProxy://") === 0 ||
        String(response.urls || "").indexOf("marchnovel://") === 0 ||
        /^data:text\/html(?:;[^,]*)?,/i.test(picDirect)) {
        // 小说/网页阅读：March 源 playerContent 可能把正文转成 data:text/html。
        // 先解码并写入按 playId 隔离的本地缓存，再交给 webview 加载真实 file://。
        if (/^data:text\/html(?:;[^,]*)?,/i.test(picDirect)) {
            try {
                var dataComma = picDirect.indexOf(",");
                if (dataComma < 0) throw new Error("data URL 缺少内容分隔符");
                var dataHeader = picDirect.slice(0, dataComma);
                var dataPayload = picDirect.slice(dataComma + 1);
                var dataHtml;
                if (/;base64(?:;|$)/i.test(dataHeader)) {
                    dataPayload = dataPayload.replace(/\s+/g, "");
                    var dataBytes = android.util.Base64.decode(String(dataPayload), android.util.Base64.DEFAULT);
                    dataHtml = String(new java.lang.String(dataBytes, "UTF-8"));
                } else {
                    dataHtml = decodeURIComponent(dataPayload);
                }
                var dataCachePath = "hiker://files/data/PY影视壳/cache/novel_" + md5(String(playId || "novel")) + ".html";
                writeFile(dataCachePath, dataHtml);
                var dataLocalPath = String(getPath(dataCachePath) || "");
                if (!dataLocalPath) throw new Error("缓存路径解析为空");
                var dataFileUrl = startsWith(dataLocalPath, "file://")
                    ? dataLocalPath
                    : "file://" + dataLocalPath;
                return "web://" + dataFileUrl;
            } catch (dataUrlError) {
                return "toast://正文缓存失败: " + errorText(dataUrlError);
            }
        }
        try {
            var localProxyParam = picDirect.indexOf("localProxy://") === 0
                ? decodeURIComponent(picDirect.replace(/^localProxy:\/\/\?param=/, ""))
                : picDirect.replace(/^marchnovel:\/\//, "marchnovel:");
            var proxyResult = callLocalProxy(sourceId, localProxyParam, "");
            var proxyBody = "";
            if (Array.isArray(proxyResult)) {
                proxyBody = String(proxyResult[2] || "");
            } else if (proxyResult && typeof proxyResult === "object") {
                proxyBody = String(proxyResult.body || proxyResult.content || "");
            } else if (typeof proxyResult === "string") {
                proxyBody = proxyResult;
            }
            if (!proxyBody || proxyBody.indexOf("<html") < 0) {
                proxyBody = "<html><head><meta charset='utf-8'><style>body{font-size:18px;line-height:1.9;padding:20px;color:#333}</style></head><body>" + String(proxyBody || "正文暂不可用") + "</body></html>";
            }
            var novelCachePath = "hiker://files/data/PY影视壳/cache/novel_" + md5(String(playId || "novel")) + ".html";
            try {
                writeFile(novelCachePath, proxyBody);
            } catch (ignoreNovelCacheWriteError) {
                return "toast://正文写入失败: " + errorText(ignoreNovelCacheWriteError);
            }
            // 转成 file:// 实际路径（web:// 后面需 http/file 地址；hiker://files 不能直接 webview）
            var novelFileUrl = novelCachePath;
            try {
                var novelLocal = String(getPath(novelCachePath) || novelCachePath);
                if (startsWith(novelLocal, "file://")) novelLocal = novelLocal.slice(7);
                if (startsWith(novelLocal, "hiker://")) novelLocal = novelCachePath;
                if (!startsWith(novelLocal, "hiker://")) novelFileUrl = "file://" + novelLocal;
            } catch (ignoreNovelPathError) {}
            return "web://" + novelFileUrl;
        } catch (localProxyError) {
            return "toast://正文获取失败: " + errorText(localProxyError);
        }
    }
    var parse = Number(response.parse || response.jx || 0);
    var rawUrls = response.urls || response.url;
    if (!rawUrls && parse === 0 && /^https?:\/\//i.test(String(response.playUrl || ""))) rawUrls = response.playUrl;
    rawUrls = rawUrls || playId;
    var urls = Array.isArray(rawUrls) ? rawUrls : [rawUrls];
    urls = urls.map(function(url) { return normalizeProxyUrl(url, sourceId); });

    var firstUrl = String(urls[0] || playId || "");
    var suspiciousPage = /^https?:\/\//i.test(firstUrl) && !isDirectMediaUrl(firstUrl) &&
        (isImageMediaUrl(firstUrl) || firstUrl === String(detailId || "") || /(?:\/$|\.(?:html?|php)(?:$|[?#]))/i.test(firstUrl));
    if (parse === 0 && suspiciousPage) {
        try {
            var repaired = callSourceCompatible(sourceId, ["genericPlayerContent"], [
                [firstUrl, String(detailId || "")],
                [firstUrl]
            ]) || {};
            response = repaired;
            rawUrls = response.url || firstUrl;
            urls = Array.isArray(rawUrls) ? rawUrls : [rawUrls];
            urls = urls.map(function(url) { return normalizeProxyUrl(url, sourceId); });
            parse = Number(response.parse || response.jx || 0);
        } catch (ignoreGenericPlayerError) {}
    }

    if (parse !== 0) {
        var parseTarget = String(urls[0] || playId);
        if (/^https?:\/\//.test(String(response.playUrl || ""))) parseTarget = String(response.playUrl) + parseTarget;
        return "video://" + parseTarget;
    }

    var names = response.names || response.name;
    if (!Array.isArray(names)) names = urls.map(function(_, index) { return index === 0 ? (label || flag || "播放") : "线路 " + (index + 1); });
    var headers = normalizeHeaders(response.headers || response.header, urls.length);
    var stableLines = stabilizePlaybackLines(urls, names, headers, label, flag);
    stableLines = prioritizeKbjPlaybackLines(sourceId, stableLines);
    stableLines = unwrapKbjHls2Proxy(sourceId, flag, stableLines);

    // 单条线路：若该 m3u8 是 master 播放列表（含多清晰度变体），把各清晰度
    // 解析为独立线路，播放页线路面板即可切换分辨率；解析失败/非 master 保持原样。
    if (stableLines.urls.length === 1 && !stableLines._skipMasterProbe) {
        try {
            var variants = resolveMasterPlaylistVariants(sourceId, String(stableLines.urls[0] || ""), stableLines.headers[0] || {});
            if (variants) {
                var variantUrls = variants.map(function(variant) { return normalizeProxyUrl(variant.url, sourceId); });
                var variantNames = variants.map(function(variant) { return String(variant.name || "线路"); });
                stableLines = stabilizePlaybackLines(variantUrls, variantNames, stableLines.headers, label, flag);
            }
        } catch (ignoreMasterVariantError) {}
    }

    // 多剧集（多分辨率分集）组装：detail.js 把当前线路的所有剧集一起传入。
    // 多清晰度源（如 FreePornVideos 的 2160P/720P/480P 分集）点击任一集播放时，
    // 把各集解析为独立线路，播放页线路面板显示全部清晰度可切换；
    // 只有 1 个剧集或非分辨率分集时保持原样（单线路不弹窗）。
    if (stableLines.urls.length === 1 && Array.isArray(routeEpisodes) && routeEpisodes.length > 1) {
        try {
            var episodeLines = [];
            var seenEpisodeIds = {};
            var seenEpisodeUrls = {};
            var qualityKeys = {};
            routeEpisodes.forEach(function(entry) {
                var text = String(entry || "");
                var separator = text.indexOf("$");
                var episodeName = separator > 0 ? text.slice(0, separator) : "";
                var episodeId = separator > 0 ? text.slice(separator + 1) : text;
                if (!episodeId || seenEpisodeIds[episodeId]) return;
                seenEpisodeIds[episodeId] = true;
                var qualityKey = playbackQualityKey(episodeName);
                if (qualityKey) qualityKeys[qualityKey] = true;
                episodeLines.push({name: episodeName, id: episodeId});
            });
            if (episodeLines.length > 1 && Object.keys(qualityKeys).length > 1) {
                var multiUrls = [];
                var multiNames = [];
                var multiHeaders = [];
                episodeLines.forEach(function(episodeLine) {
                    try {
                        var episodeResponse = callSourceCompatible(sourceId, ["playerContent"], [
                            [flag || "", String(episodeLine.id), []],
                            [flag || "", String(episodeLine.id)]
                        ]);
                        if (typeof episodeResponse === "string") {
                            var episodeResponseText = episodeResponse;
                            try { episodeResponse = JSON.parse(episodeResponseText); } catch (ignoreEpisodeJsonError) {
                                episodeResponse = {parse: 0, url: episodeResponseText};
                            }
                        }
                        var episodeUrl = episodeResponse && (episodeResponse.urls || episodeResponse.url);
                        if (!episodeUrl && episodeResponse && Number(episodeResponse.parse || episodeResponse.jx || 0) === 0 &&
                            /^https?:\/\//i.test(String(episodeResponse.playUrl || ""))) {
                            episodeUrl = episodeResponse.playUrl;
                        }
                        if (Array.isArray(episodeUrl)) episodeUrl = episodeUrl[0];
                        if (!episodeUrl && isDirectMediaUrl(episodeLine.id)) episodeUrl = episodeLine.id;
                        if (!episodeUrl) return;
                        episodeUrl = normalizeProxyUrl(String(episodeUrl), sourceId);
                        if (!episodeUrl || seenEpisodeUrls[episodeUrl]) return;
                        seenEpisodeUrls[episodeUrl] = true;
                        multiUrls.push(episodeUrl);
                        multiNames.push(episodeLine.name || ("线路 " + multiUrls.length));
                        var episodeHeader = episodeResponse && (episodeResponse.headers || episodeResponse.header);
                        var normalizedEpisodeHeaders = normalizeHeaders(episodeHeader, 1);
                        multiHeaders.push(normalizedEpisodeHeaders[0] || {});
                    } catch (ignoreEpisodeResolveError) {}
                });
                if (multiUrls.length > 1) {
                    stableLines = stabilizePlaybackLines(multiUrls, multiNames, multiHeaders, label, flag);
                }
            }
        } catch (ignoreEpisodeLineError) {}
    }

    return JSON.stringify({urls: stableLines.urls, names: stableLines.names, headers: stableLines.headers, parse: 0});
}

// 小说正文解析：reader.js 调用。调源 playerContent 拿正文，兼容多种格式：
// novel://{json}（七猫 hipy 源）、data:text/html（March 源）、
// {url: 网页}（po18 网页源）。返回 {title, content} 纯文本。
function resolveNovelContent(sourceId, flag, chapterId) {
    var response = null;
    try {
        response = callSourceCompatible(sourceId, ["playerContent"], [
            [flag || "", String(chapterId || ""), []],
            [flag || "", String(chapterId || "")]
        ]);
    } catch (novelResolveError) {
        return {title: "", content: "", error: errorText(novelResolveError)};
    }
    if (typeof response === "string") {
        try { response = JSON.parse(response); } catch (ignoreNovelJsonError) {
            response = {parse: 0, url: response};
        }
    }
    response = response || {};
    var direct = String(response.url || response.playUrl || "");
    var title = "";
    var content = "";
    try {
        // novel://{json}
        if (direct.indexOf("novel://") === 0) {
            var payload = direct.slice("novel://".length);
            var data = JSON.parse(payload);
            title = String(data.title || data.name || "");
            content = String(data.content || data.text || "");
        } else if (/^data:text\/html(?:;[^,]*)?,/i.test(direct)) {
            // data:text/html（March 源）
            var dComma = direct.indexOf(",");
            if (dComma >= 0) {
                var dHeader = direct.slice(0, dComma);
                var dPayload = direct.slice(dComma + 1);
                var dHtml;
                if (/;base64(?:;|$)/i.test(dHeader)) {
                    dPayload = dPayload.replace(/\s+/g, "");
                    var dBytes = android.util.Base64.decode(String(dPayload), android.util.Base64.DEFAULT);
                    dHtml = String(new java.lang.String(dBytes, "UTF-8"));
                } else {
                    dHtml = decodeURIComponent(dPayload);
                }
                content = stripHtmlTags(dHtml);
            }
        } else if (String(response.content || response.text || "")) {
            content = String(response.content || response.text || "");
        } else if (/^https?:/i.test(direct) && response.parse === 0) {
            // 网页源（po18）：内容在网页里，reader 无法直接渲染正文，提示用网页打开
            content = "该章节为网页版，请在浏览器中打开阅读：" + direct;
        }
    } catch (novelParseError) {
        return {title: title, content: content, error: errorText(novelParseError)};
    }
    if (!title && String(chapterId || "").indexOf("@@") > 0) {
        title = String(chapterId).split("@@")[2] || "";
    }
    return {title: title, content: content};
}

// 简易 HTML 标签剥离（正文转纯文本）
function stripHtmlTags(html) {
    var text = String(html || "");
    text = text.replace(/<script[\s\S]*?<\/script>/gi, "");
    text = text.replace(/<style[\s\S]*?<\/style>/gi, "");
    text = text.replace(/<br\s*\/?>/gi, "\n");
    text = text.replace(/<\/p>/gi, "\n");
    text = text.replace(/<[^>]+>/g, "");
    text = text.replace(/&nbsp;/gi, " ");
    text = text.replace(/&amp;/gi, "&");
    text = text.replace(/&lt;/gi, "<");
    text = text.replace(/&gt;/gi, ">");
    text = text.replace(/&quot;/gi, '"');
    text = text.replace(/&#39;/g, "'");
    text = text.replace(/\n{3,}/g, "\n\n");
    return text;
}

var coreExports = {
    BUILD_VERSION: BUILD_VERSION,
    CORE_PAGE_PATH: CORE_PAGE_PATH,
    __proxyMark: (typeof MY_PARAMS !== "undefined" && MY_PARAMS !== null) ? "proxy-thread" : "main-thread",
    RUNTIME_INFO: RUNTIME_INFO,
    DATA_ROOT: DATA_ROOT,
    SOURCE_ROOT: SOURCE_ROOT,
    INDEX_PATH: INDEX_PATH,
    LINE_SOURCE_INDEX_PATH: LINE_SOURCE_INDEX_PATH,
    ACTIVE_SOURCE_PATH: ACTIVE_SOURCE_PATH,
    HISTORY_PATH: HISTORY_PATH,
    SCAN_FOLDER_PATH: SCAN_FOLDER_PATH,
    BATCH_REPORT_PATH: BATCH_REPORT_PATH,
    CONFIG_INDEX_PATH: CONFIG_INDEX_PATH,
    SOURCE_STATUS_PATH: SOURCE_STATUS_PATH,
    LIVE_INDEX_PATH: LIVE_INDEX_PATH,
    CATEGORY_PREFETCH_PATH: CATEGORY_PREFETCH_PATH,
    errorText: errorText,
    normalizeProxyBodyResult: normalizeProxyBodyResult,
    normalizeProxyImageResult: normalizeProxyImageResult,
    directProxyImageFallback: directProxyImageFallback,
    fetchDirectProxyImage: fetchDirectProxyImage,
    getLocalProxyUrl: getLocalProxyUrl,
    getIndex: getIndex,
    getLineSourceIndex: getLineSourceIndex,
    getUserSources: getUserSources,
    sortSources: sortSources,
    moveSource: moveSource,
    listSources: listSources,
    listUserSources: listUserSources,
    getSource: getSource,
    getCurrentSource: getCurrentSource,
    getSourceSelection: getSourceSelection,
    setCurrentSource: setCurrentSource,
    renameSource: renameSource,
    listEnabledSources: listEnabledSources,
    isSourceEnabled: isSourceEnabled,
    setSourceEnabled: setSourceEnabled,
    sourceDomain: sourceDomain,
    detectDuplicateDomains: detectDuplicateDomains,
    getSourceStats: getSourceStats,
    listHistory: listHistory,
    recordHistory: recordHistory,
    removeHistory: removeHistory,
    clearHistory: clearHistory,
    getScanFolder: getScanFolder,
    setScanFolder: setScanFolder,
    listFolderRoots: listFolderRoots,
    listFolder: listFolder,
    getBatchImportReport: getBatchImportReport,
    importFolder: importFolder,
    importSource: importSource,
    importPyCode: importPyCode,
    importJsCode: importJsCode,
    importLocation: importLocation,
    readImportLocation: readImportLocation,
    getConfigIndex: getConfigIndex,
    saveConfigLine: saveConfigLine,
    activateConfigLine: activateConfigLine,
    moveConfigLine: moveConfigLine,
    removeConfigLine: removeConfigLine,
    getSourceStatusCache: getSourceStatusCache,
    saveSourceStatus: saveSourceStatus,
    sourceRuntimeKind: sourceRuntimeKind,
    setSourceExtend: setSourceExtend,
    removeSource: removeSource,
    clearRuntimeCache: clearRuntimeCache,
    callbackCoreLoaderSource: callbackCoreLoaderSource,
    getLiveIndexPath: getLiveIndexPath,
    getLiveSources: getLiveSources,
    saveLiveSources: saveLiveSources,
    renameLiveSource: renameLiveSource,
    updateLiveSource: updateLiveSource,
    sortLiveSources: sortLiveSources,
    moveLiveSource: moveLiveSource,
    removeLiveSources: removeLiveSources,
    getRuntime: getRuntime,
    importUrl: importUrl,
    callSource: callSource,
    callSourceCompatible: callSourceCompatible,
    callLocalProxy: callLocalProxy,
    fetchDirectProxyImage: fetchDirectProxyImage,
    prepareSource: prepareSource,
    warmSource: warmSource,
    consumeWarmHome: consumeWarmHome,
    prefetchCategory: prefetchCategory,
    consumePrefetchedCategory: consumePrefetchedCategory,
    cachedCategorySource: cachedCategorySource,
    clearCategoryPrefetch: clearCategoryPrefetch,
    getHomeClasses: getHomeClasses,
    cacheHomeClasses: cacheHomeClasses,
    clearHomeClasses: clearHomeClasses,
    getHomeFilters: getHomeFilters,
    cacheHomeFilters: cacheHomeFilters,
    clearHomeFilters: clearHomeFilters,
    normalizeVod: normalizeVod,
    normalizeVodList: normalizeVodList,
    getVodRawCached: getVodRawCached,
    normalizePageResult: normalizePageResult,
    normalizeHomeResult: normalizeHomeResult,
    imageUrl: imageUrl,
    listImageUrl: listImageUrl,
    upgradeImageHttps: upgradeImageHttps,
    adaptiveDirectImageUrl: adaptiveDirectImageUrl,
    parseHikerImageRequest: parseHikerImageRequest,
    normalizeProxyUrl: normalizeProxyUrl,
    surritAdaptiveUrl: surritAdaptiveUrl,
    resolveMasterPlaylistVariants: resolveMasterPlaylistVariants,
    stabilizePlaybackLines: stabilizePlaybackLines,
    mergeVodListWithGeneric: mergeVodListWithGeneric,
    enrichVodListFromGeneric: enrichVodListFromGeneric,
    homeSource: homeSource,
    homeVideoSource: homeVideoSource,
    categorySource: categorySource,
    detailSource: detailSource,
    searchSource: searchSource,
    compatibilityReport: compatibilityReport,
    checkSource: checkSource,
    checkSourceConnectivity: checkSourceConnectivity,
    verifySourceImage: verifySourceImage,
    removeSources: removeSources,
    createSourcesShare: createSourcesShare,
    resolvePlay: resolvePlay,
    resolveNovelContent: resolveNovelContent,
    stripHtmlTags: stripHtmlTags,
};
$.exports = coreExports;
writeCoreSlot(coreExports);
