function loadPopupCore(requiredMethods) {
    var corePath = "hiker://files/data/PY\u5f71\u89c6\u58f3/subpage/py_core.js";
    var pagePath = "hiker://page/py_core_v1840";
    var buildVersion = "2026081840";
    var methods = Array.isArray(requiredMethods) ? requiredMethods : [];
    function ready(candidate) {
        if (!candidate) return false;
        for (var i = 0; i < methods.length; i++) {
            if (typeof candidate[methods[i]] !== "function") return false;
        }
        return true;
    }
    function sharedCore() {
        var slots = [];
        try { if (typeof globalThis !== "undefined" && globalThis) slots.push(globalThis); } catch (ignoreGlobalThisError) {}
        try { if (typeof window !== "undefined" && window) slots.push(window); } catch (ignoreWindowError) {}
        try { if (typeof top !== "undefined" && top) slots.push(top); } catch (ignoreTopError) {}
        for (var index = 0; index < slots.length; index++) {
            try {
                var entry = slots[index].__pyCoreModule;
                if (entry && String(entry.version || "") === buildVersion && ready(entry.module)) return entry.module;
            } catch (ignoreSharedCoreError) {}
        }
        return null;
    }
    var loaded = sharedCore();
    if (!ready(loaded)) {
        try { loaded = $.require(pagePath); } catch (ignorePageRequireError) {}
    }
    if (!ready(loaded)) {
        try { loaded = $.require(corePath); } catch (ignoreFileRequireError) {}
    }
    if (!ready(loaded)) {
        try { loaded = $.require(corePath, true); } catch (ignoreFileReloadError) {}
    }
    if (!ready(loaded)) {
        var previousExports = $.exports;
        try {
            $.exports = {};
            var code = "";
            try {
                if (typeof readFile === "function") code = String(readFile(corePath) || "");
            } catch (ignoreReadError) {}
            if (!code) code = String(request(corePath) || "");
            if (!code) throw new Error("PY core module is empty");
            eval(code);
            loaded = $.exports;
        } finally {
            $.exports = previousExports;
        }
    }
    if (!ready(loaded)) {
        var missing = [];
        for (var j = 0; j < methods.length; j++) {
            if (!loaded || typeof loaded[methods[j]] !== "function") missing.push(methods[j]);
        }
        throw new Error("PY core module missing methods: " + missing.join(", "));
    }
    return loaded;
}

function loadPopupLibrary() {
    var libraryPath = "hiker://files/data/PY\u5f71\u89c6\u58f3/libs/hiker_pop_883.js";
    function ready(candidate) {
        return candidate && typeof candidate.setUseStartActivity === "function" &&
            typeof candidate.selectBottomRes === "function" &&
            typeof candidate.runOnNewThread === "function" &&
            typeof candidate.runOnUIThread === "function";
    }
    var loaded = null;
    try { loaded = $.require(libraryPath); } catch (ignorePopupLibraryRequireError) {}
    if (!ready(loaded)) {
        try { loaded = $.require(libraryPath, true); } catch (ignorePopupLibraryReloadError) {}
    }
    if (!ready(loaded)) {
        var previousExports = $.exports;
        try {
            $.exports = {};
            var code = "";
            try {
                if (typeof readFile === "function") code = String(readFile(libraryPath) || "");
            } catch (ignorePopupLibraryReadError) {}
            if (!code) code = String(request(libraryPath) || "");
            code = code.replace(/^\s*js:\s*/, "");
            if (!code) throw new Error("Popup library is empty");
            eval(code);
            loaded = $.exports;
        } finally {
            $.exports = previousExports;
        }
    }
    if (!ready(loaded)) throw new Error("Popup library is incomplete");
    return loaded;
}

var core = loadPopupCore([
    "getSourceStatusCache",
    "getSourceSelection",
    "saveSourceStatus",
    "checkSourceConnectivity",
    "errorText",
    "setCurrentSource"
]);
var hikerPop = loadPopupLibrary();
var DETECT_VERSION = 6;
var DETECT_TTL = 10 * 60 * 1000;
var detectLockKey = "py_source_popup_detecting_v" + DETECT_VERSION;
var statusCache = core.getSourceStatusCache();

function statusState(sourceId) {
    var value = statusCache.sources[String(sourceId)] || {};
    // 该函数会从 UI 线程回调触发，避免读取可能不在回调作用域中的顶层变量。
    if (Number(value.version || 0) !== 6) return {state: "unknown"};
    return value;
}

function marker(state) {
    if (state === "valid") return "✅ ";
    if (state === "invalid") return "❌ ";
    return "⏳ ";
}

function sourceLabel(source, currentId, showStatus) {
    var state = statusState(source.id);
    return (String(source.id) === String(currentId) ? "➡️ " : "") + (showStatus === false ? "" : marker(state.state)) + String(source.name || source.fileName || source.id);
}

function searchableText(source) {
    return [source.name, source.fileName, source.path, source.api, source.remoteUrl, source.runtime]
        .map(function(value) { return String(value || "").toLowerCase(); })
        .join(" ");
}

function show(mode) {
    hikerPop.setUseStartActivity(false);
    var selection = core.getSourceSelection(mode || "active");
    var sources = selection.sources || [];
    var scopeMode = String(selection.mode || "py");
    var scopeTitle = scopeMode === "line" ? "线路源" : "PY源";
    var showStatus = scopeMode === "py";
    if (!sources.length) return "toast://当前没有启用的" + scopeTitle;
    var currentId = selection.current;
    var searchText = "";
    var visibleIds = [];
    var popup = null;
    var popupClosed = false;

    function rebuild(manage) {
        var keyword = String(searchText || "").trim().toLowerCase();
        var filtered = sources.filter(function(source) {
            if (!keyword) return true;
            if (keyword[0] === "?") {
                try { return new RegExp(keyword.slice(1), "i").test(searchableText(source)); } catch (ignoreRegexError) {}
            }
            return searchableText(source).indexOf(keyword) >= 0;
        });
        visibleIds = filtered.map(function(source) { return String(source.id); });
        manage.list.length = 0;
        filtered.forEach(function(source) { manage.list.push(sourceLabel(source, currentId, showStatus)); });
        manage.setTitle("选择" + scopeTitle + " 当前共:" + sources.length + "个" + (keyword ? " · 匹配" + filtered.length : ""));
        manage.change();
    }

    function detect(manage, forcedId) {
        if (String(getMyVar(detectLockKey, "") || "") === "1") {
            if (forcedId) toast("检测正在进行");
            return;
        }
        putMyVar(detectLockKey, "1");
        hikerPop.runOnNewThread(function() {
            // 海阔 UI/后台回调可能使用独立 Rhino 作用域，异步回绘不能依赖模块顶层常量。
            var callbackDetectVersion = 6;
            var callbackDetectTtl = 10 * 60 * 1000;
            var valid = 0;
            var invalid = 0;
            try {
                for (var i = 0; i < sources.length; i++) {
                    var source = sources[i];
                    if (forcedId && String(source.id) !== String(forcedId)) continue;
                    var old = statusState(source.id);
                    var fresh = Number(old.version || 0) === callbackDetectVersion && Date.now() - Number(old.savedAt || 0) < callbackDetectTtl;
                    if (!forcedId && fresh && (old.state === "valid" || old.state === "invalid")) {
                        if (old.state === "valid") valid++;
                        else invalid++;
                        continue;
                    }
                    statusCache.sources[String(source.id)] = core.saveSourceStatus(source.id, {version: callbackDetectVersion, state: "pending", message: "检测中"});
                    try {
                        hikerPop.runOnUIThread(function() { if (!popupClosed) rebuild(manage); });
                    } catch (ignorePendingUiError) {}
                    try {
                        var report = core.checkSourceConnectivity(source.id);
                        var state = report && report.ok ? "valid" : "invalid";
                        if (state === "valid") valid++;
                        else invalid++;
                        statusCache.sources[String(source.id)] = core.saveSourceStatus(source.id, {
                            version: callbackDetectVersion,
                            state: state,
                            message: report && (report.detail || report.error) || "检测完成",
                            elapsed: Number(report && report.elapsed || 0),
                            stage: String(report && report.stage || "源站")
                        });
                    } catch (error) {
                        invalid++;
                        statusCache.sources[String(source.id)] = core.saveSourceStatus(source.id, {version: callbackDetectVersion, state: "invalid", message: core.errorText(error)});
                    }
                    try {
                        hikerPop.runOnUIThread(function() { if (!popupClosed) rebuild(manage); });
                    } catch (ignoreResultUiError) {}
                }
                if (!forcedId) {
                    hikerPop.runOnUIThread(function() { toast("源检测完成：正常" + valid + " 异常" + invalid); });
                }
            } finally {
                putMyVar(detectLockKey, "");
            }
        });
    }

    var initial = sources.map(function(source) { return sourceLabel(source, currentId, showStatus); });
    visibleIds = sources.map(function(source) { return String(source.id); });
    var currentPosition = Math.max(0, visibleIds.indexOf(String(currentId)));
    var inputBox = new hikerPop.ResExtraInputBox({
        hint: "源关键字",
        title: "搜索",
        titleVisible: true,
        defaultValue: "",
        onChange: function(text, manage) {
            searchText = String(text || "");
            rebuild(manage);
        },
        click: function(_, manage) {
            searchText = "";
            inputBox.setDefaultValue("");
            rebuild(manage);
        }
    });

    popup = hikerPop.selectBottomRes({
        options: initial,
        columns: 3,
        height: 0.82,
        title: "选择" + scopeTitle + " 当前共:" + sources.length + "个",
        noAutoDismiss: true,
        toPosition: currentPosition,
        extraInputBox: inputBox,
        beforeShow: function(_, manage) {
            // Hiker 8.83 may ignore the initial span count passed to with().
            manage.changeColumns(3);
        },
        onDismiss: function() { popupClosed = true; },
        menuClick: function() {
            try { popup.dismiss(); } catch (ignoreMenuDismissError) {}
            return scopeMode === "line"
                ? "hiker://page/py_config_lines_v1840#noRecordHistory##noHistory#"
                : "hiker://page/py_source_manager_v1840#noRecordHistory##noHistory#";
        },
        click: function(_, position) {
            var sourceId = visibleIds[Number(position)];
            if (!sourceId) return;
            try {
                core.setCurrentSource(sourceId);
                // belt-and-suspenders: some Haiku runtimes drop setActiveSourceId write;
                // write active_source.json directly to guarantee the selection sticks.
                try { writeFile(core.DATA_ROOT + "/active_source.json", JSON.stringify({version: 1, sourceId: String(sourceId)})); } catch (ignoreDirectWrite) {}
                try { popup.dismiss(); } catch (ignoreDismissError) {}
                refreshPage(true);
            } catch (error) {
                toast("切换源失败：" + core.errorText(error));
            }
        },
        longClick: function(_, position, manage) {
            var sourceId = visibleIds[Number(position)];
            if (!sourceId) return;
            var source = sources.find(function(item) { return String(item.id) === String(sourceId); });
            // 源长按操作：检测 + 排序（海阔弹窗无拖动排序，用置顶/上移/下移/置底）
            hikerPop.selectCenter({
                options: ["重新检测", "置顶", "上移", "下移", "置底", "打开源管理"],
                columns: 2,
                title: String(source && source.name || "源操作"),
                click: function(action) {
                    if (action === "重新检测") {
                        detect(manage, sourceId);
                        return;
                    }
                    if (action === "置顶" || action === "上移" || action === "下移" || action === "置底") {
                        var moveModes = {"置顶": "top", "上移": "up", "下移": "down", "置底": "bottom"};
                        try {
                            var loader = loadPopupCore(["moveSource"]);
                            loader.moveSource(sourceId, moveModes[action]);
                            // 重新拉取源列表并重建弹窗，让顺序立即生效
                            var fresh = core.getSourceSelection(mode || "active");
                            sources = fresh.sources || [];
                            currentId = fresh.current || "";
                            rebuild(manage);
                            try { toast("已" + action); } catch (ignoreMoveToastError) {}
                        } catch (error) {
                            try { toast("排序失败：" + core.errorText(error)); } catch (ignoreMoveErrorToast) {}
                        }
                        return;
                    }
                    if (action === "打开源管理") {
                        // 跳转源管理页面（menuClick/click 返回 URL 即跳转）
                        try { popup.dismiss(); } catch (ignoreOpenManagerDismissError) {}
                        return "hiker://page/py_source_manager_v1840#noRecordHistory##noHistory#";
                    }
                    try { popup.dismiss(); } catch (ignoreManageDismissError) {}
                    refreshPage(false);
                }
            });
        }
    });
    return "hiker://empty";
}

$.exports = {
    show: show,
    detectVersion: DETECT_VERSION,
    marker: marker,
    sourceLabel: sourceLabel,
    searchableText: searchableText
};
