import json
import builtins
import asyncio
import ast
import hashlib
import importlib.util
import os
import sys
import threading
import time
import weakref
import requests
from html.parser import HTMLParser
from urllib.parse import urlsplit, urlunsplit
from org.mozilla.javascript import Context as JSContext, Function, NativeJavaMap, NativeArray, NativeObject
from com.chaquo.python import PyObject
from base.hiker import *
from java import *
import inspect


def _load_local_source_compat():
    """Load this runtime's compatibility layer without using a shared name."""
    local_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "source_compat.py"))
    with open(local_path, "rb") as source_file:
        payload = source_file.read()
    identity = local_path.encode("utf-8") + b"\0" + payload
    module_name = "hiker_source_compat_" + hashlib.sha256(identity).hexdigest()[:12]
    existing = sys.modules.get(module_name)
    if existing is not None and os.path.abspath(getattr(existing, "__file__", "")) == local_path:
        return existing

    spec = importlib.util.spec_from_file_location(module_name, local_path)
    if spec is None or spec.loader is None:
        raise ImportError("cannot load local source compatibility module: " + local_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        if sys.modules.get(module_name) is module:
            sys.modules.pop(module_name, None)
        raise
    return module


_source_compat_module = _load_local_source_compat()
invalidate_source_cache = _source_compat_module.invalidate_source_cache
patch_source_compat = _source_compat_module.patch_source_compat
prepare_source_cache = _source_compat_module.prepare_source_cache
prune_source_cache = _source_compat_module.prune_source_cache


_managed_android_proxy = ""
_requests_compat_installed = False
_signature_cache = weakref.WeakKeyDictionary()
_bunny_state_lock = threading.Lock()
_bunny_host_locks = {}
_bunny_cookie_cache = {}
_bunny_cookie_generation = 0
_BUNNY_COOKIE_TTL_SECONDS = 15 * 60
_BUNNY_POW_DIFFICULTY = 13
_BUNNY_POW_MAX_ATTEMPTS = 32768
_BUNNY_POW_MAX_SECONDS = 12.0


class _BunnyPowParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.value = ""

    def handle_starttag(self, _tag, attrs):
        if self.value:
            return
        for name, value in attrs:
            if str(name or "").lower() == "data-pow":
                self.value = str(value or "").strip()
                return


def _response_text(response):
    try:
        return str(response.text or "")
    except Exception:
        try:
            return bytes(response.content or b"").decode("utf-8", "ignore")
        except Exception:
            return ""


def _extract_bunny_pow(response):
    if response is None or int(getattr(response, "status_code", 0) or 0) != 403:
        return ""
    headers = getattr(response, "headers", {}) or {}
    challenge_header = str(headers.get("CDN-Challenge", "") or "").strip().lower()
    body = _response_text(response)
    if challenge_header not in ("true", "1", "yes") and ".bunny-shield/" not in body:
        return ""
    parser = _BunnyPowParser()
    try:
        parser.feed(body[:131072])
    except Exception:
        return ""
    value = parser.value
    parts = value.split("#")
    if len(parts) != 4 or len(value) > 1024 or any(not part for part in parts):
        return ""
    return value


def _java_byte_array(value):
    raw = bytes(value)
    return jarray(jbyte)([(item - 256) if item > 127 else item for item in raw])


def _new_argon2id_hasher(userkey):
    from org.bouncycastle.crypto.generators import Argon2BytesGenerator
    from org.bouncycastle.crypto.params import Argon2Parameters

    params = (Argon2Parameters.Builder(Argon2Parameters.ARGON2_id)
              .withSalt(_java_byte_array(userkey.encode("utf-8")))
              .withIterations(2)
              .withMemoryAsKB(512)
              .withParallelism(1)
              .build())
    generator = Argon2BytesGenerator()
    generator.init(params)

    def hash_password(password):
        output = jarray(jbyte)([0] * 32)
        generator.generateBytes(_java_byte_array(password.encode("utf-8")), output)
        return "".join("%02x" % (int(item) & 0xff) for item in output)

    return hash_password


def _bunny_hash_matches(hash_hex, difficulty=_BUNNY_POW_DIFFICULTY):
    hash_hex = str(hash_hex or "").lower()
    prefix = "0" * (difficulty // 8)
    if not hash_hex.startswith(prefix) or len(hash_hex) <= len(prefix):
        return False
    try:
        nibble = int(hash_hex[len(prefix)], 16)
    except (TypeError, ValueError):
        return False
    shift = ((len(prefix) + 1) * 8) - difficulty
    if shift < 0 or shift > 7:
        return False
    return (nibble & (0xff >> shift)) == 0


def _solve_bunny_pow(pow_value, max_attempts=_BUNNY_POW_MAX_ATTEMPTS,
                      max_seconds=_BUNNY_POW_MAX_SECONDS):
    parts = str(pow_value or "").split("#")
    if len(parts) != 4:
        return ""
    userkey, challenge = parts[0], parts[1]
    hasher = _new_argon2id_hasher(userkey)
    deadline = time.monotonic() + max(0.1, float(max_seconds))
    for answer in range(max(0, int(max_attempts))):
        if answer and answer % 16 == 0 and time.monotonic() >= deadline:
            break
        if _bunny_hash_matches(hasher(challenge + str(answer))):
            return pow_value + "#" + str(answer)
    return ""


def _host_key(url):
    try:
        parsed = urlsplit(str(url or ""))
        return parsed.hostname.lower() if parsed.hostname else ""
    except Exception:
        return ""


def _host_lock(host):
    with _bunny_state_lock:
        lock = _bunny_host_locks.get(host)
        if lock is None:
            lock = threading.Lock()
            _bunny_host_locks[host] = lock
        return lock


def _apply_cached_bunny_cookies(session, host):
    now = time.monotonic()
    with _bunny_state_lock:
        state = _bunny_cookie_cache.get(host)
        if state and state[0] <= now:
            _bunny_cookie_cache.pop(host, None)
            state = None
    if not state:
        return 0
    _, generation, cookies = state
    jar = getattr(session, "cookies", None)
    if jar is not None:
        for name, value, domain, path in cookies:
            try:
                jar.set(name, value, domain=domain or host, path=path or "/")
            except Exception:
                try:
                    jar.set(name, value)
                except Exception:
                    pass
    return generation


def _remember_bunny_cookies(session, host):
    global _bunny_cookie_generation
    cookies = []
    try:
        for cookie in session.cookies:
            domain = str(getattr(cookie, "domain", "") or "").lstrip(".")
            if domain and host != domain and not host.endswith("." + domain):
                continue
            name = str(getattr(cookie, "name", "") or "")
            if name.startswith("bunny_shield"):
                cookies.append((name, str(cookie.value), domain or host,
                                str(getattr(cookie, "path", "/") or "/")))
    except Exception:
        return 0
    if not cookies:
        return 0
    with _bunny_state_lock:
        _bunny_cookie_generation += 1
        generation = _bunny_cookie_generation
        _bunny_cookie_cache[host] = (
            time.monotonic() + _BUNNY_COOKIE_TTL_SECONDS,
            generation,
            tuple(cookies),
        )
    return generation


def _bunny_verify_url(request_url):
    parsed = urlsplit(str(request_url or ""))
    return urlunsplit((parsed.scheme, parsed.netloc, "/.bunny-shield/verify-pow", "", ""))


def _post_bunny_verification(session, original_request, request_url, pow_response, request_kwargs):
    parsed = urlsplit(str(request_url or ""))
    origin = urlunsplit((parsed.scheme, parsed.netloc, "", "", ""))
    headers = {
        "Content-Type": "application/json",
        "BunnyShield-Challenge-Response": pow_response,
        "Origin": origin,
        "Referer": str(request_url),
    }
    kwargs = {
        "headers": headers,
        "data": b"",
        "allow_redirects": False,
        "timeout": request_kwargs.get("timeout", (4, 8)),
        "verify": request_kwargs.get("verify", False),
    }
    for name in ("proxies", "cert"):
        if name in request_kwargs:
            kwargs[name] = request_kwargs[name]
    try:
        response = original_request(session, "POST", _bunny_verify_url(request_url), **kwargs)
        return int(getattr(response, "status_code", 500) or 500) < 400
    except Exception:
        return False


def _retry_after_bunny_challenge(session, original_request, method, url, request_kwargs,
                                  challenge_response, initial_generation):
    pow_value = _extract_bunny_pow(challenge_response)
    host = _host_key(url)
    if not pow_value or not host:
        return challenge_response
    with _host_lock(host):
        current_generation = _apply_cached_bunny_cookies(session, host)
        if current_generation and current_generation != initial_generation:
            try:
                challenge_response.close()
            except Exception:
                pass
            return original_request(session, method, url, **request_kwargs)
        try:
            pow_response = _solve_bunny_pow(pow_value)
        except Exception:
            return challenge_response
        if not pow_response or not _post_bunny_verification(
                session, original_request, url, pow_response, request_kwargs):
            return challenge_response
        _remember_bunny_cookies(session, host)
        try:
            challenge_response.close()
        except Exception:
            pass
        return original_request(session, method, url, **request_kwargs)


def _install_requests_compat():
    """给未显式声明证书策略的 PY 请求补上 Android 兼容默认值。

    许多影视源直接调用 requests.get/post，Chaquopy 的 Android 证书链
    与桌面 Python 不完全一致。源脚本如果明确传入 verify，则继续尊重源脚本。
    """
    global _requests_compat_installed
    if _requests_compat_installed:
        return
    try:
        session_type = requests.Session
        original_request = session_type.request
        if getattr(original_request, "_py_hiker_verify_compat", False):
            _requests_compat_installed = True
            return

        def compatible_request(self, method, url, **kwargs):
            if "verify" not in kwargs:
                kwargs["verify"] = False
            if "timeout" not in kwargs:
                # Metadata requests must not leave a Hiker label callback waiting
                # indefinitely when a source omits its own timeout.
                kwargs["timeout"] = (4, 8)
            normalized_method = str(method or "GET").upper()
            initial_generation = 0
            if normalized_method in ("GET", "HEAD"):
                host = _host_key(url)
                if host:
                    initial_generation = _apply_cached_bunny_cookies(self, host)
            response = original_request(self, method, url, **kwargs)
            if normalized_method not in ("GET", "HEAD"):
                return response
            return _retry_after_bunny_challenge(
                self, original_request, method, url, kwargs, response, initial_generation
            )

        compatible_request._py_hiker_verify_compat = True
        session_type.request = compatible_request
        _requests_compat_installed = True
    except Exception:
        # 某些极简运行时可能没有可写的 Session.request；不阻断 PY 加载。
        _requests_compat_installed = False


_install_requests_compat()


def _normalize_proxy_value(value):
    value = str(value or "").strip()
    if not value or value.lower() in ("null", "none", "direct", ":0", "0.0.0.0:0"):
        return ""
    # Android 的 http_proxy 通常是 host:port；部分系统会在逗号后追加排除列表。
    value = value.split(",", 1)[0].strip()
    if not value or value.endswith(":0"):
        return ""
    if "://" not in value:
        value = "http://" + value
    return value


def _read_android_proxy():
    try:
        from android.provider import Settings
        from com.example.hikerview.service.parser import JSEngine

        activity = JSEngine.getInstance().getCurrentActivity(None)
        if activity is not None:
            value = Settings.Global.getString(activity.getContentResolver(), "http_proxy")
            return str(value or ""), "android_settings"
    except Exception:
        pass

    try:
        from java.lang import System

        host = System.getProperty("http.proxyHost")
        port = System.getProperty("http.proxyPort")
        if host and port:
            return "%s:%s" % (host, port), "java_properties"
    except Exception:
        pass
    return "", "unavailable"


def sync_android_proxy():
    """让 requests/urllib3 跟随 Android 当前的全局 HTTP 代理。"""
    global _managed_android_proxy
    raw_proxy, source = _read_android_proxy()
    if source == "unavailable":
        return {
            "enabled": bool(_managed_android_proxy),
            "proxy": _managed_android_proxy,
            "source": source,
            "unchanged": True,
        }
    proxy = _normalize_proxy_value(raw_proxy)
    proxy_keys = ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy")

    if proxy:
        for key in proxy_keys:
            os.environ[key] = proxy
        bypass = os.environ.get("NO_PROXY") or os.environ.get("no_proxy") or ""
        bypass_items = [item.strip() for item in bypass.split(",") if item.strip()]
        for item in ("127.0.0.1", "127.0.0.0/8", "localhost", "::1", "10.0.2.15"):
            if item not in bypass_items:
                bypass_items.append(item)
        bypass = ",".join(bypass_items)
        os.environ["NO_PROXY"] = bypass
        os.environ["no_proxy"] = bypass
    elif _managed_android_proxy:
        for key in proxy_keys:
            if os.environ.get(key) == _managed_android_proxy:
                os.environ.pop(key, None)

    _managed_android_proxy = proxy
    return {"enabled": bool(proxy), "proxy": proxy, "source": source}

def json_parse(content):
    return json.loads(content)

def json_stringify(data):
    return json.dumps(data, ensure_ascii=False)


def call_function_to_jsonstr(mo, func_name,*args, **kwargs):
    return json_stringify(call_function(mo,func_name,*args, **kwargs))

def call_function(mo, func_name,*args, **kwargs):
    func = getattr(mo,func_name,None)
    if func and callable(func):
        return func(*args, **kwargs)
    else:
        raise ValueError(f"Function {func_name} not found in module")


def _ensure_spider_defaults(spider):
    try:
        getattr(spider, "_debug")
    except AttributeError:
        try:
            setattr(spider, "_debug", False)
        except (AttributeError, TypeError):
            pass
    return spider


def instantiate_spider(mo):
    spider_type = getattr(mo, "Spider", None)
    if spider_type is None or not callable(spider_type):
        # 影视壳（TVBox/影视仓）部分 PY 源没有 Spider 类，直接在模块顶层
        # 定义 homeContent/categoryContent/detailContent/searchContent 等
        # 函数。此时把模块本身包装成 Spider 兼容对象，页面调用链无需改动。
        top_funcs = [name for name in (
            "homeContent", "homeVideoContent", "categoryContent", "detailContent",
            "searchContent", "playerContent", "localProxy", "getName",
            "getImageHeaders", "genericVideoList", "init",
        ) if callable(getattr(mo, name, None))]
        if top_funcs:
            return _ensure_spider_defaults(_FunctionalSpiderAdapter(mo))
        raise ValueError("Spider class not found in module")

    # 部分影视源继承的模板把可选方法标成 abstractmethod，即使这些方法
    # 对当前页面并非必需也会阻止整个源加载。影视壳按能力调用方法，因此
    # 在实例化阶段解除抽象标记，由基类默认实现或页面级兼容逻辑兜底。
    abstract_methods = getattr(spider_type, "__abstractmethods__", None)
    if abstract_methods:
        try:
            spider_type.__abstractmethods__ = frozenset()
        except (AttributeError, TypeError):
            pass
    return _ensure_spider_defaults(spider_type())


class _FunctionalSpiderAdapter:
    """把无 Spider 类的函数式 PY 源适配成 Spider 兼容对象。

    影视壳常见写法（模块顶层直接定义接口函数）：
        def homeContent(filter=False): ...
        def categoryContent(tid, pg=1, filter=False, extend=None): ...
    适配器把函数透传为同名实例方法，并补上 BaseSpider 的默认属性
    （_HikerProxyUrl 等），让 call_compatible / localProxy 链路正常工作。
    """

    def __init__(self, module):
        object.__setattr__(self, "_module", module)
        self._env = getattr(module, "ENV", None) or getattr(module, "_ENV", None) or ""
        self._debug = bool(getattr(module, "_debug", False))
        self.extend = ""
        self._HikerProxyUrl = ""

    def __setattr__(self, name, value):
        object.__setattr__(self, name, value)
        if name == "_HikerProxyUrl":
            module = getattr(self, "_module", None)
            if module is not None:
                try:
                    setattr(module, name, value)
                except (AttributeError, TypeError):
                    pass

    def __getattr__(self, name):
        func = getattr(self._module, name, None)
        if callable(func):
            return func
        raise AttributeError(name)


def _get_cached_signature(func):
    target = getattr(func, "__func__", func)
    is_bound = getattr(func, "__self__", None) is not None
    try:
        cached = _signature_cache.get(target)
    except TypeError:
        cached = None
    if cached is not None and is_bound in cached:
        return cached[is_bound]

    signature = inspect.signature(func)
    try:
        if cached is None:
            cached = {}
            _signature_cache[target] = cached
        cached[is_bound] = signature
    except TypeError:
        # Some Java/Chaquopy callable proxies cannot be weak-referenced. Their
        # signatures are uncommon and must not be retained after source reset.
        pass
    return signature


def clear_signature_cache():
    count = len(_signature_cache)
    _signature_cache.clear()
    return count


def unload_python_module(module_name, recursive=False):
    """Unload one content-addressed source module from the current process."""
    module_name = str(module_name or "").strip()
    if not module_name:
        return {"removed": 0, "modules": []}
    prefix = module_name + "."
    names = [
        name for name in list(sys.modules)
        if name == module_name or (recursive and name.startswith(prefix))
    ]
    for name in sorted(names, key=len, reverse=True):
        sys.modules.pop(name, None)
    if names:
        clear_signature_cache()
    return {"removed": len(names), "modules": sorted(names)}


def call_compatible(mo, func_names, candidates):
    checked = []
    for func_name in func_names:
        func = getattr(mo, func_name, None)
        if not func or not callable(func):
            continue
        checked.append(func_name)
        try:
            signature = _get_cached_signature(func)
        except (TypeError, ValueError):
            return func(*candidates[0])
        for args in candidates:
            try:
                signature.bind(*args)
            except TypeError:
                continue
            return func(*args)
    raise ValueError("No compatible function: " + ", ".join(checked or func_names))


def inspect_source_file(path):
    report = {
        "python": ".".join(str(item) for item in sys.version_info[:3]),
        "imports": [],
        "missing": [],
        "warnings": [],
        "syntaxError": "",
    }
    try:
        with open(path, "r", encoding="utf-8-sig") as source_file:
            source = source_file.read()
        tree = ast.parse(source, filename=path)
    except SyntaxError as error:
        report["syntaxError"] = "%s (line %s)" % (error.msg, error.lineno or 0)
        return report

    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            imports.add(node.module.split(".", 1)[0])
    report["imports"] = sorted(imports)

    for module_name in report["imports"]:
        try:
            available = module_name in sys.modules or importlib.util.find_spec(module_name) is not None
        except (ImportError, ModuleNotFoundError, ValueError):
            available = False
        if not available:
            report["missing"].append(module_name)

    if "com.whl.quickjs.wrapper" in source:
        report["warnings"].append("FONGMI_QUICKJS_BRIDGE")
    if "from t4" in source or "import t4" in source:
        report["warnings"].append("EXTERNAL_T4")
    return report

def call_global_function(func_name,*args, **kwargs):
    return call_function(builtins,func_name,*args, **kwargs)

def wrapper_jsfunc(jsFunc):
    def wrapper(*args):
        args = list(args)
        jscontext = JSContext.getCurrentContext()
        scope = jsFunc.getParentScope()
        for i, k in enumerate(args):
            args[i] = toJsObject(k, scope, jscontext)
        ret = jsFunc.call(jscontext, None, None, args)
        if(type(ret)==NativeJavaMap):
            return ret.unwrap()
        return ret;
    return wrapper


def sync_wrapper(func, param):
    if(inspect.iscoroutinefunction(func)):
        return asyncio.run(func(*param))
    else:
        return func(*param)
        
        

def toJsObject(data, scope, jscontext):
    data_type = type(data)
    if data_type == list or data_type==tuple or data_type==set:
        if(data_type==set or data_type==tuple):
            data = list(data)
        for i in range(len(data)):
            data[i]=toJsObject(data[i], scope, jscontext)
        return jscontext.newArray(scope, data)
    elif data_type == dict:
        jsObject = jscontext.newObject(scope)
        for key, value in data.items():
            jsObject.put(str(key), jsObject, toJsObject(value, scope, jscontext))
        return jsObject
    elif callable(data):
        return PyFunction(data, scope, jscontext)
    return data

def toNativeJsObject(data):
    data_type = type(data)
    if data_type == list or data_type==tuple or data_type==set:
        if(data_type==set or data_type==tuple):
            data = list(data)
        for i in range(len(data)):
            data[i]=toNativeJsObject(data[i])
        return NativeArray(data)
    elif data_type == dict:
        jsObject = NativeObject()
        for key, value in data.items():
            jsObject.put(str(key), jsObject, toNativeJsObject(value))
        return jsObject
    #elif callable(data):
    #    return PyFunction(data)
    return data

class PyFunction(dynamic_proxy(Function)):
    def __init__(self, pyFunc, scope, jscontext):
        super().__init__()
        self.pyFunc=pyFunc
        self.scope=scope
        self.jscontext=jscontext
    def call(self, context, scriptable, scriptable2, objArr):
        return toJsObject(self.pyFunc(*objArr), self.scope, self.jscontext)
    def construct(self, scriptable, objArr):
        pass
    def getParentScope(self):
        return self.scope
