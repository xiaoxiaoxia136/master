var gateRuleTitle = (typeof MY_RULE !== "undefined" && MY_RULE && MY_RULE.title) ? String(MY_RULE.title) : "PY影视壳";
var legacyCompat = $.require("hiker://files/data/" + gateRuleTitle + "/subpage/legacy_compat.js");
legacyCompat.install();

// PY影视壳运行期远程门禁。
// 海阔原生 ZIP 导入没有自定义导入前钩子；本模块在规则运行前锁定所有功能。
function resolveGateEndpoint() {
    var blocks = [
        "3GueVpWqv+UlQdeaz01vANdIANjMGyz/aQl7/RiARwdv",
        "e5ZcZXkxjm5+SRy7Kw==",
        "lDNUDZj8ux1siDwFgtTeIgEpXkWgXuu4LtXDUyrldeFQ",
        "rcX8Eqb7Xp17fslol7BP6IdoROjZjvzkjtPRnlUB6soj"
    ];
    var encoded = blocks[2] + blocks[3] + blocks[0] + blocks[1];
    var keySeed = [226,10,204,38,251,247,15,149,253,4,223,110,138,53,110,230,87,36,98,10,44,215,252,80,169,231,229,67,244,129,156,145];
    var ivSeed = [32,68,241,0,139,85,32,47,14,116,146,97,185,169,53,255];
    var key = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, keySeed.length);
    var iv = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, ivSeed.length);
    for (var keyIndex = 0; keyIndex < keySeed.length; keyIndex++) {
        var keyValue = keySeed[keyIndex] ^ ((keyIndex * 73 + 41) & 255);
        key[keyIndex] = keyValue > 127 ? keyValue - 256 : keyValue;
    }
    for (var ivIndex = 0; ivIndex < ivSeed.length; ivIndex++) {
        var ivValue = ivSeed[ivIndex] ^ ((ivIndex * 37 + 91) & 255);
        iv[ivIndex] = ivValue > 127 ? ivValue - 256 : ivValue;
    }
    var cipher = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
    cipher.init(javax.crypto.Cipher.DECRYPT_MODE,
        new javax.crypto.spec.SecretKeySpec(key, "AES"),
        new javax.crypto.spec.IvParameterSpec(iv));
    var plain = cipher.doFinal(android.util.Base64.decode(encoded, android.util.Base64.DEFAULT));
    return String(new java.lang.String(plain, "UTF-8"));
}
var GATE_ACCEPTED_VERSION_KEY = "py_shell_gate_accepted_version";
var GATE_LAST_CONFIG_KEY = "py_shell_gate_last_config";
var GATE_SESSION_VERSION_KEY = "py_shell_gate_session_version";
var GATE_SESSION_AT_KEY = "py_shell_gate_session_at";
var GATE_LISTENER_KEY = "py_shell_gate_listener";
var GATE_SESSION_TTL_MS = 5 * 60 * 1000;

function safeGetItem(key, fallback) {
    try { return String(getItem(key, fallback) || fallback || ""); } catch (ignoreGetItemError) { return String(fallback || ""); }
}

function safeSetItem(key, value) {
    try { setItem(key, String(value || "")); return true; } catch (ignoreSetItemError) { return false; }
}

function normalizeConfig(raw) {
    var config = raw;
    if (typeof config === "string") config = JSON.parse(config);
    if (!config || typeof config !== "object") throw new Error("远程配置不是 JSON 对象");
    var version = String(config.version || "").trim();
    var hash = String(config.password_sha256 || "").trim().toLowerCase();
    if (!version) throw new Error("远程配置缺少 version");
    if (!/^[0-9a-f]{64}$/.test(hash)) throw new Error("远程配置 password_sha256 无效");
    return {
        schema: Number(config.schema || 1),
        app: String(config.app || "PY影视壳"),
        enabled: config.enabled !== false,
        version: version,
        password_sha256: hash,
        message: String(config.message || "请输入访问密码"),
        updated_at: String(config.updated_at || "")
    };
}

function cachedConfig() {
    var raw = safeGetItem(GATE_LAST_CONFIG_KEY, "");
    if (!raw) return null;
    try { return normalizeConfig(raw); } catch (ignoreCachedConfigError) { return null; }
}

function fetchRemoteConfig() {
    var configUrl = resolveGateEndpoint();
    var separator = configUrl.indexOf("?") >= 0 ? "&" : "?";
    var bucket = Math.floor(Date.now() / 60000);
    var raw = request(configUrl + separator + "_=" + bucket, {
        timeout: 6000,
        headers: {
            "Accept": "application/json,text/plain,*/*",
            "Cache-Control": "no-cache"
        }
    });
    var config = normalizeConfig(String(raw || "").trim());
    safeSetItem(GATE_LAST_CONFIG_KEY, JSON.stringify(config));
    return config;
}

function sha256(value) {
    var digest = java.security.MessageDigest.getInstance("SHA-256");
    var bytes = new java.lang.String(String(value || "")).getBytes("UTF-8");
    var output = digest.digest(bytes);
    var hex = "";
    for (var index = 0; index < output.length; index++) {
        var item = Number(output[index]) & 255;
        hex += (item < 16 ? "0" : "") + item.toString(16);
    }
    return hex;
}

function accepted(config) {
    return !!config && config.enabled && safeGetItem(GATE_ACCEPTED_VERSION_KEY, "") === config.version;
}

function markSession(config) {
    putMyVar(GATE_SESSION_VERSION_KEY, config.version);
    putMyVar(GATE_SESSION_AT_KEY, String(Date.now()));
    try {
        if (getMyVar(GATE_LISTENER_KEY, "") !== "1") {
            putMyVar(GATE_LISTENER_KEY, "1");
            addListener("onClose", $.toString(function(versionKey, atKey, listenerKey) {
                putMyVar(versionKey, "");
                putMyVar(atKey, "");
                putMyVar(listenerKey, "");
            }, GATE_SESSION_VERSION_KEY, GATE_SESSION_AT_KEY, GATE_LISTENER_KEY));
        }
    } catch (ignoreGateListenerError) {}
}

function sessionAccepted(config) {
    if (!config || !accepted(config)) return false;
    var version = String(getMyVar(GATE_SESSION_VERSION_KEY, "") || "");
    var checkedAt = Number(getMyVar(GATE_SESSION_AT_KEY, "0") || 0);
    return version === config.version && checkedAt > 0 && Date.now() - checkedAt < GATE_SESSION_TTL_MS;
}

function lockedItems(config, reason) {
    var items = [];
    items.push({
        title: "访问验证",
        desc: reason || (config && config.message) || "请输入访问密码后继续",
        col_type: "text_center_1",
        url: "hiker://empty",
        extra: {lineVisible: false}
    });
    if (config && config.enabled) {
        items.push({
            title: "输入访问密码",
            desc: "验证远程版本 " + config.version,
            col_type: "text_center_1",
            url: $("", config.message || "请输入访问密码").input(function(configJson) {
                try {
                    return $.require("hiker://page/py_gate_v1843").submitPassword(configJson, input);
                } catch (error) {
                    return "toast://验证失败：" + (error && error.toString ? error.toString() : String(error));
                }
            }, JSON.stringify(config)),
            extra: {
                id: "py_gate_password",
                lineVisible: false,
                backgroundColor: "#80BFFF",
                textColor: "#FFFFFF"
            }
        });
    }
    items.push({
        title: "说明：\n密码为远程更新，不定期更换，制作不易，请勿分享。",
        desc: "",
        col_type: "rich_text",
        url: "hiker://empty",
        extra: {lineVisible: false}
    });
    return items;
}

function renderLocked(config, reason) {
    try { setPageTitle("PY影视壳 · 访问验证"); } catch (ignoreGateTitleError) {}
    setResult(lockedItems(config, reason));
    return false;
}

function authorize(checkRemote) {
    // 代理线程 require py_core 时，getItem/safeGetItem 可能不可用，
    // 直接放行；图片/播放代理请求已在主线程通过门禁。
    if (typeof MY_PARAMS !== "undefined") return true;
    var config = cachedConfig();
    // localhost 代理线程（52020 图片/播放代理）：只要存在已缓存的远程配置
    // 就认为主线程已完成密码验证（代理请求不泄露配置，且仅监听 localhost）。
    if (!checkRemote && config && accepted(config)) return true;
    if (!checkRemote) {
        if (accepted(config)) { markSession(config); return true; }
        return renderLocked(config, config ? "需要先验证访问密码" : "尚未取得远程配置，请返回首页联网验证");
    }

    if (sessionAccepted(config)) return true;
    try {
        config = fetchRemoteConfig();
        if (!config.enabled) return renderLocked(config, "远程门禁当前已停用");
        if (accepted(config)) { markSession(config); return true; }
        return renderLocked(config, config.message);
    } catch (remoteError) {
        config = cachedConfig();
        if (accepted(config)) { markSession(config); return true; }
        return renderLocked(config, "无法获取远程密码配置；新设备保持锁定");
    }
}

function submitPassword(configJson, password) {
    var config = normalizeConfig(configJson);
    if (!config.enabled) return "toast://远程门禁当前已停用";
    if (sha256(String(password || "")) !== config.password_sha256) {
        return "toast://访问密码错误";
    }
    safeSetItem(GATE_ACCEPTED_VERSION_KEY, config.version);
    safeSetItem(GATE_LAST_CONFIG_KEY, JSON.stringify(config));
    markSession(config);
    refreshPage(false);
    return "toast://验证成功";
}

$.exports = {
    authorize: authorize,
    submitPassword: submitPassword,
    sha256: sha256,
    normalizeConfig: normalizeConfig,
    configUrl: resolveGateEndpoint
};
