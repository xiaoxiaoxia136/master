function loadPopupCore(requiredMethods) {
    var corePath = "hiker://files/data/PY\u5f71\u89c6\u58f3/subpage/py_core.js";
    var pagePath = "hiker://page/py_core_v1843";
    var methods = Array.isArray(requiredMethods) ? requiredMethods : [];
    function ready(candidate) {
        if (!candidate) return false;
        for (var i = 0; i < methods.length; i++) {
            if (typeof candidate[methods[i]] !== "function") return false;
        }
        return true;
    }
    var loaded = null;
    try { loaded = $.require(pagePath); } catch (ignorePageRequireError) {}
    if (!ready(loaded)) {
        try { loaded = $.require(corePath, true); } catch (ignoreFileRequireError) {}
    }
    if (!ready(loaded)) {
        var previousExports = $.exports;
        try {
            $.exports = {};
            var code = "";
            try {
                if (typeof readFile === "function") code = String(readFile(corePath) || "");
            } catch (ignoreReadError) {}
            if (!code) code = String(request(corePath) || "");
            if (!code) throw new Error("PY core module is empty");
            eval(code);
            loaded = $.exports;
        } finally {
            $.exports = previousExports;
        }
    }
    if (!ready(loaded)) {
        var missing = [];
        for (var j = 0; j < methods.length; j++) {
            if (!loaded || typeof loaded[methods[j]] !== "function") missing.push(methods[j]);
        }
        throw new Error("PY core module missing methods: " + missing.join(", "));
    }
    return loaded;
}

function loadPopupLibrary() {
    var libraryPath = "hiker://files/data/PY\u5f71\u89c6\u58f3/libs/hiker_pop_883.js";
    function ready(candidate) {
        return candidate && typeof candidate.setUseStartActivity === "function" &&
            typeof candidate.selectBottomRes === "function" &&
            typeof candidate.runOnNewThread === "function" &&
            typeof candidate.runOnUIThread === "function";
    }
    var loaded = null;
    try { loaded = $.require(libraryPath); } catch (ignorePopupLibraryRequireError) {}
    if (!ready(loaded)) {
        try { loaded = $.require(libraryPath, true); } catch (ignorePopupLibraryReloadError) {}
    }
    if (!ready(loaded)) {
        var previousExports = $.exports;
        try {
            $.exports = {};
            var code = "";
            try {
                if (typeof readFile === "function") code = String(readFile(libraryPath) || "");
            } catch (ignorePopupLibraryReadError) {}
            if (!code) code = String(request(libraryPath) || "");
            code = code.replace(/^\s*js:\s*/, "");
            if (!code) throw new Error("Popup library is empty");
            eval(code);
            loaded = $.exports;
        } finally {
            $.exports = previousExports;
        }
    }
    if (!ready(loaded)) throw new Error("Popup library is incomplete");
    return loaded;
}

var core = loadPopupCore([
    "getConfigIndex",
    "removeConfigLine",
    "activateConfigLine",
    "errorText"
]);
var hikerPop = loadPopupLibrary();

function openPySources() {
    try {
        var popup = $.require("hiker://files/data/" + MY_RULE.title + "/subpage/source_popup_v1843.js");
        var target = popup && typeof popup.show === "function" ? popup.show("py") : "";
        return target || "hiker://empty";
    } catch (ignorePopupError) {
        return "hiker://page/py_source_manager_v1843#noRecordHistory##noHistory#";
    }
}

function showLines() {
    hikerPop.setUseStartActivity(false);
    var index = core.getConfigIndex();
    var lines = Array.isArray(index.lines) ? index.lines : [];
    if (!lines.length) return "hiker://page/py_config_import_v1843#noRecordHistory##noHistory#";
    var popup = null;
    var options = lines.map(function(line) {
        return (String(line.id) === String(index.current) ? "➡️ " : "") + String(line.name || "配置线路");
    });
    popup = hikerPop.selectBottomRes({
        options: options,
        columns: 2,
        height: 0.62,
        title: "切换配置线路 当前共:" + lines.length + "条",
        longClick: function(value, position) {
            var line = lines[Number(position)];
            if (!line) return;
            var label = String(line.name || "配置线路");
            if (confirm("删除线路「" + label + "」？\n该线路关联的线路源也会一并删除。")) {
                try {
                    core.removeConfigLine(line.id);
                    toast("已删除线路：" + label);
                    try { popup.dismiss(); } catch (ignoreDismissError) {}
                    refreshPage(false);
                } catch (error) {
                    toast("删除失败：" + core.errorText(error));
                }
            }
        },
        menuClick: function() {
            try { popup.dismiss(); } catch (ignoreDismissError) {}
            return "hiker://page/py_config_import_v1843#noRecordHistory##noHistory#";
        },
        click: function(_, position) {
            var line = lines[Number(position)];
            if (!line) return;
            showLoading("正在加载配置线路...");
            hikerPop.runOnNewThread(function() {
                try {
                    var report = core.activateConfigLine(line.id);
                    hikerPop.runOnUIThread(function() {
                        try { hideLoading(); } catch (ignoreHideLoadingError) {}
                        refreshPage(true);
                        toast("线路已加载：导入" + Number(report.imported || 0) + "个源，跳过" + Number(report.skipped || 0) + "个");
                    });
                } catch (error) {
                    var message = core.errorText(error);
                    hikerPop.runOnUIThread(function() {
                        try { hideLoading(); } catch (ignoreHideLoadingError) {}
                        toast("线路加载失败：" + message);
                    });
                }
            });
        }
    });
    return "hiker://empty";
}

function show() {
    hikerPop.setUseStartActivity(false);
    var popup = null;
    popup = hikerPop.selectBottomRes({
        options: ["线路", "PY源"],
        columns: 2,
        height: 0.26,
        title: "选择切换类型",
        click: function(_, position) {
            try { popup.dismiss(); } catch (ignoreDismissError) {}
            if (Number(position) === 1) return openPySources();
            return showLines();
        }
    });
    return "hiker://empty";
}

$.exports = {show: show, showLines: showLines, openPySources: openPySources};
