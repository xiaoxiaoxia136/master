var RULE_TITLE = (typeof MY_RULE !== "undefined" && MY_RULE && MY_RULE.title) ? String(MY_RULE.title) : "PY影视壳";
var BUILD_VERSION = "2026081842";
var DATA_ROOT = "hiker://files/data/" + RULE_TITLE;
var DRPY_ENGINE_PATH = DATA_ROOT + "/runtime/drpy/drpy2.js";
var activeDrpyId = "";
var activeDrpy = null;

function textError(error) {
    if (!error) return "未知错误";
    return error.message ? String(error.message) : String(error);
}

function sourceKind(source) {
    var kind = String(source && (source.runtime || source.kind) || "").toLowerCase();
    if (kind) return kind;
    var path = String(source && source.path || "");
    var api = String(source && source.api || "");
    if (/\.py(?:$|[?#])/i.test(path) || /\.py(?:$|[?#])/i.test(api)) return "py";
    if (/\.js(?:$|[?#])/i.test(path) || /drpy/i.test(api)) return "drpy";
    return "py";
}

function isExternal(source) {
    return sourceKind(source) !== "py";
}

function appendQuery(url, params) {
    var parts = [];
    Object.keys(params || {}).forEach(function(key) {
        var value = params[key];
        if (value === undefined || value === null || String(value) === "") return;
        parts.push(encodeURIComponent(key) + "=" + encodeURIComponent(String(value)));
    });
    if (!parts.length) return String(url || "");
    return String(url || "") + (String(url || "").indexOf("?") >= 0 ? "&" : "?") + parts.join("&");
}

function requestText(url, options) {
    var text = request(String(url || ""), Object.assign({timeout: 12000}, options || {}));
    if (!text) throw new Error("接口没有返回内容");
    return String(text);
}

function xmlValue(block, tag, fallback) {
    var match = String(block || "").match(new RegExp("<" + tag + "[^>]*>([\\s\\S]*?)<\\/" + tag + ">", "i"));
    if (!match) return fallback || "";
    return String(match[1] || "").replace(/^\s*<!\[CDATA\[/, "").replace(/\]\]>\s*$/, "").trim();
}

function parseXml(text) {
    var result = {class: [], list: []};
    var classBlock = String(text || "").match(/<class[^>]*>([\s\S]*?)<\/class>/i);
    if (classBlock) {
        var classRegex = /<ty\s+[^>]*id=["']([^"']*)["'][^>]*>([\s\S]*?)<\/ty>/gi;
        var classMatch;
        while ((classMatch = classRegex.exec(classBlock[1])) !== null) {
            result.class.push({type_id: String(classMatch[1] || ""), type_name: String(classMatch[2] || "").replace(/<!\[CDATA\[/g, "").replace(/\]\]>/g, "").trim()});
        }
    }
    var videoRegex = /<video[^>]*>([\s\S]*?)<\/video>/gi;
    var videoMatch;
    while ((videoMatch = videoRegex.exec(String(text || ""))) !== null) {
        var block = videoMatch[1];
        var from = [];
        var plays = [];
        var ddRegex = /<dd\s+[^>]*flag=["']([^"']*)["'][^>]*>([\s\S]*?)<\/dd>/gi;
        var ddMatch;
        while ((ddMatch = ddRegex.exec(block)) !== null) {
            from.push(String(ddMatch[1] || ""));
            plays.push(String(ddMatch[2] || "").replace(/^\s*<!\[CDATA\[/, "").replace(/\]\]>\s*$/, "").trim());
        }
        result.list.push({
            vod_id: xmlValue(block, "id", ""),
            vod_name: xmlValue(block, "name", ""),
            vod_pic: xmlValue(block, "pic", ""),
            vod_remarks: xmlValue(block, "note", xmlValue(block, "last", "")),
            vod_actor: xmlValue(block, "actor", ""),
            vod_director: xmlValue(block, "director", ""),
            vod_content: xmlValue(block, "des", ""),
            vod_play_from: from.join("$$$"),
            vod_play_url: plays.join("$$$")
        });
    }
    return result;
}

function parsePayload(text) {
    var value = String(text || "").trim();
    if (!value) return {class: [], list: []};
    if (value[0] === "{" || value[0] === "[") {
        try { return JSON.parse(value); } catch (ignoreJsonError) {}
    }
    if (/<(?:rss|list|video|class)[\s>]/i.test(value)) return parseXml(value);
    throw new Error("接口返回的不是 JSON/XML 视频数据");
}

function resolvePic(pic, api) {
    var value = String(pic || "");
    if (!value || /^(?:https?:|data:|hiker:|file:|\/\/)/i.test(value)) return value;
    var host = String(api || "").match(/^https?:\/\/[^/]+/i);
    if (!host) return value;
    return host[0] + (value[0] === "/" ? value : "/" + value);
}

function normalizeCmsResult(payload, source) {
    var result = payload && typeof payload === "object" ? payload : {};
    if (result.data && typeof result.data === "object" && !Array.isArray(result.data)) {
        if (!result.list && Array.isArray(result.data.list)) result.list = result.data.list;
        if (!result.class && Array.isArray(result.data.class)) result.class = result.data.class;
    }
    if (!Array.isArray(result.list)) result.list = Array.isArray(result.data) ? result.data : [];
    if (!Array.isArray(result.class)) result.class = [];
    result.class = result.class.map(function(item) {
        item = item || {};
        return Object.assign({}, item, {
            type_id: String(item.type_id !== undefined ? item.type_id : (item.id !== undefined ? item.id : "")),
            type_name: String(item.type_name || item.name || item.title || item.type_id || item.id || "分类")
        });
    });
    result.list = result.list.map(function(item) {
        item = item || {};
        var copied = Object.assign({}, item);
        copied.vod_pic = resolvePic(copied.vod_pic || copied.pic || copied.cover || "", source.api);
        return copied;
    });
    return result;
}

function cmsCall(source, operation, args) {
    var api = String(source.api || source.path || "");
    if (!/^https?:\/\//i.test(api)) throw new Error("CMS 接口地址无效");
    var url;
    if (operation === "home") {
        url = appendQuery(api, {ac: "class"});
        var home = {class: [], list: []};
        try { home = normalizeCmsResult(parsePayload(requestText(url)), source); } catch (ignoreClassError) {}
        // Some XML CMS endpoints return a brief list for ac=class/ac=list that
        // contains titles and IDs but omits <pic>. Use videolist for the actual
        // home cards while preserving any category metadata from ac=class.
        try {
            var videos = normalizeCmsResult(parsePayload(requestText(appendQuery(api, {ac: "videolist", pg: 1}))), source);
            if (videos.list.length) home.list = videos.list;
            if (!home.class.length && videos.class.length) home.class = videos.class;
            Object.keys(videos).forEach(function(key) {
                if (key !== "class" && key !== "list" && home[key] === undefined) home[key] = videos[key];
            });
        } catch (ignoreHomeVideoError) {}
        if (!home.class.length && !home.list.length) home = normalizeCmsResult(parsePayload(requestText(appendQuery(api, {ac: "list"}))), source);
        return home;
    }
    if (operation === "homeVod") {
        url = appendQuery(api, {ac: "videolist", pg: args[0] || 1});
        return normalizeCmsResult(parsePayload(requestText(url)), source);
    }
    if (operation === "category") {
        url = appendQuery(api, {ac: "videolist", t: args[0], pg: args[1] || 1});
        return normalizeCmsResult(parsePayload(requestText(url)), source);
    }
    if (operation === "detail") {
        var detailId = Array.isArray(args[0]) ? args[0][0] : args[0];
        url = appendQuery(api, {ac: "detail", ids: detailId});
        return normalizeCmsResult(parsePayload(requestText(url)), source);
    }
    if (operation === "search") {
        url = appendQuery(api, {ac: "videolist", wd: args[0], pg: args[2] || args[1] || 1});
        return normalizeCmsResult(parsePayload(requestText(url)), source);
    }
    if (operation === "play") {
        var playId = String(args[1] || args[0] || "");
        return {parse: /\.(?:m3u8|mp4|flv|mkv|webm)(?:$|[?#])/i.test(playId) ? 0 : 1, url: playId};
    }
    if (operation === "imageHeaders") return {};
    throw new Error("CMS 源不支持 " + operation);
}

function t4Call(source, operation, args) {
    var api = String(source.api || source.path || "");
    var ext = source.ext === undefined ? "" : source.ext;
    var params = {extend: typeof ext === "string" ? ext : JSON.stringify(ext)};
    if (operation === "home") params.filter = "true";
    else if (operation === "homeVod") params.filter = "true";
    else if (operation === "category") Object.assign(params, {ac: "videolist", t: args[0], pg: args[1] || 1, ext: args[3] ? base64Encode(JSON.stringify(args[3])) : ""});
    else if (operation === "detail") Object.assign(params, {ac: "detail", ids: Array.isArray(args[0]) ? args[0][0] : args[0]});
    else if (operation === "search") Object.assign(params, {wd: args[0], pg: args[2] || 1});
    else if (operation === "play") Object.assign(params, {flag: args[0], play: args[1]});
    else if (operation === "imageHeaders") return {};
    else throw new Error("T4 源不支持 " + operation);
    return parsePayload(requestText(appendQuery(api, params), {headers: {"User-Agent": "okhttp/4.12.0"}}));
}

function ensureDrpy(source) {
    if (activeDrpy && activeDrpyId === String(source.id)) return activeDrpy;
    var module = $.require(DRPY_ENGINE_PATH);
    if (!module || typeof module.DRPY !== "function") throw new Error("Drpy2 引擎加载失败");
    var engine = module.DRPY();
    engine.init(String(source.path || source.ext || ""));
    var rule = engine.getRule ? engine.getRule() : {};
    if (!rule || !Object.keys(rule).length) throw new Error("JS 规则没有导出有效 rule");
    activeDrpy = engine;
    activeDrpyId = String(source.id);
    return engine;
}

function operationName(methods) {
    var names = Array.isArray(methods) ? methods : [methods];
    if (names.some(function(name) { return name === "homeContent" || name === "getHomeContent"; })) return "home";
    if (names.some(function(name) { return name === "homeVideoContent" || name === "getHomeVideoContent"; })) return "homeVod";
    if (names.indexOf("categoryContent") >= 0) return "category";
    if (names.indexOf("detailContent") >= 0) return "detail";
    if (names.indexOf("playerContent") >= 0) return "play";
    if (names.indexOf("searchContentPage") >= 0 || names.indexOf("searchContent") >= 0) return "search";
    if (names.indexOf("getImageHeaders") >= 0) return "imageHeaders";
    if (names.indexOf("localProxy") >= 0 || names.indexOf("proxy") >= 0) return "proxy";
    return String(names[0] || "");
}

function drpyCall(source, operation, args) {
    var engine = ensureDrpy(source);
    if (operation === "home") return engine.home(args[0] !== false);
    if (operation === "homeVod") return engine.homeVod({});
    if (operation === "category") return engine.category(String(args[0] || ""), String(args[1] || 1), args[2] !== false, args[3] || {});
    if (operation === "detail") return engine.detail(String(Array.isArray(args[0]) ? args[0][0] : args[0] || ""));
    if (operation === "play") return engine.play(String(args[0] || ""), String(args[1] || ""), []);
    if (operation === "search") return engine.search(String(args[0] || ""), !!args[1], String(args[2] || 1));
    if (operation === "proxy") return engine.proxy(args[0] || {});
    if (operation === "imageHeaders") return {};
    throw new Error("Drpy 源不支持 " + operation);
}

function callCompatible(source, methods, candidates) {
    var operation = operationName(methods);
    var args = Array.isArray(candidates) && candidates.length ? candidates[0] : [];
    var kind = sourceKind(source);
    if (kind === "drpy" || kind === "js") return drpyCall(source, operation, args);
    if (kind === "cms") return cmsCall(source, operation, args);
    if (kind === "t4") return t4Call(source, operation, args);
    throw new Error("未知外部源类型: " + kind);
}

function prepare(source) {
    if (sourceKind(source) === "drpy" || sourceKind(source) === "js") ensureDrpy(source);
    return {sourceId: source.id, sourceName: source.name || source.id, runtime: sourceKind(source)};
}

function inspect(source) {
    var name = String(source.name || source.fileName || source.id || "视频源");
    if (sourceKind(source) === "drpy" || sourceKind(source) === "js") {
        var engine = ensureDrpy(source);
        var rule = engine.getRule ? engine.getRule() : {};
        name = String(rule.title || rule.name || name);
    }
    return {name: name, report: {runtime: sourceKind(source), warnings: [], imports: [], missing: []}};
}

function clear(sourceId) {
    if (!sourceId || activeDrpyId === String(sourceId)) {
        activeDrpy = null;
        activeDrpyId = "";
    }
}

$.exports = {
    BUILD_VERSION: BUILD_VERSION,
    sourceKind: sourceKind,
    isExternal: isExternal,
    prepare: prepare,
    inspect: inspect,
    callCompatible: callCompatible,
    clear: clear,
    errorText: textError
};
