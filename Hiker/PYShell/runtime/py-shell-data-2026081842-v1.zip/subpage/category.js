var core = $.require("hiker://page/py_core_v1842");
var items = [];
var sourceId = String(MY_PARAMS.sourceId || "");
var tid = String(MY_PARAMS.tid || "");
var pageName = String(MY_PARAMS.name || "分类");
var stateKey = "py_filter@" + sourceId + "@" + tid;
var baseExtend = MY_PARAMS.extend || {};
var savedExtend = {};
var currentPage = Number(typeof MY_PAGE === "undefined" ? 1 : (MY_PAGE || 1));

function notifyNextPage(message) {
    if (currentPage <= 1 || typeof toast !== "function") return;
    try { toast(message); } catch (ignorePageToastError) {}
}

function cleanLabel(value, fallback) {
    var text = value === undefined || value === null ? "" : String(value);
    text = text
        .replace(/\\u([0-9a-fA-F]{4})/g, function(_, hex) { return String.fromCharCode(parseInt(hex, 16)); })
        .replace(/\\x([0-9a-fA-F]{2})/g, function(_, hex) { return String.fromCharCode(parseInt(hex, 16)); })
        .replace(/<br\s*\/?>/gi, " ")
        .replace(/<[^>]+>/g, " ")
        .replace(/\s+/g, " ")
        .trim();
    return text || fallback || "";
}

try { savedExtend = JSON.parse(getMyVar(stateKey, "{}")); } catch (ignoreStateError) {}
var extend = Object.assign({}, baseExtend, savedExtend);

function pushFilters(filters) {
    var groups = filters && filters[tid];
    if (!Array.isArray(groups)) return;
    groups.forEach(function(group) {
        var key = String(group.key || "");
        var values = Array.isArray(group.value) ? group.value : [];
        if (!key || !values.length) return;
        items.push({title: String(group.name || key), col_type: "rich_text"});
        values.forEach(function(option) {
            var value = String(option.v === undefined ? "" : option.v);
            var selected = String(extend[key] === undefined ? "" : extend[key]) === value;
            items.push({
                title: String(option.n || value || "全部"),
                col_type: "scroll_button",
                url: $("#noLoading#").lazyRule(function(filterStateKey, filterKey, filterValue) {
                    var current = {};
                    try { current = JSON.parse(getMyVar(filterStateKey, "{}")); } catch (ignoreParseError) {}
                    current[filterKey] = filterValue;
                    putMyVar(filterStateKey, JSON.stringify(current));
                    refreshPage(false);
                    return "hiker://empty";
                }, stateKey, key, value),
                extra: selected ? {backgroundColor: "#168C72", textColor: "#FFFFFF"} : {}
            });
        });
    });
}

function routeFor(vod) {
    var folder = String(vod.vod_tag || "").toLowerCase() === "folder";
    return folder ? {
        url: "hiker://page/py_category_v1842?page=fypage##fypage",
        extra: {
            sourceId: sourceId,
            tid: String(vod.vod_id || ""),
            name: cleanLabel(vod.vod_name, "分类"),
            extend: {},
            filters: {},
            lineVisible: false
        }
    } : {
        url: "hiker://page/py_detail_v1842",
        extra: {
            sourceId: sourceId,
            vodId: String(vod.vod_id || ""),
            name: cleanLabel(vod.vod_name, "详情"),
            pic: String(vod.vod_pic || ""),
            lineVisible: false
        }
    };
}

try {
    setPageTitle(pageName);
    notifyNextPage("正在加载下一页");
    if (currentPage === 1) pushFilters(MY_PARAMS.filters || {});
    var result = core.categorySource(sourceId, tid, String(currentPage), true, extend) || {};
    var list = Array.isArray(result.list) ? result.list : [];
    var pageCount = Number(result.pagecount || result.pageCount || 0);
    if (pageCount > 0 && currentPage > pageCount) list = [];
    if (currentPage > 1 && !list.length) notifyNextPage("到底了");
    list.forEach(function(vod) {
        var route = routeFor(vod || {});
        var pic = core.imageUrl(sourceId, vod.vod_pic, vod.vod_id);
        items.push({
            title: cleanLabel(vod.vod_name, "未命名"),
            desc: cleanLabel(vod.vod_remarks || vod.vod_year, ""),
            pic_url: pic,
            img: pic,
            col_type: "movie_2",
            url: route.url,
            extra: Object.assign({}, route.extra, {img: pic})
        });
    });
    if (!list.length && currentPage === 1) {
        items.push({title: "本页没有内容", col_type: "text_center_1", url: "hiker://empty"});
    }
} catch (error) {
    items.push({
        title: "分类加载失败",
        desc: core.errorText(error),
        col_type: "text_center_1",
        url: "hiker://empty"
    });
}

setResult(items);
