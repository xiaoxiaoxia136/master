// 首页视频源入口：仅用于切换选中的视频源。
// 批量管理（去重/禁用/删除/检测/统计）已移至 设置 → 源管理。
var core = $.require("hiker://page/py_core_v1842");
var items = [];
var searchStateKey = "py_source_switch_search";
var callbackCoreLoader = core.callbackCoreLoaderSource();

// flex_button 按文字自适应宽度。使用海阔当前 Activity 的 TextView Paint
// 测量实际主题字体，补齐到统一像素宽度；英文/数字保持正常半角。
// 仅改变标签显示，不修改原始 source.name、搜索或源 ID。
var pillTextPaint = null;
try {
    if (typeof getCurrentActivity === "function" && typeof android !== "undefined") {
        var pillSampleTextView = new android.widget.TextView(getCurrentActivity());
        pillSampleTextView.setTextSize(16);
        pillTextPaint = pillSampleTextView.getPaint();
    }
} catch (ignorePillPaintError) {}

function compactPillTitle(value) {
    var text = String(value || "视频源")
        .replace(/[\uFE0E\uFE0F]/g, "")
        .replace(/\s+/g, " ")
        .trim();
    if (!pillTextPaint) return text.length > 8 ? text.slice(0, 7) + "…" : text;
    try {
        var targetWidth = Number(pillTextPaint.measureText("测测测测测"));
        var visible = "";
        for (var index = 0; index < text.length;) {
            var code = text.charCodeAt(index);
            var step = code >= 0xD800 && code <= 0xDBFF && index + 1 < text.length ? 2 : 1;
            var part = text.slice(index, index + step);
            if (Number(pillTextPaint.measureText(visible + part + "…")) > targetWidth) {
                visible += "…";
                break;
            }
            visible += part;
            index += step;
        }
        function paddingFor(width) {
            var thin = " ";
            var hair = " ";
            var thinWidth = Number(pillTextPaint.measureText(thin)) || 1;
            var hairWidth = Number(pillTextPaint.measureText(hair)) || thinWidth;
            var thinCount = Math.max(0, Math.floor(width / thinWidth));
            var remain = Math.max(0, width - thinCount * thinWidth);
            var hairCount = Math.max(0, Math.round(remain / hairWidth));
            return new Array(thinCount + 1).join(thin) + new Array(hairCount + 1).join(hair);
        }
        var missing = Math.max(0, targetWidth - Number(pillTextPaint.measureText(visible)));
        return paddingFor(missing / 2) + visible + paddingFor(missing - missing / 2);
    } catch (ignorePillMeasureError) {
        return text.length > 8 ? text.slice(0, 7) + "…" : text;
    }
}

setPageTitle("切换视频源");

try {
    addListener("onClose", $.toString(function(key) { putMyVar(key, ""); }, searchStateKey));
} catch (ignoreSearchCloseError) {}

try {
    var index = core.getIndex();
    // 只显示启用的源；禁用源在源管理中管理
    var enabledSources = (Array.isArray(index.sources) ? index.sources : []).filter(function(source) {
        return core.isSourceEnabled(source);
    });
    var searchText = String(getMyVar(searchStateKey, "") || "").trim().toLowerCase();
    var sources = enabledSources.filter(function(source) {
        if (!searchText) return true;
        return [source.name, source.fileName, source.path].some(function(value) {
            return String(value || "").toLowerCase().indexOf(searchText) >= 0;
        });
    });
    var currentId = index.current;

    // 首行搜索框：按源名称、文件名和路径过滤三列标签。
    items.push({
        title: "🔍",
        desc: "搜索视频源...",
        col_type: "input",
        url: $.toString(function(key) {
            putMyVar(key, input);
            refreshPage(false);
        }, searchStateKey),
        extra: {
            defaultValue: String(getMyVar(searchStateKey, "") || ""),
            titleVisible: true,
            onChange: $.toString(function(key) {
                if (!input) putMyVar(key, "");
            }, searchStateKey),
            lineVisible: false
        }
    });

    if (!sources.length) {
        items.push({
            title: searchText
                ? "没有匹配的视频源"
                : (index.sources.length ? "全部视频源已被禁用，请到设置中启用" : "暂无视频源，请到设置中导入"),
            col_type: "text_center_1",
            url: "hiker://page/py_settings_v1842#noRecordHistory##noHistory#"
        });
    } else {
        sources.forEach(function(source) {
            var isCurrent = String(source.id) === String(currentId);
            items.push({
                title: compactPillTitle(source.name),
                col_type: "flex_button",
                url: $("hiker://empty").lazyRule(function(sourceId, loaderSource) {
                    try {
                        var module = eval(loaderSource)(["setCurrentSource", "getSource"]);
                        module.setCurrentSource(sourceId);
                        var sourceName = module.getSource(sourceId).name;
                        back(true);
                        return "toast://已切换: " + sourceName;
                    } catch (error) {
                        return "toast://" + (error && error.toString ? error.toString() : String(error));
                    }
                }, source.id, callbackCoreLoader),
                extra: isCurrent
                    ? {
                        backgroundColor: "#80BFFF",
                        textColor: "#FFFFFF",
                        lineVisible: false,
                        id: "py_source_row_" + source.id
                    }
                    : {
                        lineVisible: false,
                        id: "py_source_row_" + source.id
                    }
            });
        });
    }

    items.push({
        title: "管理视频源（去重/禁用/检测/统计）",
        desc: "前往源管理",
        col_type: "text_1",
        url: "hiker://page/py_source_manager_v1842#noRecordHistory##noHistory#",
        extra: {lineVisible: false}
    });
} catch (error) {
    items.push({title: "源切换加载失败", desc: core.errorText(error), col_type: "text_center_1", url: "hiker://empty"});
}

setResult(items);
