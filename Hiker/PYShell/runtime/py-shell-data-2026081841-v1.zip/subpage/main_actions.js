var ACTIONS_VERSION = "2026081841";
var boundCore = null;
var HOME_FILTERS_ENABLED_KEY = "py_home_filters_enabled";

function homeFiltersEnabled() {
    try { return String(getItem(HOME_FILTERS_ENABLED_KEY, "1")) !== "0"; } catch (ignoreHomeFiltersSettingError) {}
    try { return String(getMyVar(HOME_FILTERS_ENABLED_KEY, "1")) !== "0"; } catch (ignoreHomeFiltersSessionSettingError) {}
    return true;
}

function coreReady(candidate, methods) {
    if (!candidate) return false;
    for (var index = 0; index < methods.length; index++) {
        if (typeof candidate[methods[index]] !== "function") return false;
    }
    return true;
}

function bindCore(core) {
    boundCore = core || null;
    return boundCore;
}

function resolveCore(loaderSource, methods) {
    var required = Array.isArray(methods) ? methods : [];
    if (coreReady(boundCore, required)) return boundCore;
    var loaded = eval(loaderSource)(required);
    if (!coreReady(loaded, required)) throw new Error("PY 核心模块加载不完整");
    boundCore = loaded;
    return loaded;
}

function errorMessage(error) {
    if (error && typeof error.toString === "function") return error.toString();
    return String(error || "未知错误");
}

function primaryCallback(actionPath, actionVersion, key, value, sourceId, requestKey, label, currentButtonId, listCls, footerId, subCls, loaderSource) {
    try {
        var actions = null;
        try { actions = $.require(actionPath); } catch (ignoreCachedActionError) {}
        if (!actions || String(actions.VERSION || "") !== String(actionVersion || "") || typeof actions.switchPrimary !== "function") {
            actions = $.require(actionPath, true);
        }
        if (!actions || String(actions.VERSION || "") !== String(actionVersion || "") || typeof actions.switchPrimary !== "function") {
            throw new Error("首页动作模块加载不完整: switchPrimary");
        }
        return actions.switchPrimary(
            actionPath, actionVersion, key, value, sourceId, requestKey, label,
            currentButtonId, listCls, footerId, subCls, loaderSource
        );
    } catch (error) {
        return "toast://分类切换失败: " + (error && error.toString ? error.toString() : String(error));
    }
}

function subCallback(actionPath, actionVersion, key, tid, value, sourceId, requestKey, label, currentButtonId, listCls, footerId, filterKey, subCls, loaderSource) {
    try {
        var actions = null;
        try { actions = $.require(actionPath); } catch (ignoreCachedActionError) {}
        if (!actions || String(actions.VERSION || "") !== String(actionVersion || "") || typeof actions.switchSub !== "function") {
            actions = $.require(actionPath, true);
        }
        if (!actions || String(actions.VERSION || "") !== String(actionVersion || "") || typeof actions.switchSub !== "function") {
            throw new Error("首页动作模块加载不完整: switchSub");
        }
        return actions.switchSub(
            key, tid, value, sourceId, requestKey, label, currentButtonId,
            listCls, footerId, filterKey, loaderSource
        );
    } catch (error) {
        return "toast://切换失败: " + (error && error.toString ? error.toString() : String(error));
    }
}

function buildCards(core, sourceId, list, listCls) {
    var normalized = core.normalizeVodList(list || []);
    var cards = [];
    for (var index = 0; index < normalized.length; index++) {
        var vod = normalized[index] || {};
        var pic = core.listImageUrl(sourceId, vod.vod_pic, vod.vod_id);
        var folder = String(vod.vod_tag || "").toLowerCase() === "folder";
        cards.push({
            title: String(vod.vod_name || "未命名"),
            desc: String(vod.vod_remarks || vod.vod_year || ""),
            pic_url: pic,
            img: pic,
            col_type: "movie_2",
            url: folder ? "hiker://page/py_category_v1841?page=fypage##fypage" : "hiker://page/py_detail_v1841",
            extra: {
                id: "PY影视壳.home.vod." + md5(String(vod.vod_id || "") + "@" + String(vod.vod_name || "")),
                cls: listCls,
                sourceId: sourceId,
                tid: folder ? String(vod.vod_id || "") : undefined,
                vodId: folder ? undefined : String(vod.vod_id || ""),
                name: String(vod.vod_name || (folder ? "分类" : "详情")),
                pic: String(vod.vod_pic || ""),
                img: pic,
                extend: folder ? {} : undefined,
                lineVisible: false
            }
        });
    }
    return cards;
}

function normalizeOptions(primary) {
    var sourceOptions = primary && Array.isArray(primary.value) ? primary.value : [];
    var options = [];
    for (var index = 0; index < sourceOptions.length; index++) {
        var option = sourceOptions[index];
        if (option === null || typeof option !== "object") continue;
        options.push({
            n: String(option.n || option.name || (index === 0 ? "全部" : "分类")),
            v: String(option.v || option.value || "")
        });
    }
    return options;
}

function filterStateKey(sourceId, tid) {
    return "py_home_filters_" + String(sourceId || "") + "_" + String(tid || "");
}

function readFilterState(stateKey) {
    try {
        var parsed = JSON.parse(String(getMyVar(stateKey, "{}") || "{}"));
        return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
    } catch (ignoreFilterStateError) {
        return {};
    }
}

function normalizeFilterState(definitions, state) {
    var normalized = {};
    var groups = Array.isArray(definitions) ? definitions : [];
    state = state && typeof state === "object" ? state : {};
    for (var groupIndex = 0; groupIndex < groups.length; groupIndex++) {
        var group = groups[groupIndex] || {};
        var key = String(group.key || "");
        var options = normalizeOptions(group);
        if (!key || !options.length) continue;
        var selected = state[key] === undefined ? "" : String(state[key]);
        var valid = false;
        for (var optionIndex = 0; optionIndex < options.length; optionIndex++) {
            if (options[optionIndex].v === selected) {
                valid = true;
                break;
            }
        }
        if (!valid) selected = options[0].v;
        if (selected) normalized[key] = selected;
    }
    return normalized;
}

function getSelectedFilterExtend(core, sourceId, tid) {
    if (!homeFiltersEnabled()) return {};
    if (!core || typeof core.getHomeFilters !== "function" || !tid) return {};
    var filters = core.getHomeFilters(sourceId) || {};
    var definitions = filters[String(tid || "")];
    if (!Array.isArray(definitions) || !definitions.length) return {};
    var stateKey = filterStateKey(sourceId, tid);
    var normalized = normalizeFilterState(definitions, readFilterState(stateKey));
    try { putMyVar(stateKey, JSON.stringify(normalized)); } catch (ignoreFilterStateSaveError) {}
    return normalized;
}

function buildSubItemsFromPrimary(primary, sourceId, tid, listCls, footerId, subCls, loaderSource, actionPath, actionVersion) {
    var result = [];
    var options = normalizeOptions(primary);
    if (!options.length) return result;
    var filterKey = String(primary.key || "sub");
    var stateKey = filterStateKey(sourceId, tid);
    var state = readFilterState(stateKey);
    var selectedValue = state[filterKey] === undefined ? "" : String(state[filterKey]);
    var validValue = false;
    var index;
    for (index = 0; index < options.length; index++) {
        if (options[index].v === selectedValue) {
            validValue = true;
            break;
        }
    }
    if (!validValue) selectedValue = options[0].v;
    result.push({
        title: "",
        col_type: "line_blank",
        url: "hiker://empty",
        extra: {cls: subCls, lineVisible: false}
    });
    result.push({
        title: String(primary.name || primary.key || "分类").replace(/[：:]$/, "") + "：",
        col_type: "scroll_button",
        url: "hiker://empty",
        extra: {cls: subCls, backgroundColor: "#F0F4F3", textColor: "#555555", lineVisible: false}
    });
    for (index = 0; index < options.length; index++) {
        var option = options[index];
        var buttonId = "PY影视壳.home.sub." + md5(String(tid) + "@" + filterKey + "@" + (option.v || "all"));
        var selected = option.v === selectedValue;
        result.push({
            title: option.n,
            col_type: "scroll_button",
            url: $("#noLoading#").lazyRule(
                subCallback,
                actionPath, actionVersion, stateKey, String(tid || ""), option.v, sourceId,
                stateKey + "_request", option.n, buttonId, listCls, footerId, filterKey,
                subCls, loaderSource
            ),
            extra: selected
                ? {id: buttonId, cls: subCls, backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}
                : {id: buttonId, cls: subCls, lineVisible: false}
        });
    }
    return result;
}

function buildSubCategoryItems(core, sourceId, tid, listCls, footerId, subCls, loaderSource, actionPath, actionVersion) {
    try {
        if (!homeFiltersEnabled()) return [];
        if (!core || typeof core.getHomeFilters !== "function") return [];
        var filters = core.getHomeFilters(sourceId) || {};
        var definitions = filters[String(tid || "")];
        if (!Array.isArray(definitions) || !definitions.length) return [];
        var stateKey = filterStateKey(sourceId, tid);
        var normalizedState = normalizeFilterState(definitions, readFilterState(stateKey));
        try { putMyVar(stateKey, JSON.stringify(normalizedState)); } catch (ignoreFilterStateSaveError) {}
        var result = [];
        for (var index = 0; index < definitions.length; index++) {
            var groupItems = buildSubItemsFromPrimary(
                definitions[index], sourceId, tid, listCls, footerId, subCls,
                loaderSource, actionPath, actionVersion
            );
            for (var itemIndex = 0; itemIndex < groupItems.length; itemIndex++) result.push(groupItems[itemIndex]);
        }
        return result;
    } catch (ignoreBuildSubError) {
        return [];
    }
}

function buildCategoryItems(source, classes, selectedTid, listCls, footerId, subCls, loaderSource, actionPath, actionVersion) {
    var result = [];
    if (!source || !Array.isArray(classes) || !classes.length) return result;
    var sourceId = source.id;
    var stateKey = "py_home_category_" + String(sourceId || "");
    var homeButtonId = "PY影视壳.home.category." + md5("home");
    result.push({
        title: "精选",
        col_type: "scroll_button",
        url: $("#noLoading#").lazyRule(
            primaryCallback,
            actionPath, actionVersion, stateKey, "", sourceId, stateKey + "_request", "精选",
            homeButtonId, listCls, footerId, subCls, loaderSource
        ),
        extra: !selectedTid
            ? {id: homeButtonId, backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}
            : {id: homeButtonId, lineVisible: false}
    });
    for (var index = 0; index < classes.length; index++) {
        var category = classes[index] || {};
        var tid = String(category.type_id || "");
        var label = String(category.type_name || tid || "分类");
        var buttonId = "PY影视壳.home.category." + md5(tid || "home");
        var selected = tid === selectedTid;
        result.push({
            title: label,
            col_type: "scroll_button",
            url: $("#noLoading#").lazyRule(
                primaryCallback,
                actionPath, actionVersion, stateKey, tid, sourceId, stateKey + "_request", label,
                buttonId, listCls, footerId, subCls, loaderSource
            ),
            extra: selected
                ? {id: buttonId, backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}
                : {id: buttonId, lineVisible: false}
        });
    }
    return result;
}

function switchSub(key, tid, value, sourceId, requestKey, label, currentButtonId, listCls, footerId, filterKey, loaderSource) {
    var token = String(Date.now()) + "_" + Math.random();
    putMyVar(requestKey, token);
    var previousState = readFilterState(key);
    var previous = previousState[filterKey] === undefined ? "" : String(previousState[filterKey]);
    var nextState = {};
    Object.keys(previousState).forEach(function(stateKey) { nextState[stateKey] = previousState[stateKey]; });
    if (value) nextState[filterKey] = value;
    else delete nextState[filterKey];
    putMyVar(key, JSON.stringify(nextState));
    var oldButtonId = "PY影视壳.home.sub." + md5(String(tid) + "@" + filterKey + "@" + (previous || "all"));
    try {
        if (oldButtonId !== currentButtonId) updateItem(oldButtonId, {extra: {id: oldButtonId, lineVisible: false}});
        updateItem(currentButtonId, {extra: {id: currentButtonId, backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}});
        if (typeof showLoading === "function") showLoading("正在加载" + label + "...");
        if (String(getMyVar(requestKey, "")) !== token) return "hiker://empty";
        var core = resolveCore(loaderSource, ["cachedCategorySource", "normalizeVodList", "listImageUrl"]);
        var response = core.cachedCategorySource(sourceId, tid, "1", true, nextState) || {};
        if (String(getMyVar(requestKey, "")) !== token) return "hiker://empty";
        var cards = buildCards(core, sourceId, response.list || [], listCls);
        if (!cards.length) throw new Error("当前分类没有返回内容");
        deleteItemByCls(listCls);
        addItemBefore(footerId, cards);
        return "toast://已切换到" + label;
    } catch (error) {
        if (String(getMyVar(requestKey, "")) !== token) return "hiker://empty";
        try { putMyVar(key, JSON.stringify(previousState)); } catch (ignoreRollbackError) {}
        return "toast://切换失败: " + errorMessage(error);
    } finally {
        if (String(getMyVar(requestKey, "")) === token && typeof hideLoading === "function") hideLoading();
    }
}

function switchPrimary(actionPath, actionVersion, key, value, sourceId, requestKey, label, currentButtonId, listCls, footerId, subCls, loaderSource) {
    var token = String(Date.now()) + "_" + Math.random();
    putMyVar(requestKey, token);
    var previous = String(getMyVar(key, "") || "");
    var oldButtonId = "PY影视壳.home.category." + md5(previous || "home");
    putMyVar(key, value);
    try { deleteItemByCls(subCls); } catch (ignoreSubClearError) {}
    try {
        updateItem(oldButtonId, {extra: {id: oldButtonId, lineVisible: false}});
        updateItem(currentButtonId, {extra: {id: currentButtonId, backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}});
        if (typeof showLoading === "function") showLoading("正在加载" + label + "...");
        if (String(getMyVar(requestKey, "")) !== token) return "hiker://empty";
        var required = ["prefetchCategory", "cachedCategorySource", "normalizeVodList", "listImageUrl"];
        if (value) required.push("getHomeFilters");
        var core = resolveCore(loaderSource, required);
        var selectedExtend = value ? getSelectedFilterExtend(core, sourceId, value) : {};
        var response = value && Object.keys(selectedExtend).length
            ? core.cachedCategorySource(sourceId, value, "1", true, selectedExtend)
            : core.prefetchCategory(sourceId, value, requestKey, token);
        response = response || {};
        if (String(getMyVar(requestKey, "")) !== token) return "hiker://empty";
        var cards = buildCards(core, sourceId, response.list || [], listCls);
        if (!cards.length) throw new Error("当前分类没有返回内容");
        deleteItemByCls(listCls);
        if (value) {
            var subItems = buildSubCategoryItems(
                core, sourceId, value, listCls, footerId, subCls,
                loaderSource, actionPath, actionVersion
            );
            if (subItems.length) addItemBefore(footerId, subItems);
        }
        addItemBefore(footerId, cards);
        return "hiker://empty";
    } catch (error) {
        if (String(getMyVar(requestKey, "")) !== token) return "hiker://empty";
        try {
            putMyVar(key, previous);
            updateItem(currentButtonId, {extra: {id: currentButtonId, lineVisible: false}});
            updateItem(oldButtonId, {extra: {id: oldButtonId, backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}});
        } catch (ignoreRollbackError) {}
        return "toast://分类切换失败: " + errorMessage(error);
    } finally {
        if (String(getMyVar(requestKey, "")) === token && typeof hideLoading === "function") hideLoading();
    }
}

$.exports = {
    VERSION: ACTIONS_VERSION,
    bindCore: bindCore,
    buildCategoryItems: buildCategoryItems,
    buildSubCategoryItems: buildSubCategoryItems,
    getSelectedFilterExtend: getSelectedFilterExtend,
    switchPrimary: switchPrimary,
    switchSub: switchSub
};
