function loadReaderCore() {
    var corePath = "hiker://files/data/PY\u5f71\u89c6\u58f3/subpage/py_core.js";
    var pagePath = "hiker://page/py_core_v1841";
    var requiredMethods = ["resolveNovelContent", "getSource", "errorText"];
    function ready(candidate) {
        if (!candidate) return false;
        for (var index = 0; index < requiredMethods.length; index++) {
            if (typeof candidate[requiredMethods[index]] !== "function") return false;
        }
        return true;
    }
    var loaded = null;
    try { loaded = $.require(pagePath); } catch (ignorePageRequireError) {}
    if (!ready(loaded)) {
        try { loaded = $.require(corePath, true); } catch (ignoreFileRequireError) {}
    }
    if (!ready(loaded)) {
        var previousExports = $.exports;
        try {
            $.exports = {};
            var code = "";
            try { if (typeof readFile === "function") code = String(readFile(corePath) || ""); } catch (ignoreReadError) {}
            if (!code) code = String(request(corePath) || "");
            if (!code) throw new Error("PY 核心模块为空");
            eval(code);
            loaded = $.exports;
        } finally {
            $.exports = previousExports;
        }
    }
    if (!ready(loaded)) throw new Error("PY 阅读核心模块不完整");
    return loaded;
}

var core = loadReaderCore();
var items = [];
var sourceId = String(MY_PARAMS.sourceId || "");
var flag = String(MY_PARAMS.flag || "");
var chapterId = String(MY_PARAMS.chapterId || "");
var chapterTitle = String(MY_PARAMS.title || "小说正文");
var vodId = String(MY_PARAMS.vodId || MY_PARAMS.pid || "");
var detailName = String(MY_PARAMS.name || "");
var detailPic = String(MY_PARAMS.pic || "");

// extra 传参可能丢失（长 chapterId + 多字段），从固定 key MyVar 兜底读取
try {
    var metaCache = JSON.parse(getMyVar("py_reader_meta", "{}") || "{}") || {};
    if (!vodId) vodId = String(metaCache.vodId || "");
    if (!detailName) detailName = String(metaCache.name || "");
    if (!detailPic) detailPic = String(metaCache.pic || "");
} catch (ignoreMetaError) {}

var listKey = "py_chapters_" + md5(sourceId + "@" + vodId);
var stateKey = "py_reader_state_" + md5(sourceId + "@" + vodId);
var chapterList = [];
try {
    var storedList = String(getMyVar(listKey, "") || "");
    if (storedList) chapterList = JSON.parse(storedList) || [];
} catch (ignoreListError) {}

function value(value, fallback) {
    var text = value === undefined || value === null ? "" : String(value);
    return text || fallback || "";
}

function chapterTitleOf(id) {
    var raw = String(id || "");
    if (raw.indexOf("@@") > 0) {
        var parts = raw.split("@@");
        if (parts.length > 2 && parts[2]) return parts[2];
    }
    if (raw.indexOf("/") > 0 && raw.indexOf("://") > 0) {
        var last = raw.split("/").pop();
        if (last) return last;
    }
    return "";
}

// 解析当前应显示的章节：页面内切章（refreshPage）后 state.base 仍等于
// 初始进入章（MY_PARAMS.chapterId 不变），用 state.index 定位；
// 从详情页点其他章进入（新页面）时 state.base 不同，重置为新章。
function resolveCurrent() {
    var state = {};
    try { state = JSON.parse(getMyVar(stateKey, "{}") || "{}") || {}; } catch (ignoreStateError) {}
    if (state && String(state.base || "") === String(chapterId || "") && typeof state.index === "number" && state.index >= 0) {
        return {index: state.index, sameSession: true};
    }
    var found = -1;
    for (var index = 0; index < chapterList.length; index++) {
        if (String(chapterList[index] || "") === String(chapterId || "")) {
            found = index;
            break;
        }
    }
    if (found >= 0) {
        try { putMyVar(stateKey, JSON.stringify({base: chapterId, index: found})); } catch (ignoreStateWriteError) {}
    }
    return {index: found, sameSession: false};
}

function navRule(delta, currentIndex, maxIndex) {
    return $("hiker://empty").lazyRule(function(stateKey, delta, currentIndex, maxIndex) {
        var state = {};
        try { state = JSON.parse(getMyVar(stateKey, "{}") || "{}") || {}; } catch (ignoreStateError) {}
        var next = Math.max(0, Math.min(maxIndex, currentIndex + delta));
        state.index = next;
        try { putMyVar(stateKey, JSON.stringify(state)); } catch (ignoreStateWriteError) {}
        // refreshPage() 默认滚动到顶部（切章后回到新章开头）；
        // 不能用 refreshPage(false)（保持原滚动位置会停在末尾）
        refreshPage();
        return "hiker://empty";
    }, stateKey, delta, currentIndex, maxIndex);
}

function pushNavButtons(currentIndex) {
    var maxIndex = chapterList.length - 1;
    var navExtra = {
        sourceId: sourceId,
        vodId: vodId,
        name: detailName,
        pic: detailPic,
        lineVisible: false
    };
    // 三个大按钮一行并排：flex_button（背景色/圆角/文字完整；text_4 无背景色
    // 且裁剪，弃用）。等长文字（上一章/章目录/下一章）等宽；目录绿色突出。
    // 海阔无 space-between/居中，按钮组靠左（平台限制）
    var buttonStyle = {textSize: 28, lineVisible: false};
    var primaryStyle = {textSize: 28, backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false};
    if (currentIndex > 0) {
        items.push({
            title: "上一章",
            col_type: "flex_button",
            url: navRule(-1, currentIndex, maxIndex),
            extra: buttonStyle
        });
    } else {
        items.push({
            title: "已经是第一章",
            col_type: "flex_button",
            url: "hiker://empty",
            extra: buttonStyle
        });
    }
    items.push({
        title: "章目录",
        col_type: "flex_button",
        url: "hiker://page/py_detail_v1841",
        extra: primaryStyle
    });
    if (currentIndex < maxIndex) {
        items.push({
            title: "下一章",
            col_type: "flex_button",
            url: navRule(1, currentIndex, maxIndex),
            extra: buttonStyle
        });
    } else {
        items.push({
            title: "已经是最后一章",
            col_type: "flex_button",
            url: "hiker://empty",
            extra: buttonStyle
        });
    }
}

function pushReaderPage() {
    try {
        if (typeof showLoading === "function") showLoading("正在加载正文...");
        var current = resolveCurrent();
        var displayChapterId = current.index >= 0 ? String(chapterList[current.index] || chapterId) : chapterId;
        var result = core.resolveNovelContent(sourceId, flag, displayChapterId) || {};
        var content = value(result.content, "");
        var title = value(result.title, chapterTitleOf(displayChapterId) || chapterTitle);
        if (!content) {
            var error = value(result.error, "未知错误");
            items.push({
                title: "正文加载失败：" + error,
                col_type: "text_center_1",
                url: "hiker://empty",
                extra: {lineVisible: false}
            });
        } else {
            items.push({
                title: title,
                col_type: "text_2",
                url: "hiker://empty",
                extra: {lineVisible: false, textAlign: "center"}
            });
            // 正文用 long_text（参考一起草🌿阅读模式：支持字号/行距/背景设置
            // 与点击翻页），配合页面 #readTheme# 标记启用阅读模式
            items.push({
                title: content,
                col_type: "long_text",
                url: "hiker://empty",
                extra: {textSize: 18, lineVisible: false}
            });
        }
        if (current.index >= 0) pushNavButtons(current.index);
        try { setPageTitle(title); } catch (ignoreTitleError) {}
    } catch (error) {
        items.push({
            title: "阅读页加载失败：" + (error && error.toString ? error.toString() : String(error)),
            col_type: "text_center_1",
            url: "hiker://empty",
            extra: {lineVisible: false}
        });
    } finally {
        try { if (typeof hideLoading === "function") hideLoading(); } catch (ignoreHideLoadingError) {}
    }
    setResult(items);
}

try {
    if (!sourceId || !chapterId) {
        items.push({
            title: "缺少阅读参数（sourceId/chapterId）",
            col_type: "text_center_1",
            url: "hiker://empty",
            extra: {lineVisible: false}
        });
        setResult(items);
    } else {
        pushReaderPage();
    }
} catch (outerError) {
    try {
        items.push({
            title: "阅读页异常：" + (outerError && outerError.toString ? outerError.toString() : String(outerError)),
            col_type: "text_center_1",
            url: "hiker://empty",
            extra: {lineVisible: false}
        });
        setResult(items);
    } catch (ignoreFinalError) {}
}
