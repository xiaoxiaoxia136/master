function loadHistoryCore(requiredMethods) {
    var corePath = "hiker://files/data/PY\u5f71\u89c6\u58f3/subpage/py_core.js";
    var pagePath = "hiker://page/py_core_v1841";
    var methods = Array.isArray(requiredMethods) ? requiredMethods : [];
    function ready(candidate) {
        if (!candidate) return false;
        for (var i = 0; i < methods.length; i++) {
            if (typeof candidate[methods[i]] !== "function") return false;
        }
        return true;
    }
    var loaded = null;
    try { loaded = $.require(pagePath); } catch (ignorePageRequireError) {}
    if (!ready(loaded)) {
        try { loaded = $.require(corePath, true); } catch (ignoreFileRequireError) {}
    }
    if (!ready(loaded)) {
        var previousExports = $.exports;
        try {
            $.exports = {};
            var code = "";
            try {
                if (typeof readFile === "function") code = String(readFile(corePath) || "");
            } catch (ignoreReadError) {}
            if (!code) code = String(request(corePath) || "");
            if (!code) throw new Error("PY 核心模块为空");
            eval(code);
            loaded = $.exports;
        } finally {
            $.exports = previousExports;
        }
    }
    if (!ready(loaded)) throw new Error("PY 核心模块加载不完整");
    return loaded;
}

var core = loadHistoryCore([
    "listHistory",
    "listSources",
    "clearHistory",
    "removeHistory",
    "imageUrl",
    "callbackCoreLoaderSource",
    "errorText"
]);
var items = [];
var stateKey = "py_history_source_filter";
var callbackCoreLoader = core.callbackCoreLoaderSource();

function text(value, fallback) {
    var result = value === undefined || value === null ? "" : String(value);
    return result || fallback || "";
}

function formatTime(timestamp) {
    var date = new Date(Number(timestamp || 0));
    if (!Number(timestamp || 0) || isNaN(date.getTime())) return "";
    function pad(value) { return value < 10 ? "0" + value : String(value); }
    return date.getFullYear() + "-" + pad(date.getMonth() + 1) + "-" + pad(date.getDate()) +
        " " + pad(date.getHours()) + ":" + pad(date.getMinutes());
}

function pushFilter(title, sourceId, selected) {
    items.push({
        title: title,
        col_type: "scroll_button",
        url: $("#noLoading#").lazyRule(function(key, value) {
            putMyVar(key, value);
            refreshPage(false);
            return "hiker://empty";
        }, stateKey, sourceId),
        extra: selected
            ? {backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}
            : {lineVisible: false}
    });
}

function historyImage(record, sourceExists) {
    var raw = text(record && record.pic, "").trim();
    if (!raw) return "";
    if (sourceExists) return core.imageUrl(record.sourceId, raw, record.vodId);
    // 源已删除时不再调用源相关 header、解密或 localProxy。历史中仍是普通
    // 远程图/本地图时可继续显示；旧回环代理和 proxy:// 记录直接留空占位。
    if (/^(?:data:|hiker:\/\/|file:\/\/)/i.test(raw)) return raw;
    if (/^proxy:\/\//i.test(raw)) return "";
    if (/^https?:\/\/(?:127\.0\.0\.1|localhost|10\.0\.2\.15)(?::|\/)/i.test(raw)) return "";
    return /^https?:\/\//i.test(raw) ? raw : "";
}

try {
    setPageTitle("历史记录");
    var records = core.listHistory();
    var sources = core.listSources();
    var available = {};
    sources.forEach(function(source) { available[source.id] = true; });

    var sourceNames = {};
    records.forEach(function(record) {
        if (!sourceNames[record.sourceId]) sourceNames[record.sourceId] = text(record.sourceName, "视频源");
    });
    var sourceIds = Object.keys(sourceNames);
    var selectedSourceId = String(getMyVar(stateKey, "") || "");
    if (selectedSourceId && sourceIds.indexOf(selectedSourceId) < 0) {
        selectedSourceId = "";
        putMyVar(stateKey, "");
    }

    if (records.length) {
        pushFilter("全部", "", !selectedSourceId);
        sourceIds.forEach(function(sourceId) {
            pushFilter(sourceNames[sourceId], sourceId, selectedSourceId === sourceId);
        });
        items.push({
            title: "清空记录",
            col_type: "scroll_button",
            url: $("确认清空全部观看记录？").confirm(function(key, loaderSource) {
                try {
                    var loadCore = eval(loaderSource);
                    loadCore(["clearHistory"]).clearHistory();
                    putMyVar(key, "");
                    refreshPage(false);
                    return "toast://历史记录已清空";
                } catch (error) {
                    return "toast://清空记录失败：" + (error && error.toString ? error.toString() : String(error));
                }
            }, stateKey, callbackCoreLoader),
            extra: {backgroundColor: "#E9EEF2", textColor: "#C0392B", lineVisible: false}
        });
    }

    var visible = selectedSourceId
        ? records.filter(function(record) { return record.sourceId === selectedSourceId; })
        : records;

    visible.forEach(function(record) {
        var sourceName = text(record.sourceName, "视频源");
        var episodeName = text(record.episodeName, "已观看");
        var watchedAt = formatTime(record.updatedAt);
        var desc = "来源：" + sourceName + "\n最近：" + episodeName + (watchedAt ? "  ·  " + watchedAt : "");
        var exists = !!available[record.sourceId];
        var pic = historyImage(record, exists);
        items.push({
            title: text(record.title, "未命名"),
            desc: desc,
            pic_url: pic,
            img: pic,
            col_type: "movie_1_vertical_pic",
            url: exists ? "hiker://page/py_detail_v1841" : "toast://该视频源已移除，重新导入后可继续观看",
            extra: {
                sourceId: record.sourceId,
                vodId: record.vodId,
                name: text(record.title, "详情"),
                pic: text(record.pic, ""),
                img: pic,
                lineVisible: false,
                longClick: [{
                    title: "删除这条记录",
                    js: $.toString(function(key, loaderSource) {
                        try {
                            var loadCore = eval(loaderSource);
                            loadCore(["removeHistory"]).removeHistory(key);
                            refreshPage(false);
                            return "toast://已删除";
                        } catch (error) {
                            return "toast://删除失败：" + (error && error.toString ? error.toString() : String(error));
                        }
                    }, record.key, callbackCoreLoader)
                }]
            }
        });
    });

    if (!visible.length) {
        items.push({
            title: records.length ? "当前源还没有观看记录" : "还没有观看记录",
            desc: records.length ? "" : "打开任意视频源并点击选集后，会在这里记录最近观看位置",
            col_type: "text_center_1",
            url: "hiker://empty",
            extra: {lineVisible: false}
        });
    }
} catch (error) {
    items.push({
        title: "历史记录加载失败",
        desc: core.errorText(error),
        col_type: "text_center_1",
        url: "hiker://empty"
    });
}

setResult(items);
