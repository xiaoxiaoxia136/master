// 配置线路管理：参考源管理（聚影本地接口管理）的布局与批量操作方式。
// 功能：搜索、批量选择、删除所选、清空所有、切换当前线路。
var core = $.require("hiker://page/py_core_v1841");
var callbackCoreLoader = core.callbackCoreLoaderSource();
var items = [];

var modeKey = "py_lines_batch_mode";
var selectedKey = "py_lines_selected";
var searchKey = "py_lines_search";

function readArrayState(key) {
    try { return JSON.parse(String(getMyVar(key, "[]") || "[]")); } catch (ignoreArrayError) { return []; }
}

try {
    addListener("onClose", $.toString(function(keys) {
        keys.forEach(function(key) { putMyVar(key, ""); });
    }, [modeKey, selectedKey, searchKey]));
} catch (ignoreCloseListenerError) {}

setPageTitle("线路管理");

var index = core.getConfigIndex();
var lines = Array.isArray(index.lines) ? index.lines : [];
var batchMode = String(getMyVar(modeKey, "") || "") === "1";
var selectedIds = readArrayState(selectedKey);
var searchText = String(getMyVar(searchKey, "") || "").trim().toLowerCase();

var filtered = lines.filter(function(line) {
    if (!searchText) return true;
    return [line.name, line.url].some(function(value) {
        return String(value || "").toLowerCase().indexOf(searchText) >= 0;
    });
});
var visibleIds = filtered.map(function(line) { return String(line.id); });
var selectedMap = {};
selectedIds.forEach(function(id) { selectedMap[String(id)] = true; });
var allSelected = filtered.length > 0 && visibleIds.every(function(id) { return !!selectedMap[id]; });

// ---- 顶部工具栏 ----
items.push({
    title: "操作",
    pic_url: getPath(core.DATA_ROOT + "/assets/settings_v116.png"),
    col_type: "icon_2",
    url: $(["批量选择", "清空所有"], 2, "选择操作功能项").select(function(modeKey, selectedKey, loaderSource) {
        if (input === "批量选择") {
            var active = String(getMyVar(modeKey, "") || "") === "1";
            putMyVar(modeKey, active ? "" : "1");
            if (active) putMyVar(selectedKey, "[]");
            refreshPage(false);
            return "toast://" + (active ? "已退出批量选择" : "已进入批量选择");
        }
        if (input === "清空所有") {
            var module = eval(loaderSource)(["getConfigIndex"]);
            var ids = (module.getConfigIndex().lines || []).map(function(line) { return String(line.id); });
            if (!ids.length) return "toast://当前没有配置线路";
            return $("确定要删除全部 " + ids.length + " 条配置线路？\n同时删除这些线路导入的视频源").confirm(function(ids, selectedKey, modeKey, loaderSource) {
                var module = eval(loaderSource)(["removeConfigLine"]);
                var removed = 0;
                ids.forEach(function(id) {
                    try { module.removeConfigLine(id); removed++; } catch (ignoreRemoveError) {}
                });
                putMyVar(selectedKey, "[]");
                putMyVar(modeKey, "");
                refreshPage(false);
                return "toast://已清空全部 " + removed + " 条配置线路";
            }, ids, selectedKey, modeKey, loaderSource);
        }
        return "hiker://empty";
    }, modeKey, selectedKey, callbackCoreLoader),
    extra: {lineVisible: false}
});
items.push({
    title: "分享",
    pic_url: getPath(core.DATA_ROOT + "/assets/video_source_v116.png"),
    col_type: "icon_2",
    url: $(["分享当前线路", "分享全部线路"], 2, "选择分享范围").select(function(lines, currentId) {
        if (!lines.length) return "toast://当前没有配置线路";
        var targets = input === "分享当前线路"
            ? lines.filter(function(line) { return String(line.id) === String(currentId); })
            : lines;
        if (!targets.length) return "toast://当前线路不存在";
        try {
            var exported = {
                urls: targets.map(function(line) {
                    return {name: String(line.name || "配置线路"), url: String(line.url || "")};
                })
            };
            var sharePath = "hiker://files/_cache/PY影视壳_配置线路_" + Date.now() + ".json";
            writeFile(sharePath, JSON.stringify(exported, null, 2));
            return "share://" + sharePath;
        } catch (error) {
            return "toast://分享失败：" + (error && error.toString ? error.toString() : String(error));
        }
    }, lines, String(index.current || "")),
    extra: {lineVisible: false}
});
items.push({col_type: "line"});

// ---- 搜索框 ----
items.push({
    title: "🔍",
    desc: "搜索线路名称或地址...",
    col_type: "input",
    url: $.toString(function(key) {
        putMyVar(key, input);
        refreshPage(false);
    }, searchKey),
    extra: {
        defaultValue: String(getMyVar(searchKey, "") || ""),
        titleVisible: true,
        onChange: $.toString(function(key) {
            if (!input) putMyVar(key, "");
        }, searchKey),
        lineVisible: false
    }
});

// ---- 批量操作行 ----
if (batchMode) {
    items.push({
        title: allSelected ? "取消全选" : "全部选中",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(modeKey, selectedKey, ids) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            var selectedMap = {};
            selected.forEach(function(id) { selectedMap[String(id)] = true; });
            var allSelected = ids.length > 0 && ids.every(function(id) { return !!selectedMap[id]; });
            putMyVar(modeKey, "1");
            putMyVar(selectedKey, JSON.stringify(allSelected ? [] : ids));
            refreshPage(false);
            return allSelected ? "toast://已取消全选" : "toast://已全部选中";
        }, modeKey, selectedKey, visibleIds),
        extra: {
            backgroundColor: allSelected ? "#168C72" : "",
            textColor: allSelected ? "#FFFFFF" : "",
            longClick: [{
                title: "退出批量选择",
                js: $.toString(function(modeKey, selectedKey) {
                    putMyVar(modeKey, "");
                    putMyVar(selectedKey, "[]");
                    refreshPage(false);
                    return "toast://已退出批量选择";
                }, modeKey, selectedKey)
            }]
        }
    });
    items.push({
        title: "反向选择",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(modeKey, selectedKey, ids) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            var selectedMap = {};
            selected.forEach(function(id) { selectedMap[String(id)] = true; });
            putMyVar(modeKey, "1");
            putMyVar(selectedKey, JSON.stringify(ids.filter(function(id) { return !selectedMap[id]; })));
            refreshPage(false);
            return "toast://已反向选择";
        }, modeKey, selectedKey, visibleIds)
    });
    items.push({
        title: "删除所选",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(selectedKey, modeKey, namesById, loaderSource) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            selected = selected.map(String).filter(function(id) { return !!namesById[id]; });
            if (!selected.length) return "toast://请先在列表中选择要删除的配置线路";
            var preview = selected.slice(0, 4).map(function(id) { return namesById[id]; }).join("、");
            if (selected.length > 4) preview += " 等";
            return $("确认删除已选的 " + selected.length + " 条配置线路？\n" + preview).confirm(function(ids, selectedKey, modeKey, loaderSource) {
                try {
                    var module = eval(loaderSource)(["removeConfigLine"]);
                    var removed = 0;
                    ids.forEach(function(id) {
                        try { module.removeConfigLine(id); removed++; } catch (ignoreRemoveError) {}
                    });
                    putMyVar(selectedKey, "[]");
                    putMyVar(modeKey, "");
                    refreshPage(false);
                    return "toast://已删除 " + removed + " 条配置线路";
                } catch (error) {
                    return "toast://批量删除失败: " + (error && error.toString ? error.toString() : String(error));
                }
            }, selected, selectedKey, modeKey, loaderSource);
        }, selectedKey, modeKey, filtered.reduce(function(map, line) {
            map[line.id] = String(line.name || "配置线路");
            return map;
        }, {}), callbackCoreLoader)
    });
    items.push({
        title: "退出选择",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(modeKey, selectedKey) {
            putMyVar(modeKey, "");
            putMyVar(selectedKey, "[]");
            refreshPage(false);
            return "toast://已退出批量选择";
        }, modeKey, selectedKey),
        extra: {id: "py_lines_action_exit", lineVisible: false}
    });
    items.push({col_type: "line"});
}

// ---- 统计胶囊 ----
items.push({
    title: "当前 " + lines.length,
    col_type: "text_4",
    url: "hiker://empty#noLoading#",
    extra: {backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}
});
items.push({
    title: "选中 " + (batchMode ? Object.keys(selectedMap).length : 0),
    col_type: "text_4",
    url: "hiker://empty#noLoading#",
    extra: {lineVisible: false}
});
items.push({col_type: "line"});

// ---- 线路列表 ----
filtered.forEach(function(line) {
    var isCurrent = String(line.id) === String(index.current);
    var batchSelected = !!selectedMap[String(line.id)];
    var titlePrefix = batchMode
        ? (batchSelected ? "☑ " : "☐ ")
        : (isCurrent ? "➡️ " : "");
    var rowTitle = titlePrefix + String(line.name || "配置线路");
    var desc = String(line.url || "");
    if (batchMode && batchSelected) desc = "已选择 · " + desc;
    var lineMenu = [isCurrent ? "当前线路" : "设为当前线路", "置顶", "上移", "下移", "置底", "删除"];
    var lineActionUrl = batchMode
        ? $("hiker://empty").lazyRule(function(selectedKey, lineId) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            selected = selected.map(String);
            var position = selected.indexOf(lineId);
            if (position >= 0) selected.splice(position, 1);
            else selected.push(lineId);
            putMyVar(selectedKey, JSON.stringify(selected));
            refreshPage(false);
            return "hiker://empty";
        }, selectedKey, String(line.id))
        : $(lineMenu, 2, "选择线路操作").select(function(lineId, lineName, isCurrent, loaderSource) {
            var module = eval(loaderSource)(["moveConfigLine", "activateConfigLine"]);
            if (input === "当前线路") return "toast://当前正在使用：" + lineName;
            if (["置顶", "上移", "下移", "置底"].indexOf(input) >= 0) {
                try {
                    var moveModes = {"置顶": "top", "上移": "up", "下移": "down", "置底": "bottom"};
                    module.moveConfigLine(lineId, moveModes[input]);
                    refreshPage(false);
                    return "toast://已" + input + "：" + lineName;
                } catch (error) {
                    return "toast://排序失败：" + (error && error.toString ? error.toString() : String(error));
                }
            }
            if (input === "设为当前线路") {
                try {
                    if (typeof showLoading === "function") showLoading("正在加载配置线路...");
                    var report = module.activateConfigLine(lineId);
                    refreshPage(true);
                    return "toast://线路已加载：导入" + Number(report.imported || 0) + "个源";
                } catch (error) {
                    return "toast://线路加载失败：" + (error && error.toString ? error.toString() : String(error));
                } finally {
                    try { if (typeof hideLoading === "function") hideLoading(); } catch (ignoreHideLoadingError) {}
                }
            }
            if (input === "删除") {
                return $("确认删除线路「" + lineName + "」？\n同时删除该线路导入的视频源").confirm(function(lineId, lineName, selectedKey, loaderSource) {
                    try {
                        eval(loaderSource)(["removeConfigLine"]).removeConfigLine(lineId);
                        var selected = [];
                        try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
                        putMyVar(selectedKey, JSON.stringify(selected.filter(function(id) { return String(id) !== lineId; })));
                        refreshPage(false);
                        return "toast://已删除线路：" + lineName;
                    } catch (error) {
                        return "toast://删除失败：" + (error && error.toString ? error.toString() : String(error));
                    }
                }, String(lineId), lineName, selectedKey, loaderSource);
            }
            return "hiker://empty";
        }, String(line.id), String(line.name || "配置线路"), isCurrent, callbackCoreLoader);

    items.push({
        title: rowTitle,
        desc: desc,
        col_type: "text_1",
        url: lineActionUrl,
        extra: isCurrent && !batchMode ? {backgroundColor: "#E8F5F1", textColor: "#116B58", lineVisible: false} : {lineVisible: false}
    });
    items.push({col_type: "line"});
});

if (!filtered.length) {
    items.push({
        title: lines.length ? "没有匹配的配置线路" : "暂无配置线路，请到接口源管理导入配置",
        col_type: "text_center_1",
        url: lines.length ? "hiker://empty" : "hiker://page/py_interface_manager_v1841#noRecordHistory##noHistory#"
    });
}

setResult(items);
