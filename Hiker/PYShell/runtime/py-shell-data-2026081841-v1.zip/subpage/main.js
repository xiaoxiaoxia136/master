var CORE_PAGE = "hiker://page/py_core_v1841";
var CORE_FILE = "hiker://files/data/" + MY_RULE.title + "/subpage/py_core.js";
var ACTIONS_VERSION = "2026081841";
var ACTIONS_FILE = "hiker://files/data/" + MY_RULE.title + "/subpage/main_actions.js";
var HOME_LIST_CLS = "PY影视壳.home.list";
var HOME_SUB_CLS = "PY影视壳.home.sub";
var HOME_FOOTER_ID = "PY影视壳.home.footer";
var FALLBACK_START_LIMIT_MS = 15000;

function mainCoreReady(candidate) {
    if (!candidate || typeof candidate !== "object") return false;
    var required = [
        "callbackCoreLoaderSource", "getCurrentSource", "getHomeClasses", "cacheHomeClasses",
        "homeSource", "homeVideoSource", "categorySource", "normalizeVodList",
        "listImageUrl", "errorText", "clearCategoryPrefetch", "consumePrefetchedCategory"
    ];
    for (var index = 0; index < required.length; index++) {
        if (typeof candidate[required[index]] !== "function") return false;
    }
    return true;
}

function loadMainCore() {
    var candidate = null;
    try { candidate = $.require(CORE_PAGE); } catch (ignoreMainCorePageError) {}
    if (mainCoreReady(candidate)) return candidate;
    candidate = $.require(CORE_FILE, true);
    if (!mainCoreReady(candidate)) throw new Error("PY 核心模块加载不完整");
    return candidate;
}

function mainActionsReady(candidate) {
    return !!candidate && typeof candidate === "object"
        && String(candidate.VERSION || "") === ACTIONS_VERSION
        && typeof candidate.bindCore === "function"
        && typeof candidate.buildCategoryItems === "function"
        && typeof candidate.buildSubCategoryItems === "function"
        && typeof candidate.getSelectedFilterExtend === "function";
}

function loadMainActions() {
    var candidate = null;
    try { candidate = $.require(ACTIONS_FILE); } catch (ignoreMainActionsCacheError) {}
    if (mainActionsReady(candidate)) return candidate;
    candidate = $.require(ACTIONS_FILE, true);
    if (!mainActionsReady(candidate)) throw new Error("首页动作模块加载不完整");
    return candidate;
}

function bootstrapErrorText(error, candidateCore) {
    if (candidateCore && typeof candidateCore.errorText === "function") {
        try { return candidateCore.errorText(error); } catch (ignoreCoreErrorTextError) {}
    }
    if (error && typeof error.toString === "function") return error.toString();
    return String(error || "未知启动错误");
}

var core = null;
var mainActions = null;
var callbackCoreLoader = "";
var bootstrapError = null;
try {
    var legacyCompat = $.require("hiker://files/data/" + MY_RULE.title + "/subpage/legacy_compat.js");
    if (!legacyCompat || typeof legacyCompat.install !== "function") throw new Error("旧版兼容模块加载不完整");
    legacyCompat.install();
    core = loadMainCore();
    mainActions = loadMainActions();
    mainActions.bindCore(core);
    callbackCoreLoader = core.callbackCoreLoaderSource();
} catch (startupError) {
    bootstrapError = startupError;
}

var items = [];
var page = typeof MY_PAGE === "undefined" ? 1 : Number(MY_PAGE || 1);
var controlsAdded = false;
var loadStartedAt = Date.now();
var loadError = null;

function canStartFallback() {
    return Date.now() - loadStartedAt < FALLBACK_START_LIMIT_MS;
}

function notifyNextPage(message) {
    if (page <= 1 || typeof toast !== "function") return;
    try { toast(message); } catch (ignorePageToastError) {}
}

function currentUiMode() {
    var saved = "";
    try { saved = String(getItem("py_ui_mode", "") || ""); } catch (ignorePersistentModeError) {}
    if (!saved) saved = String(getMyVar("py_ui_mode", "shell") || "shell");
    return saved === "simple" ? "simple" : "shell";
}

function cleanLabel(value, fallback) {
    var text = value === undefined || value === null ? "" : String(value);
    text = text
        .replace(/\\u([0-9a-fA-F]{4})/g, function(_, hex) { return String.fromCharCode(parseInt(hex, 16)); })
        .replace(/\\x([0-9a-fA-F]{2})/g, function(_, hex) { return String.fromCharCode(parseInt(hex, 16)); })
        .replace(/<br\s*\/?>/gi, " ")
        .replace(/<[^>]+>/g, " ")
        .replace(/\s+/g, " ")
        .trim();
    return text || fallback || "";
}

function androidSdkInt() {
    try { return Number(android.os.Build.VERSION.SDK_INT || 0); } catch (ignoreAndroidSdkError) {}
    return 0;
}

function pushControls(source) {
    controlsAdded = true;
    var sdkInt = androidSdkInt();
    function compactSourceName(value) {
        var name = cleanLabel(value, "选择源");
        return name.length > 7 ? name.slice(0, 6) + "…" : name;
    }
    if (currentUiMode() === "simple") {
        items.push({
            title: compactSourceName(source ? source.name : "选择源"),
            pic_url: getPath(core.DATA_ROOT + "/assets/video_source_v116.png"),
            col_type: "icon_2",
            url: $("#noLoading#").lazyRule(function(popupPath, sdkInt) {
                if (Number(sdkInt || 0) > 0 && Number(sdkInt) < 26) {
                    return "hiker://page/py_source_manager_v1841#noRecordHistory##noHistory#";
                }
                try {
                    var popup = $.require(popupPath);
                    var target = popup && typeof popup.show === "function" ? popup.show("py") : "";
                    return target || "hiker://empty";
                } catch (ignorePopupError) {
                    return "hiker://page/py_source_manager_v1841#noRecordHistory##noHistory#";
                }
            }, "hiker://files/data/" + MY_RULE.title + "/subpage/source_popup_v1841.js", sdkInt),
            extra: {lineVisible: false}
        });
        items.push({title: "历史记录", pic_url: getPath(core.DATA_ROOT + "/assets/history_v116.png"), col_type: "icon_2", url: "hiker://page/py_history_v1841#noRecordHistory##noHistory#", extra: {lineVisible: false}});
        items.push({
            title: "重新载入",
            pic_url: getPath(core.DATA_ROOT + "/assets/reload_v116.png"),
            col_type: "icon_2",
            url: $("#noLoading#").lazyRule(function(loaderSource, sourceId) {
                var currentCore = eval(loaderSource)(["clearCategoryPrefetch"]);
                currentCore.clearCategoryPrefetch(sourceId);
                refreshPage(true);
                return "toast://已重新载入";
            }, callbackCoreLoader, source ? source.id : ""),
            extra: {lineVisible: false}
        });
        items.push({title: "设置", pic_url: getPath(core.DATA_ROOT + "/assets/settings_v116.png"), col_type: "icon_2", url: "hiker://page/py_settings_v1841#noRecordHistory##noHistory#", extra: {lineVisible: false}});
    } else {
        items.push({
            title: "线路",
            pic_url: getPath(core.DATA_ROOT + "/assets/reload_v116.png"),
            col_type: "icon_5",
            url: $("#noLoading#").lazyRule(function(popupPath, sdkInt) {
                if (Number(sdkInt || 0) > 0 && Number(sdkInt) < 26) {
                    return "hiker://page/py_config_lines_v1841#noRecordHistory##noHistory#";
                }
                try {
                    var popup = $.require(popupPath);
                    var target = popup && typeof popup.show === "function" ? popup.show() : "";
                    return target || "hiker://empty";
                } catch (ignorePopupError) {
                    return "hiker://page/py_config_lines_v1841#noRecordHistory##noHistory#";
                }
            }, "hiker://files/data/" + MY_RULE.title + "/subpage/config_popup_v1841.js", sdkInt),
            extra: {lineVisible: false}
        });
        items.push({
            title: compactSourceName(source ? source.name : "选择源"),
            pic_url: getPath(core.DATA_ROOT + "/assets/video_source_v116.png"),
            col_type: "icon_5",
            url: $("#noLoading#").lazyRule(function(popupPath, sdkInt) {
                if (Number(sdkInt || 0) > 0 && Number(sdkInt) < 26) {
                    return "hiker://page/py_source_manager_v1841#noRecordHistory##noHistory#";
                }
                try {
                    var popup = $.require(popupPath);
                    var target = popup && typeof popup.show === "function" ? popup.show("active") : "";
                    return target || "hiker://empty";
                } catch (ignorePopupError) {
                    return "hiker://page/py_source_manager_v1841#noRecordHistory##noHistory#";
                }
            }, "hiker://files/data/" + MY_RULE.title + "/subpage/source_popup_v1841.js", sdkInt),
            extra: {lineVisible: false}
        });
        items.push({title: "历史", pic_url: getPath(core.DATA_ROOT + "/assets/history_v116.png"), col_type: "icon_5", url: "hiker://page/py_history_v1841#noRecordHistory##noHistory#", extra: {lineVisible: false}});
        items.push({title: "直播", pic_url: getPath(core.DATA_ROOT + "/assets/video_source_v116.png"), col_type: "icon_5", url: "hiker://page/py_live_v1841?page=fypage##fypage#noRecordHistory##noHistory#", extra: {lineVisible: false}});
        items.push({title: "设置", pic_url: getPath(core.DATA_ROOT + "/assets/settings_v116.png"), col_type: "icon_5", url: "hiker://page/py_settings_v1841#noRecordHistory##noHistory#", extra: {lineVisible: false}});
    }
    items.push({title: "搜索", desc: "输入关键词", col_type: "input", url: "input ? 'hiker://page/py_search_v1841?page=fypage##fypage&keyword=' + encodeURIComponent(input) : 'toast://请输入关键词'", extra: {titleVisible: true}});
}

function detailUrl(sourceId, vod) {
    if (String(vod.vod_tag || "").toLowerCase() === "folder") {
        return {url: "hiker://page/py_category_v1841?page=fypage##fypage", extra: {sourceId: sourceId, tid: String(vod.vod_id || ""), name: cleanLabel(vod.vod_name, "分类"), extend: {}, lineVisible: false}};
    }
    return {url: "hiker://page/py_detail_v1841", extra: {sourceId: sourceId, vodId: String(vod.vod_id || ""), name: cleanLabel(vod.vod_name, "详情"), pic: String(vod.vod_pic || ""), lineVisible: false}};
}

function pushVodList(sourceId, list) {
    var normalized = core.normalizeVodList(list || []);
    for (var index = 0; index < normalized.length; index++) {
        var vod = normalized[index] || {};
        var route = detailUrl(sourceId, vod);
        var pic = core.listImageUrl(sourceId, vod.vod_pic, vod.vod_id);
        var cardExtra = {};
        for (var key in route.extra) {
            if (Object.prototype.hasOwnProperty.call(route.extra, key)) cardExtra[key] = route.extra[key];
        }
        cardExtra.img = pic;
        cardExtra.cls = HOME_LIST_CLS;
        items.push({title: cleanLabel(vod.vod_name, "未命名"), desc: cleanLabel(vod.vod_remarks || vod.vod_year, ""), pic_url: pic, img: pic, col_type: "movie_2", url: route.url, extra: cardExtra});
    }
}

function categoryKey(sourceId) {
    return "py_home_category_" + String(sourceId || "");
}

function pushCategories(source, classes, selectedTid) {
    if (page !== 1) return;
    var categoryItems = mainActions.buildCategoryItems(source, classes, selectedTid, HOME_LIST_CLS, HOME_FOOTER_ID, HOME_SUB_CLS, callbackCoreLoader, ACTIONS_FILE, ACTIONS_VERSION);
    for (var index = 0; index < categoryItems.length; index++) items.push(categoryItems[index]);
}

function pushSubCategories(source, selectedTid) {
    if (page !== 1) return;
    var subItems = mainActions.buildSubCategoryItems(core, source.id, selectedTid, HOME_LIST_CLS, HOME_FOOTER_ID, HOME_SUB_CLS, callbackCoreLoader, ACTIONS_FILE, ACTIONS_VERSION);
    for (var index = 0; index < subItems.length; index++) items.push(subItems[index]);
}

if (bootstrapError) {
    try { setPageTitle(MY_RULE.title); } catch (ignoreBootstrapTitleError) {}
    items.push({title: "PY影视壳启动失败", desc: bootstrapErrorText(bootstrapError, core), col_type: "text_center_1", url: "hiker://page/py_settings_v1841#noRecordHistory##noHistory#", extra: {lineVisible: false}});
} else {
    try {
        var source = core.getCurrentSource();
        setPageTitle(source.name || MY_RULE.title);
        notifyNextPage("正在加载下一页");
        if (page === 1) {
            pushControls(source);
            if (typeof setPreResult === "function") {
                setPreResult(items.slice());
                items.length = 0;
            }
        }

        var selectedTid = String(getMyVar(categoryKey(source.id), "") || "");
        if (selectedTid === "推荐") selectedTid = "";
        var sourceRequestKey = categoryKey(source.id) + "_request";
        var sourceRequestToken = String(getMyVar(sourceRequestKey, "") || "");
        var sourceJustSwitched = sourceRequestToken.indexOf("source_switch_") === 0;
        if (sourceJustSwitched) {
            try { putMyVar(sourceRequestKey, ""); } catch (ignoreSourceSwitchTokenClearError) {}
        }
        var classes = core.getHomeClasses(source.id);
        var prefetched = null;
        var homeCacheTtl = sourceJustSwitched ? 6 * 60 * 60 * 1000 : undefined;
        var home = !selectedTid
            ? core.consumePrefetchedCategory(source.id, "", "1", {}, homeCacheTtl)
            : null;
        if (!home && typeof core.consumeWarmHome === "function") home = core.consumeWarmHome(source.id);
        if (!classes.length && !home) {
            try {
                home = core.homeSource(source.id, true) || {};
            } catch (homeError) {
                loadError = homeError;
                home = home || {};
            }
            var freshClasses = Array.isArray(home.class) ? home.class : [];
            if (freshClasses.length) {
                classes = freshClasses;
                core.cacheHomeClasses(source.id, classes);
            }
        }
        var firstClassTid = String(classes[0] && classes[0].type_id || "");
        var migrationExtend = selectedTid ? mainActions.getSelectedFilterExtend(core, source.id, selectedTid) : {};
        if (selectedTid && firstClassTid && selectedTid === firstClassTid && !Object.keys(migrationExtend).length) {
            selectedTid = "";
            try { putMyVar(categoryKey(source.id), ""); } catch (ignoreHomeCategoryMigrationError) {}
        }
        var selectedCategory = null;
        for (var selectedIndex = 0; selectedIndex < classes.length; selectedIndex++) {
            if (String(classes[selectedIndex].type_id || "") === selectedTid) {
                selectedCategory = classes[selectedIndex];
                break;
            }
        }
        if (!selectedCategory) selectedTid = "";
        var selectedExtend = selectedTid
            ? mainActions.getSelectedFilterExtend(core, source.id, selectedTid)
            : {};
        if (selectedTid && typeof core.consumePrefetchedCategory === "function") {
            prefetched = core.consumePrefetchedCategory(source.id, selectedTid, page, selectedExtend);
        }

        var homeList = [];
        var pageResult = null;
        if (selectedTid) {
            if (prefetched) {
                pageResult = prefetched;
                homeList = prefetched.list || [];
            } else if (canStartFallback()) {
                try {
                    var selectedResult = core.categorySource(source.id, selectedTid, String(page), true, selectedExtend) || {};
                    pageResult = selectedResult;
                    homeList = selectedResult.list || [];
                } catch (selectedError) {
                    loadError = selectedError;
                }
            }
        } else {
            if (!home) {
                try {
                    home = core.homeSource(source.id, true) || {};
                } catch (homeError) {
                    loadError = homeError;
                }
                var homeFreshClasses = Array.isArray(home.class) ? home.class : [];
                if (homeFreshClasses.length) {
                    classes = homeFreshClasses;
                    core.cacheHomeClasses(source.id, classes);
                }
            }
            var firstCategory = classes[0] || {};
            homeList = page === 1 && Array.isArray(home.list) ? home.list : [];
            if (!homeList.length && page === 1 && firstCategory.type_id) {
                var cachedFirstCategory = core.consumePrefetchedCategory(
                    source.id, firstCategory.type_id, "1", {}, homeCacheTtl
                );
                if (cachedFirstCategory) {
                    pageResult = cachedFirstCategory;
                    homeList = cachedFirstCategory.list || [];
                }
            }
            if (page > 1 && firstCategory.type_id && canStartFallback()) {
                try {
                    pageResult = core.categorySource(source.id, firstCategory.type_id, String(page), true, {}) || {};
                    homeList = pageResult.list || [];
                } catch (nextPageError) {
                    loadError = nextPageError;
                }
            }
            if (!homeList.length && canStartFallback() && (page === 1 || !firstCategory.type_id)) {
                try {
                    pageResult = core.homeVideoSource(source.id, firstCategory.type_id || "", String(page)) || {};
                    homeList = pageResult.list || [];
                } catch (homeVideoError) {
                    loadError = homeVideoError;
                }
            }
            if (!homeList.length && classes.length && page === 1 && canStartFallback()) {
                try {
                    var firstCategoryResult = core.categorySource(source.id, firstCategory.type_id, String(page), true, {}) || {};
                    pageResult = firstCategoryResult;
                    homeList = firstCategoryResult.list || [];
                } catch (categoryFallbackError) {
                    loadError = categoryFallbackError;
                }
            }
        }
        pushCategories(source, classes, selectedTid);
        pushSubCategories(source, selectedTid || String(classes[0] && classes[0].type_id || ""));
        var pageCount = pageResult ? Number(pageResult.pagecount || pageResult.pageCount || 0) : 0;
        if (pageCount > 0 && page > pageCount) homeList = [];
        if (page > 1 && !homeList.length && !loadError) notifyNextPage("到底了");
        pushVodList(source.id, homeList);
        if (page === 1) items.push({title: "", col_type: "blank_block", url: "hiker://empty", extra: {id: HOME_FOOTER_ID, lineVisible: false}});
        if (!homeList.length && page === 1) {
            var slowOrFailed = !canStartFallback() || !!loadError;
            items.push({
                title: slowOrFailed ? "源暂时无响应，点击重新载入" : (classes.length ? "当前分类没有返回内容" : "当前视频源没有返回内容"),
                desc: loadError ? core.errorText(loadError) : "",
                col_type: "text_center_1",
                url: slowOrFailed ? $("#noLoading#").lazyRule(function(loaderSource) {
                    var currentCore = eval(loaderSource)(["clearRuntimeCache"]);
                    currentCore.clearRuntimeCache();
                    refreshPage(true);
                    return "hiker://empty";
                }, callbackCoreLoader) : "hiker://empty"
            });
        }
    } catch (error) {
        if (page === 1 && !controlsAdded) pushControls(null);
        if (page === 1) items.push({title: "请先在设置中导入视频源", desc: core.errorText(error), col_type: "text_center_1", url: "hiker://page/py_source_manager_v1841#noRecordHistory##noHistory#", extra: {lineVisible: false}});
    }
}

setResult(items);
