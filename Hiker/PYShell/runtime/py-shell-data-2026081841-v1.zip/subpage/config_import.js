var core = $.require("hiker://page/py_core_v1841");
var items = [];
var nameKey = "py_config_import_name";
var pathKey = "py_config_import_path";
var localPathKey = "py_config_import_local_path";
var callbackCoreLoader = core.callbackCoreLoaderSource();

function selectFileUrl(key) {
    return "fileSelect://" + $.toString(function(key) {
        var selected = (typeof input !== "undefined" && input)
            ? String(input)
            : ((typeof MY_PATH !== "undefined" && MY_PATH) ? String(MY_PATH) : "");
        if (!selected) return "toast://没有取得文件路径";
        putMyVar(key, selected);
        refreshPage(false);
        return "toast://已填入配置路径";
    }, key);
}

setPageTitle("配置导入");

items.push({
    title: "名称",
    desc: "配置名称（可留空）",
    col_type: "input",
    url: $.toString(function(key) { putMyVar(key, input); }, nameKey),
    extra: {
        defaultValue: String(getMyVar(nameKey, "") || ""),
        titleVisible: true,
        lineVisible: false,
        onChange: $.toString(function(key) { putMyVar(key, input); }, nameKey)
    }
});

items.push({
    title: "配置地址",
    desc: "输入远程 URL、JSON 或 JS 配置地址",
    col_type: "input",
    url: $.toString(function(key) { putMyVar(key, input); }, pathKey),
    extra: {
        defaultValue: String(getMyVar(pathKey, "") || ""),
        titleVisible: true,
        lineVisible: false,
        onChange: $.toString(function(key) { putMyVar(key, input); }, pathKey)
    }
});
items.push({
    title: "文件",
    desc: "本地文件（点击右侧按钮选择）",
    col_type: "input",
    url: JSON.stringify(selectFileUrl(localPathKey)),
    extra: {
        defaultValue: String(getMyVar(localPathKey, "") || ""),
        titleVisible: true,
        lineVisible: false,
        onChange: $.toString(function(key) { putMyVar(key, input); }, localPathKey)
    }
});

items.push({
    title: "导入配置",
    col_type: "scroll_button",
    url: $("#noLoading#").lazyRule(function(nameKey, pathKey, localPathKey, loaderSource) {
        var remotePath = String(getMyVar(pathKey, "") || "").trim();
        var localPath = String(getMyVar(localPathKey, "") || "").trim();
        var path = localPath || remotePath;
        var name = String(getMyVar(nameKey, "") || "").trim();
        if (!path) return "toast://请输入配置地址或选择本地文件";
        try {
            showLoading("正在识别并导入配置...");
            var core = eval(loaderSource)(["importLocation"]);
            var report = core.importLocation(path, name, {makeCurrent: false});
            refreshPage(true);
            return "toast://导入完成：源" + Number(report.imported || 0) + "个，线路" + Number(report.lines || 0) + "条，直播" + Number(report.live || 0) + "组，失败" + Number(report.failed || 0) + "个";
        } catch (error) {
            return "toast://导入失败：" + (error && error.toString ? error.toString() : String(error));
        } finally {
            try { hideLoading(); } catch (ignoreHideLoadingError) {}
        }
    }, nameKey, pathKey, localPathKey, callbackCoreLoader),
    extra: {backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}
});

setResult(items);
