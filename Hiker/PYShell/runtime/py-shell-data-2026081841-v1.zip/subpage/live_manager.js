// 直播源管理：搜索、改名、持久化排序、单删和批量删除。
var core = $.require("hiker://page/py_core_v1841");
var callbackCoreLoader = core.callbackCoreLoaderSource();
var items = [];
var currentKey = "py_live_current";
var modeKey = "py_live_manager_batch";
var selectedKey = "py_live_manager_selected";
var searchKey = "py_live_manager_search";

function readArrayState(key) {
    try {
        var value = JSON.parse(String(getMyVar(key, "[]") || "[]"));
        return Array.isArray(value) ? value.map(String) : [];
    } catch (ignoreArrayStateError) { return []; }
}

try {
    addListener("onClose", $.toString(function(keys) {
        keys.forEach(function(key) { putMyVar(key, ""); });
    }, [modeKey, selectedKey, searchKey]));
} catch (ignoreCloseListenerError) {}

setPageTitle("直播源管理");

var sources = core.getLiveSources();
var currentId = String(getMyVar(currentKey, "") || "");
if (currentId && !sources.some(function(source) { return String(source.id) === currentId; })) {
    currentId = sources[0] ? String(sources[0].id) : "";
    putMyVar(currentKey, currentId);
}
var batchMode = String(getMyVar(modeKey, "") || "") === "1";
var selectedIds = readArrayState(selectedKey);
var selectedMap = {};
selectedIds.forEach(function(id) { selectedMap[id] = true; });
var searchText = String(getMyVar(searchKey, "") || "").trim().toLowerCase();
var filtered = sources.filter(function(source) {
    if (!searchText) return true;
    return [source.name, source.url].some(function(value) {
        return String(value || "").toLowerCase().indexOf(searchText) >= 0;
    });
});
var visibleIds = filtered.map(function(source) { return String(source.id); });
var allSelected = filtered.length > 0 && visibleIds.every(function(id) { return !!selectedMap[id]; });

items.push({
    title: "操作",
    pic_url: getPath(core.DATA_ROOT + "/assets/settings_v116.png"),
    col_type: "icon_2",
    url: $(["批量选择", "按名称排序", "按最近更新排序", "清空所有"], 2, "选择直播源操作").select(function(modeKey, selectedKey, currentKey, loaderSource) {
        if (input === "批量选择") {
            var active = String(getMyVar(modeKey, "") || "") === "1";
            putMyVar(modeKey, active ? "" : "1");
            putMyVar(selectedKey, "[]");
            refreshPage(false);
            return "toast://" + (active ? "已退出批量选择" : "已进入批量选择");
        }
        var module = eval(loaderSource)(["getLiveSources", "sortLiveSources", "removeLiveSources"]);
        if (input === "按名称排序" || input === "按最近更新排序") {
            try {
                module.sortLiveSources(input === "按名称排序" ? "name" : "updated_desc");
                refreshPage(false);
                return "toast://已" + input;
            } catch (error) {
                return "toast://排序失败：" + (error && error.toString ? error.toString() : String(error));
            }
        }
        if (input === "清空所有") {
            var sources = module.getLiveSources();
            if (!sources.length) return "toast://当前没有直播源";
            return $("确定删除全部 " + sources.length + " 个直播源？").confirm(function(ids, modeKey, selectedKey, currentKey, loaderSource) {
                try {
                    var result = eval(loaderSource)(["removeLiveSources"]).removeLiveSources(ids);
                    putMyVar(currentKey, "");
                    putMyVar(modeKey, "");
                    putMyVar(selectedKey, "[]");
                    refreshPage(false);
                    return "toast://已清空全部 " + result.removed + " 个直播源";
                } catch (error) {
                    return "toast://清空失败：" + (error && error.toString ? error.toString() : String(error));
                }
            }, sources.map(function(source) { return String(source.id); }), modeKey, selectedKey, currentKey, loaderSource);
        }
        return "hiker://empty";
    }, modeKey, selectedKey, currentKey, callbackCoreLoader),
    extra: {lineVisible: false}
});
items.push({col_type: "line"});

items.push({
    title: "搜索",
    desc: "直播源名称或地址",
    col_type: "input",
    url: $.toString(function(key) {
        putMyVar(key, input);
        refreshPage(false);
    }, searchKey),
    extra: {
        defaultValue: String(getMyVar(searchKey, "") || ""),
        titleVisible: true,
        onChange: $.toString(function(key) { if (!input) putMyVar(key, ""); }, searchKey),
        lineVisible: false
    }
});

if (batchMode) {
    items.push({
        title: allSelected ? "取消全选" : "全部选中",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(modeKey, selectedKey, ids) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            var selectedMap = {};
            selected.map(String).forEach(function(id) { selectedMap[id] = true; });
            var allSelected = ids.length > 0 && ids.every(function(id) { return !!selectedMap[id]; });
            putMyVar(modeKey, "1");
            putMyVar(selectedKey, JSON.stringify(allSelected ? [] : ids));
            refreshPage(false);
            return allSelected ? "toast://已取消全选" : "toast://已全部选中";
        }, modeKey, selectedKey, visibleIds),
        extra: allSelected
            ? {backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}
            : {lineVisible: false}
    });
    items.push({
        title: "反向选择",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(modeKey, selectedKey, ids) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            var selectedMap = {};
            selected.map(String).forEach(function(id) { selectedMap[id] = true; });
            putMyVar(modeKey, "1");
            putMyVar(selectedKey, JSON.stringify(ids.filter(function(id) { return !selectedMap[id]; })));
            refreshPage(false);
            return "toast://已反向选择";
        }, modeKey, selectedKey, visibleIds)
    });
    items.push({
        title: "删除所选",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(selectedKey, modeKey, currentKey, namesById, loaderSource) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            selected = selected.map(String).filter(function(id) { return !!namesById[id]; });
            if (!selected.length) return "toast://请先选择要删除的直播源";
            var preview = selected.slice(0, 4).map(function(id) { return namesById[id]; }).join("、");
            if (selected.length > 4) preview += " 等";
            return $("确认删除已选的 " + selected.length + " 个直播源？\n" + preview).confirm(function(ids, selectedKey, modeKey, currentKey, loaderSource) {
                try {
                    var result = eval(loaderSource)(["removeLiveSources"]).removeLiveSources(ids);
                    var currentId = String(getMyVar(currentKey, "") || "");
                    if (!result.sources.some(function(source) { return String(source.id) === currentId; })) {
                        putMyVar(currentKey, result.sources[0] ? String(result.sources[0].id) : "");
                    }
                    putMyVar(selectedKey, "[]");
                    putMyVar(modeKey, "");
                    refreshPage(false);
                    return "toast://已删除 " + result.removed + " 个直播源";
                } catch (error) {
                    return "toast://批量删除失败：" + (error && error.toString ? error.toString() : String(error));
                }
            }, selected, selectedKey, modeKey, currentKey, loaderSource);
        }, selectedKey, modeKey, currentKey, filtered.reduce(function(map, source) {
            map[String(source.id)] = String(source.name || "直播源");
            return map;
        }, {}), callbackCoreLoader)
    });
    items.push({
        title: "退出选择",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(modeKey, selectedKey) {
            putMyVar(modeKey, "");
            putMyVar(selectedKey, "[]");
            refreshPage(false);
            return "toast://已退出批量选择";
        }, modeKey, selectedKey)
    });
    items.push({col_type: "line"});
}

items.push({
    title: "直播源 " + sources.length,
    col_type: "text_2",
    url: "hiker://empty#noLoading#",
    extra: {backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}
});
items.push({
    title: "已选 " + (batchMode ? selectedIds.length : 0),
    col_type: "text_2",
    url: "hiker://empty#noLoading#",
    extra: {lineVisible: false}
});
items.push({col_type: "line"});

filtered.forEach(function(source) {
    var sourceId = String(source.id);
    var sourceName = String(source.name || "直播源");
    var isCurrent = sourceId === currentId;
    var isSelected = !!selectedMap[sourceId];
    var rowTitle = (batchMode ? (isSelected ? "☑ " : "☐ ") : (isCurrent ? "➡️ " : "")) + sourceName;
    var channelCount = Array.isArray(source.channels) ? source.channels.length : 0;
    var rowUrl = batchMode
        ? $("hiker://empty").lazyRule(function(selectedKey, sourceId) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            selected = selected.map(String);
            var position = selected.indexOf(sourceId);
            if (position >= 0) selected.splice(position, 1);
            else selected.push(sourceId);
            putMyVar(selectedKey, JSON.stringify(selected));
            refreshPage(false);
            return "hiker://empty";
        }, selectedKey, sourceId)
        : $([isCurrent ? "当前直播源" : "设为当前", "编辑名称", "编辑URL", "编辑UA", "改名", "置顶", "上移", "下移", "置底", "删除"], 2, "选择直播源操作").select(function(sourceId, sourceName, sourceUrl, sourceUa, currentKey, selectedKey, loaderSource) {
            if (input === "当前直播源") return "toast://当前正在使用：" + sourceName;
            if (input === "设为当前") {
                putMyVar(currentKey, sourceId);
                refreshPage(false);
                return "toast://已切换：" + sourceName;
            }
            if (input === "编辑名称" || input === "改名") {
                return $(sourceName, "输入新的直播源名称").input(function(sourceId, loaderSource) {
                    try {
                        var renamed = eval(loaderSource)(["updateLiveSource"]).updateLiveSource(sourceId, {name: input});
                        refreshPage(false);
                        return "toast://已改名：" + renamed.name;
                    } catch (error) {
                        return "toast://改名失败：" + (error && error.toString ? error.toString() : String(error));
                    }
                }, sourceId, loaderSource);
            }
            if (input === "编辑URL") {
                // 输入框只预填当前源的 URL（不混入 UA），UA 统一走"编辑UA"入口；
                // 提示示例仍展示完整三段格式，说明 UA 有专门入口。
                return $(sourceUrl || "", "📝 格式：名称||URL||UA\n示例：测试||http://ge.html-5.me//ii/4gTV.txt||aptv1.3\n（这里只填 URL，UA 请用\"编辑UA\"）").input(function(sourceId, loaderSource) {
                    try {
                        var updated = eval(loaderSource)(["updateLiveSource"]).updateLiveSource(sourceId, {url: input});
                        refreshPage(false);
                        return "toast://已更新URL，请刷新直播源";
                    } catch (error) {
                        return "toast://更新URL失败：" + (error && error.toString ? error.toString() : String(error));
                    }
                }, sourceId, loaderSource);
            }
            if (input === "编辑UA") {
                // 输入框预填当前源的 UA，提示示例用完整格式（UA 是第三段）。
                return $(sourceUa || "", "📝 格式：名称||URL||UA\n示例：测试||http://ge.html-5.me//ii/4gTV.txt||aptv1.3（第三段为 UA）").input(function(sourceId, loaderSource) {
                    try {
                        var updated = eval(loaderSource)(["updateLiveSource"]).updateLiveSource(sourceId, {ua: input});
                        refreshPage(false);
                        return "toast://已更新UA";
                    } catch (error) {
                        return "toast://更新UA失败：" + (error && error.toString ? error.toString() : String(error));
                    }
                }, sourceId, loaderSource);
            }
            if (["置顶", "上移", "下移", "置底"].indexOf(input) >= 0) {
                try {
                    var modes = {"置顶": "top", "上移": "up", "下移": "down", "置底": "bottom"};
                    eval(loaderSource)(["moveLiveSource"]).moveLiveSource(sourceId, modes[input]);
                    refreshPage(false);
                    return "toast://已" + input + "：" + sourceName;
                } catch (error) {
                    return "toast://排序失败：" + (error && error.toString ? error.toString() : String(error));
                }
            }
            if (input === "删除") {
                return $("确认删除直播源「" + sourceName + "」？").confirm(function(sourceId, sourceName, currentKey, selectedKey, loaderSource) {
                    try {
                        var result = eval(loaderSource)(["removeLiveSources"]).removeLiveSources([sourceId]);
                        var currentId = String(getMyVar(currentKey, "") || "");
                        if (currentId === sourceId) putMyVar(currentKey, result.sources[0] ? String(result.sources[0].id) : "");
                        var selected = [];
                        try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
                        putMyVar(selectedKey, JSON.stringify(selected.map(String).filter(function(id) { return id !== sourceId; })));
                        refreshPage(false);
                        return "toast://已删除：" + sourceName;
                    } catch (error) {
                        return "toast://删除失败：" + (error && error.toString ? error.toString() : String(error));
                    }
                }, sourceId, sourceName, currentKey, selectedKey, loaderSource);
            }
            return "hiker://empty";
        }, sourceId, sourceName, String(source.url || ""), String(source.ua || ""), currentKey, selectedKey, callbackCoreLoader);

    var rowExtra = {lineVisible: false, textAlign: "center"};
    if (batchMode && isSelected) {
        rowExtra.backgroundColor = "#168C72";
        rowExtra.textColor = "#FFFFFF";
    } else if (isCurrent && !batchMode) {
        rowExtra.backgroundColor = "#E8F5F1";
        rowExtra.textColor = "#116B58";
    }
    items.push({
        title: rowTitle,
        desc: "频道 " + channelCount,
        col_type: "text_3",
        url: rowUrl,
        extra: rowExtra
    });
});

if (filtered.length) items.push({col_type: "line"});

if (!filtered.length) {
    items.push({
        title: sources.length ? "没有匹配的直播源" : "暂无直播源，请返回直播页添加",
        col_type: "text_center_1",
        url: "hiker://page/py_live_v1841?page=1#noRecordHistory##noHistory#"
    });
}

setResult(items);
