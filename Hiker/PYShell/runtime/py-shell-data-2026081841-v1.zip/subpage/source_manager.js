// 本地 PY 源管理：参考聚影源管理的布局与操作方式。
// 顶部只保留 操作 / 分享，随后是搜索框；不显示导入与标签按钮行。
// 功能：搜索、批量选择、查看禁用、重复筛选、清空、删除、禁用、启用、检测、排序、分享。
var core = $.require("hiker://page/py_core_v1841");
var items = [];

var tabStateKey = "py_mgr_tab";
var batchModeKey = "py_mgr_batch_mode";
var selectedStateKey = "py_mgr_selected";
var checkStateKey = "py_mgr_connectivity";
var actionStateKey = "py_mgr_actions_expanded";
var searchStateKey = "py_mgr_search";
var DETECT_VERSION = 6;
var callbackCoreLoader = core.callbackCoreLoaderSource();

function readArrayState(key) {
    try {
        var value = JSON.parse(String(getMyVar(key, "[]") || "[]"));
        return Array.isArray(value) ? value.map(function(item) { return String(item || ""); }) : [];
    } catch (ignoreStateError) {
        return [];
    }
}

function readObjectState(key) {
    try {
        var value = JSON.parse(String(getMyVar(key, "{}") || "{}"));
        return value && typeof value === "object" && !Array.isArray(value) ? value : {};
    } catch (ignoreStateError) {
        return {};
    }
}

function connectivityDesc(report) {
    if (!report) return "";
    var elapsed = Number(report.elapsed || 0);
    var seconds = elapsed > 0 ? " · " + (elapsed / 1000).toFixed(1) + "秒" : "";
    if (report.ok) {
        // 优先用完整 detail（列表条数 + 图片状态），无 detail 时回退旧格式
        if (report.detail) {
            var detail = String(report.detail)
                .replace(/图片正常\s*\([^)]*\)/g, "图片正常")
                .replace(/列表\s*(\d+)\s*条/g, "$1条")
                .replace(/\s*·\s*/g, " · ");
            if (detail.length > 48) detail = detail.slice(0, 48) + "…";
            return "正常 · " + String(report.stage || "源站") + " · " + detail + seconds;
        }
        return "正常 · " + String(report.stage || "源站") + " " + Number(report.count || 0) + "条" + seconds;
    }
    var message = String(report.error || "源站没有返回内容").replace(/[\r\n]+/g, " ");
    if (message.length > 55) message = message.slice(0, 55) + "…";
    return "失败 · " + message + seconds;
}

function cachedConnectivityDesc(status) {
    if (!status || Number(status.version || 0) !== DETECT_VERSION || (status.state !== "valid" && status.state !== "invalid")) return "";
    var elapsed = Number(status.elapsed || 0);
    var seconds = elapsed > 0 ? " · " + (elapsed / 1000).toFixed(1) + "秒" : "";
    var message = String(status.message || "检测完成").replace(/[\r\n]+/g, " ");
    message = message
        .replace(/图片正常\s*\([^)]*\)/g, "图片正常")
        .replace(/列表\s*(\d+)\s*条/g, "$1条")
        .replace(/\s*·\s*/g, " · ");
    if (message.length > 48) message = message.slice(0, 48) + "…";
    return (status.state === "valid" ? "正常" : "失败") + " · " + String(status.stage || "源站") + " · " + message + seconds;
}

// 海阔 8.83 的 text_1 不读取 extra.textSize，但它的 TextView 支持 HTML 的
// <small>/<font>。用不可见高亮标记触发 HTML 解析，使首行更小、检测结果最小灰色。
function htmlEscape(value) {
    return String(value == null ? "" : value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\"/g, "&quot;");
}

function forceHtmlText(html) {
    return String(html || "") + "‘‘\u200B’’";
}

var sourceRowPaint = null;
var sourceRowAvailableWidth = 0;
try {
    if (typeof getCurrentActivity === "function" && typeof android !== "undefined") {
        var sourceRowActivity = getCurrentActivity();
        var sourceRowSample = new android.widget.TextView(sourceRowActivity);
        sourceRowSample.setTextSize(13);
        sourceRowPaint = sourceRowSample.getPaint();
        var sourceRowMetrics = sourceRowActivity.getResources().getDisplayMetrics();
        sourceRowAvailableWidth = Number(sourceRowMetrics.widthPixels || 0) - 32 * Number(sourceRowMetrics.density || 1);
    }
} catch (ignoreSourceRowPaintError) {}

function compactRowPart(value) {
    return String(value || "")
        .replace(/[\uFE0E\uFE0F]/g, "")
        .replace(/\s+/g, " ")
        .trim();
}

function truncateRowPart(value, maxWidth, keepTail) {
    var text = compactRowPart(value);
    if (!sourceRowPaint || !(maxWidth > 0) || Number(sourceRowPaint.measureText(text)) <= maxWidth) return text;
    var units = Array.from ? Array.from(text) : text.split("");
    var output = "";
    if (keepTail) {
        for (var tailIndex = units.length - 1; tailIndex >= 0; tailIndex--) {
            var tailCandidate = "…" + units[tailIndex] + output;
            if (Number(sourceRowPaint.measureText(tailCandidate)) > maxWidth) break;
            output = units[tailIndex] + output;
        }
        return "…" + output;
    }
    for (var headIndex = 0; headIndex < units.length; headIndex++) {
        var headCandidate = output + units[headIndex] + "…";
        if (Number(sourceRowPaint.measureText(headCandidate)) > maxWidth) break;
        output += units[headIndex];
    }
    return output + "…";
}

function spacingForWidth(width) {
    if (!sourceRowPaint || !(width > 0)) return "　　";
    var thin = " ";
    var hair = " ";
    var thinWidth = Number(sourceRowPaint.measureText(thin)) || 2;
    var hairWidth = Number(sourceRowPaint.measureText(hair)) || 1;
    var thinCount = Math.max(0, Math.floor(width / thinWidth));
    var remain = Math.max(0, width - thinCount * thinWidth);
    var hairCount = Math.max(0, Math.round(remain / hairWidth));
    return new Array(thinCount + 1).join(thin) + new Array(hairCount + 1).join(hair);
}

function compactSourceRow(leftValue, rightValue) {
    var left = compactRowPart(leftValue);
    var right = compactRowPart(rightValue);
    if (!sourceRowPaint || !(sourceRowAvailableWidth > 0)) {
        if (left.length > 18) left = left.slice(0, 17) + "…";
        if (right.length > 16) right = "…" + right.slice(-15);
        return left + "　　" + right;
    }
    var minGapWidth = Number(sourceRowPaint.measureText("　"));
    right = truncateRowPart(right, sourceRowAvailableWidth * 0.46, true);
    var rightWidth = Number(sourceRowPaint.measureText(right));
    left = truncateRowPart(left, Math.max(sourceRowAvailableWidth * 0.30, sourceRowAvailableWidth - rightWidth - minGapWidth), false);
    var leftWidth = Number(sourceRowPaint.measureText(left));
    return left + spacingForWidth(Math.max(minGapWidth, sourceRowAvailableWidth - leftWidth - rightWidth)) + right;
}

function sourceRowTitle(leftValue, rightValue, status) {
    var firstLine = "<small>" + htmlEscape(compactSourceRow(leftValue, rightValue)) + "</small>";
    if (!status) return forceHtmlText(firstLine);
    return forceHtmlText(firstLine + "<br><small><small><font color=\"#999999\">" + htmlEscape(status) + "</font></small></small>");
}

try {
    addListener("onClose", $.toString(function(keys) {
        keys.forEach(function(key) { putMyVar(key, ""); });
    }, [tabStateKey, batchModeKey, selectedStateKey, checkStateKey, actionStateKey, searchStateKey]));
} catch (ignoreCloseListenerError) {}

setPageTitle("本地PY源管理");

try {
    var index = core.getIndex();
    var sources = Array.isArray(index.sources) ? index.sources : [];
    var currentId = index.current;
    var stats = core.getSourceStats();
    var duplicates = core.detectDuplicateDomains();
    var duplicateIdsMap = {};
    for (var dupDomain in duplicates) {
        duplicates[dupDomain].forEach(function(id) { duplicateIdsMap[id] = true; });
    }

    var tab = String(getMyVar(tabStateKey, "all") || "all");
    var batchMode = String(getMyVar(batchModeKey, "") || "") === "1";
    var selectedIds = readArrayState(selectedStateKey);
    var checkState = readObjectState(checkStateKey);
    var persistentStatus = {};
    try {
        persistentStatus = typeof core.getSourceStatusCache === "function"
            ? (core.getSourceStatusCache().sources || {})
            : {};
    } catch (ignorePersistentStatusError) {}
    var expandedSourceId = String(getMyVar(actionStateKey, "") || "");
    var searchText = String(getMyVar(searchStateKey, "") || "").trim().toLowerCase();

    // 按标签过滤源
    var filtered = sources.filter(function(source) {
        if (tab === "enabled") return core.isSourceEnabled(source);
        if (tab === "disabled") return !core.isSourceEnabled(source);
        if (tab === "duplicate") return !!duplicateIdsMap[source.id];
        return true;
    }).filter(function(source) {
        if (!searchText) return true;
        return [source.name, source.fileName, source.path, source.ext].some(function(value) {
            return String(value || "").toLowerCase().indexOf(searchText) >= 0;
        });
    });
    var visibleIds = filtered.map(function(source) { return String(source.id); });
    var selectedMap = {};
    selectedIds.forEach(function(id) { selectedMap[id] = true; });
    var allSelected = filtered.length > 0 && visibleIds.every(function(id) { return !!selectedMap[id]; });

    // ---- 顶部工具栏 ----
    items.push({
        title: "操作",
        pic_url: getPath(core.DATA_ROOT + "/assets/settings_v116.png"),
        col_type: "icon_2",
        url: $(["批量选择", "查看禁用", "查看重复", "显示全部", "清空所有"], 2, "选择操作功能项").select(function(tabKey, modeKey, selectedKey, actionKey, loaderSource) {
            if (input === "批量选择") {
                var active = String(getMyVar(modeKey, "") || "") === "1";
                putMyVar(modeKey, active ? "" : "1");
                if (active) putMyVar(selectedKey, "[]");
                putMyVar(actionKey, "");
                refreshPage(false);
                return "toast://" + (active ? "已退出批量选择" : "已进入批量选择");
            }
            if (input === "查看禁用") putMyVar(tabKey, "disabled");
            else if (input === "查看重复") putMyVar(tabKey, "duplicate");
            else if (input === "显示全部") putMyVar(tabKey, "all");
            else if (input === "清空所有") {
                var module = eval(loaderSource)(["getIndex", "removeSources"]);
                var ids = module.getIndex().sources.map(function(source) { return String(source.id); });
                if (!ids.length) return "toast://当前没有视频源";
                return $("确定要删除本地全部 " + ids.length + " 个视频源？").confirm(function(ids, tabKey, selectedKey, modeKey, actionKey, loaderSource) {
                    var removed = eval(loaderSource)(["removeSources"]).removeSources(ids);
                    putMyVar(tabKey, "all");
                    putMyVar(selectedKey, "[]");
                    putMyVar(modeKey, "");
                    putMyVar(actionKey, "");
                    refreshPage(false);
                    return "toast://已全部清空，共删除 " + removed + " 个视频源";
                }, ids, tabKey, selectedKey, modeKey, actionKey, loaderSource);
            }
            putMyVar(selectedKey, "[]");
            putMyVar(modeKey, "");
            putMyVar(actionKey, "");
            refreshPage(false);
            return "toast://已切换列表范围";
        }, tabStateKey, batchModeKey, selectedStateKey, actionStateKey, callbackCoreLoader),
        extra: {lineVisible: false}
    });
    items.push({
        title: "分享",
        pic_url: getPath(core.DATA_ROOT + "/assets/video_source_v116.png"),
        col_type: "icon_2",
        url: $("hiker://empty").lazyRule(function(ids, loaderSource) {
            if (!ids.length) return "toast://当前列表没有可分享的视频源";
            try {
                if (typeof showLoading === "function") showLoading("正在打包 " + ids.length + " 个视频源...");
                var share = eval(loaderSource)(["createSourcesShare"]).createSourcesShare(ids);
                return "share://" + share.path;
            } catch (error) {
                return "toast://分享文件生成失败: " + (error && error.toString ? error.toString() : String(error));
            } finally {
                try { if (typeof hideLoading === "function") hideLoading(); } catch (ignoreHideLoadingError) {}
            }
        }, visibleIds, callbackCoreLoader),
        extra: {lineVisible: false}
    });
    items.push({col_type: "line"});

    // 聚影布局中的搜索框；按要求不再输出搜索框下面的标签按钮行。
    items.push({
        title: "🔍",
        desc: "搜索视频源...",
        col_type: "input",
        url: $.toString(function(key) {
            putMyVar(key, input);
            refreshPage(false);
        }, searchStateKey),
        extra: {
            defaultValue: String(getMyVar(searchStateKey, "") || ""),
            titleVisible: true,
            onChange: $.toString(function(key) {
                if (!input) putMyVar(key, "");
            }, searchStateKey),
            lineVisible: false
        }
    });

    // 批量操作仅在“操作 → 批量选择”后显示，保持聚影的交互层级。
    if (batchMode) {
    items.push({
        title: allSelected ? "取消全选" : "全部选中",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(modeKey, selectedKey, ids) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            var selectedMap = {};
            selected.forEach(function(id) { selectedMap[String(id)] = true; });
            var allSelected = ids.length > 0 && ids.every(function(id) { return !!selectedMap[id]; });
            putMyVar(modeKey, "1");
            putMyVar(selectedKey, JSON.stringify(allSelected ? [] : ids));
            refreshPage(false);
            return allSelected ? "toast://已取消全选" : "toast://已全部选中";
        }, batchModeKey, selectedStateKey, visibleIds),
        extra: {
            backgroundColor: allSelected ? "#168C72" : "",
            textColor: allSelected ? "#FFFFFF" : "",
            longClick: [{
                title: "退出批量选择",
                js: $.toString(function(modeKey, selectedKey) {
                    putMyVar(modeKey, "");
                    putMyVar(selectedKey, "[]");
                    refreshPage(false);
                    return "toast://已退出批量选择";
                }, batchModeKey, selectedStateKey)
            }]
        }
    });

    // 反向选择：把当前选中状态取反（聚影同款交互）
    items.push({
        title: "反向选择",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(modeKey, selectedKey, ids) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            var selectedMap = {};
            selected.forEach(function(id) { selectedMap[String(id)] = true; });
            putMyVar(modeKey, "1");
            putMyVar(selectedKey, JSON.stringify(ids.filter(function(id) { return !selectedMap[id]; })));
            refreshPage(false);
            return "toast://已反向选择";
        }, batchModeKey, selectedStateKey, visibleIds)
    });

    // 去重检测：刷新重复分组并提示
    items.push({
        title: "去重检测",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(loaderSource) {
            var module = eval(loaderSource)(["detectDuplicateDomains", "getSource"]);
            var dups = module.detectDuplicateDomains();
            var names = [];
            for (var domain in dups) {
                var groupNames = dups[domain].map(function(id) {
                    try { return module.getSource(id).name; } catch (ignoreGetNameError) { return id; }
                });
                names.push(domain + "：" + groupNames.join("、"));
            }
            refreshPage(false);
            if (!names.length) return "toast://未发现重复的源站域名";
            return "toast://发现重复源站：" + names.join(" | ");
        }, callbackCoreLoader),
        extra: {lineVisible: false}
    });

    // 删除选中
    items.push({
        title: "删除",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(selectedKey, modeKey, stateKey, actionKey, namesById, loaderSource) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            selected = selected.map(String).filter(function(id) { return !!namesById[id]; });
            if (!selected.length) return "toast://请先在列表中选择要删除的视频源";
            var preview = selected.slice(0, 4).map(function(id) { return namesById[id]; }).join("、");
            if (selected.length > 4) preview += " 等";
            return $("确认删除已选的 " + selected.length + " 个视频源？\n" + preview).confirm(function(ids, selectedKey, modeKey, stateKey, actionKey, loaderSource) {
                try {
                    var removed = eval(loaderSource)(["removeSources"]).removeSources(ids);
                    putMyVar(selectedKey, "[]");
                    putMyVar(modeKey, "");
                    putMyVar(actionKey, "");
                    var state = {};
                    try { state = JSON.parse(String(getMyVar(stateKey, "{}") || "{}")); } catch (ignoreStateError) {}
                    ids.forEach(function(id) { delete state[id]; });
                    putMyVar(stateKey, JSON.stringify(state));
                    refreshPage(false);
                    return "toast://已删除 " + removed + " 个视频源";
                } catch (error) {
                    return "toast://批量删除失败: " + (error && error.toString ? error.toString() : String(error));
                }
            }, selected, selectedKey, modeKey, stateKey, actionKey, loaderSource);
        }, selectedStateKey, batchModeKey, checkStateKey, actionStateKey, filtered.reduce(function(map, source) {
            map[source.id] = source.name;
            return map;
        }, {}), callbackCoreLoader)
    });
    // 分隔：第二行操作按钮（scroll_button 连续超过 4 个会被截断）
    items.push({col_type: "line"});

    // 禁用选中
    items.push({
        title: "禁用所选",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(selectedKey, modeKey, loaderSource) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            selected = selected.map(String);
            if (!selected.length) return "toast://请先在列表中选择视频源";
            return $("确定要禁用选择的 " + selected.length + " 个视频源？").confirm(function(ids, selectedKey, modeKey, loaderSource) {
                try {
                    var module = eval(loaderSource)(["setSourceEnabled"]);
                    var disabled = 0;
                    ids.forEach(function(id) {
                        try { module.setSourceEnabled(id, false); disabled++; } catch (ignoreSetEnabledError) {}
                    });
                    putMyVar(selectedKey, "[]");
                    putMyVar(modeKey, "");
                    refreshPage(false);
                    return "toast://已禁用 " + disabled + " 个视频源";
                } catch (error) {
                    return "toast://批量禁用失败: " + (error && error.toString ? error.toString() : String(error));
                }
            }, selected, selectedKey, modeKey, loaderSource);
        }, selectedStateKey, batchModeKey, callbackCoreLoader)
    });

    // 启用选中（在"禁用"标签页下把选中源恢复启用）
    items.push({
        title: "启用所选",
        col_type: "scroll_button",
        url: $("hiker://empty").lazyRule(function(selectedKey, modeKey, loaderSource) {
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            selected = selected.map(String);
            if (!selected.length) return "toast://请先在列表中选择视频源";
            try {
                var module = eval(loaderSource)(["setSourceEnabled"]);
                var enabled = 0;
                selected.forEach(function(id) {
                    try { module.setSourceEnabled(id, true); enabled++; } catch (ignoreSetEnabledError) {}
                });
                putMyVar(selectedKey, "[]");
                putMyVar(modeKey, "");
                refreshPage(false);
                return "toast://已启用 " + enabled + " 个视频源";
            } catch (error) {
                return "toast://批量启用失败: " + (error && error.toString ? error.toString() : String(error));
            }
        }, selectedStateKey, batchModeKey, callbackCoreLoader)
    });
    // 分隔：第三行操作按钮
    items.push({col_type: "line"});

    // 检测连通性
    items.push({
        title: "检测",
        col_type: "text_4",
        url: $("hiker://empty").lazyRule(function(selectedKey, modeKey, stateKey, ids, loaderSource, detectVersion) {
            if (!ids.length) return "toast://当前标签下没有视频源";
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            var validMap = {};
            ids.forEach(function(id) { validMap[id] = true; });
            selected = selected.filter(function(id) { return !!validMap[String(id)]; }).map(String);
            if (String(getMyVar(modeKey, "") || "") === "1" && !selected.length) {
                return "toast://请先点击源名选择要检测的视频源";
            }
            var targets = selected.length ? selected : ids;
            var results = [];
            if (typeof showLoading === "function") showLoading("正在检测 " + targets.length + " 个视频源...");
            try {
                var module = eval(loaderSource)(["getSource", "checkSourceConnectivity", "saveSourceStatus"]);
                targets.forEach(function(sourceId, targetIndex) {
                    sourceId = String(sourceId);
                    try {
                        if (typeof showLoading === "function") {
                            var sourceName = sourceId;
                            try { sourceName = module.getSource(sourceId).name || sourceId; } catch (ignoreSourceNameError) {}
                            showLoading("正在检测 " + (targetIndex + 1) + "/" + targets.length + "：" + sourceName);
                        }
                        results.push(module.checkSourceConnectivity(sourceId));
                    } catch (error) {
                        results.push({
                            ok: false,
                            sourceId: sourceId,
                            sourceName: sourceId,
                            stage: "源站",
                            count: 0,
                            elapsed: 0,
                            error: error && error.toString ? error.toString() : String(error)
                        });
                    }
                });
            } finally {
                try { if (typeof hideLoading === "function") hideLoading(); } catch (ignoreHideLoadingError) {}
            }
            var state = {};
            try { state = JSON.parse(String(getMyVar(stateKey, "{}") || "{}")); } catch (ignoreStateError) {}
            var okCount = 0;
            var failedCount = 0;
            results.forEach(function(result) {
                var sourceId = String(result.sourceId || "");
                if (sourceId) {
                    state[sourceId] = result;
                    if (typeof module.saveSourceStatus === "function") {
                        module.saveSourceStatus(sourceId, {
                            version: detectVersion,
                            state: result.ok ? "valid" : "invalid",
                            message: result.detail || result.error || "检测完成",
                            elapsed: Number(result.elapsed || 0),
                            stage: String(result.stage || "源站")
                        });
                    }
                }
                if (result.ok) okCount++;
                else failedCount++;
            });
            putMyVar(stateKey, JSON.stringify(state));
            refreshPage(false);
            return "toast://检测完成：正常 " + okCount + "，失败 " + failedCount;
        }, selectedStateKey, batchModeKey, checkStateKey, visibleIds, callbackCoreLoader, DETECT_VERSION),
        extra: {id: "py_mgr_action_detect", lineVisible: false}
    });

    // 持久化排序：插在检测与分享之间。
    items.push({
        title: "排序",
        col_type: "text_4",
        url: $(["按时间排序由新到旧", "按名称排序"], 2, "选择排序方式").select(function(loaderSource) {
            try {
                var mode = input === "按时间排序由新到旧" ? "time_desc" : "name";
                eval(loaderSource)(["sortSources"]).sortSources(mode);
                refreshPage(false);
                return "toast://已" + input;
            } catch (error) {
                return "toast://排序失败：" + (error && error.toString ? error.toString() : String(error));
            }
        }, callbackCoreLoader),
        extra: {id: "py_mgr_action_sort", lineVisible: false}
    });

    // 分享选中
    items.push({
        title: "批量分享",
        col_type: "text_4",
        url: $("hiker://empty").lazyRule(function(selectedKey, modeKey, ids, loaderSource) {
            if (!ids.length) return "toast://当前标签下没有视频源";
            var selected = [];
            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
            var validMap = {};
            ids.forEach(function(id) { validMap[id] = true; });
            selected = selected.map(String).filter(function(id) { return !!validMap[id]; });
            if (String(getMyVar(modeKey, "") || "") === "1" && !selected.length) {
                return "toast://请先点击源名选择要分享的视频源";
            }
            var targets = selected.length ? selected : ids;
            try {
                if (typeof showLoading === "function") showLoading("正在打包 " + targets.length + " 个视频源...");
                var share = eval(loaderSource)(["createSourcesShare"]).createSourcesShare(targets);
                return "share://" + share.path;
            } catch (error) {
                return "toast://分享文件生成失败: " + (error && error.toString ? error.toString() : String(error));
            } finally {
                try { if (typeof hideLoading === "function") hideLoading(); } catch (ignoreHideLoadingError) {}
            }
        }, selectedStateKey, batchModeKey, visibleIds, callbackCoreLoader)
    });
    items.push({
        title: "退出选择",
        col_type: "text_4",
        url: $("hiker://empty").lazyRule(function(modeKey, selectedKey, actionKey) {
            putMyVar(modeKey, "");
            putMyVar(selectedKey, "[]");
            putMyVar(actionKey, "");
            refreshPage(false);
            return "toast://已退出批量选择";
        }, batchModeKey, selectedStateKey, actionStateKey),
        extra: {id: "py_mgr_action_exit", lineVisible: false}
    });
    items.push({col_type: "line"});
    }

    // 四个统计胶囊：当前=全部、启用、重复、禁用。
    var filterPills = [
        {key: "all", title: "当前 " + stats.total},
        {key: "enabled", title: "启用 " + stats.enabled},
        {key: "duplicate", title: "重复 " + stats.duplicate},
        {key: "disabled", title: "禁用 " + stats.disabled}
    ];
    filterPills.forEach(function(pill) {
        var active = tab === pill.key;
        items.push({
            title: pill.title,
            col_type: "text_4",
            url: $("hiker://empty").lazyRule(function(tabKey, value) {
                putMyVar(tabKey, value);
                refreshPage(false);
                return "hiker://empty#noLoading#";
            }, tabStateKey, pill.key),
            extra: active
                ? {backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}
                : {lineVisible: false}
        });
    });
    items.push({col_type: "line"});

    // ---- 过滤后的源列表 ----
    filtered.forEach(function(source) {
        var isCurrent = String(source.id) === String(currentId);
        var isDisabled = !core.isSourceEnabled(source);
        var isDuplicate = !!duplicateIdsMap[source.id];
        var batchSelected = !!selectedMap[source.id];
        var cachedStatus = persistentStatus[source.id] || null;
        var checkReport = checkState[source.id] || null;
        var cachedResult = cachedConnectivityDesc(cachedStatus);
        var status = connectivityDesc(checkReport) || cachedResult;
        var titlePrefix = batchMode
            ? (batchSelected ? "☑ " : "☐ ")
            : (isCurrent ? "➡️ " : "");
        var statusMarker = checkReport
            ? (checkReport.ok ? "✅ " : "❌ ")
            : (cachedResult ? (cachedStatus.state === "valid" ? "✅ " : "❌ ") : "");
        var rowTitle = titlePrefix + statusMarker + source.name;
        var rowExtra = {lineVisible: false, id: "py_mgr_row_" + source.id};
        var fileName = String(source.fileName || source.api || "视频源");
        var sourceMenu = [
            isCurrent ? "当前源" : "启用为当前源",
            "改名",
            "分享",
            isDisabled ? "启用" : "禁用",
            "检测",
            "置顶",
            "上移",
            "下移",
            "置底",
            "扩展",
            "编辑",
            "删除"
        ];
        var sourceActionUrl = batchMode
            ? $("#noLoading#").lazyRule(function(selectedKey, sourceId) {
                var selected = [];
                try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
                selected = selected.map(String);
                var position = selected.indexOf(sourceId);
                if (position >= 0) selected.splice(position, 1);
                else selected.push(sourceId);
                putMyVar(selectedKey, JSON.stringify(selected));
                refreshPage(false);
                return "hiker://empty";
            }, selectedStateKey, source.id)
            : $(sourceMenu, 2, "选择视频源操作").select(function(sourceId, sourceName, sourcePath, sourceExt, disabled, current, stateKey, selectedKey, loaderSource, detectVersion) {
                var module = eval(loaderSource)(["setCurrentSource", "createSourcesShare", "setSourceEnabled", "checkSourceConnectivity", "saveSourceStatus"]);
                if (input === "当前源") return "toast://当前正在使用：" + sourceName;
                if (input === "改名") {
                    return $(sourceName, "修改视频源显示名称（留空恢复源自带名称）").input(function(sourceId, loaderSource) {
                        try {
                            var renamed = eval(loaderSource)(["renameSource"]).renameSource(sourceId, input);
                            refreshPage(false);
                            return "toast://已改名：" + renamed.name;
                        } catch (error) {
                            return "toast://改名失败：" + (error && error.toString ? error.toString() : String(error));
                        }
                    }, sourceId, loaderSource);
                }
                if (input === "启用为当前源") {
                    try {
                        module.setCurrentSource(sourceId);
                        refreshPage(false);
                        return "toast://已切换：" + sourceName;
                    } catch (error) {
                        return "toast://切换失败：" + (error && error.toString ? error.toString() : String(error));
                    }
                }
                if (input === "分享") {
                    try {
                        var share = module.createSourcesShare([sourceId]);
                        return "share://" + share.path;
                    } catch (error) {
                        return "toast://分享失败：" + (error && error.toString ? error.toString() : String(error));
                    }
                }
                if (input === "启用" || input === "禁用") {
                    try {
                        module.setSourceEnabled(sourceId, input === "启用");
                        refreshPage(false);
                        return "toast://已" + input + "：" + sourceName;
                    } catch (error) {
                        return "toast://" + (error && error.toString ? error.toString() : String(error));
                    }
                }
                if (input === "检测") {
                    try {
                        if (typeof showLoading === "function") showLoading("正在检查视频源连通性...");
                        var result = module.checkSourceConnectivity(sourceId);
                        var state = {};
                        try { state = JSON.parse(String(getMyVar(stateKey, "{}") || "{}")); } catch (ignoreStateError) {}
                        state[sourceId] = result;
                        putMyVar(stateKey, JSON.stringify(state));
                        if (typeof module.saveSourceStatus === "function") {
                            module.saveSourceStatus(sourceId, {
                                version: detectVersion,
                                state: result.ok ? "valid" : "invalid",
                                message: result.detail || result.error || "检测完成",
                                elapsed: Number(result.elapsed || 0),
                                stage: String(result.stage || "源站")
                            });
                        }
                        refreshPage(false);
                        return result.ok
                            ? "toast://检查正常：" + result.sourceName
                            : "toast://检查失败：" + result.sourceName + "，" + result.error;
                    } catch (error) {
                        return "toast://检查失败：" + (error && error.toString ? error.toString() : String(error));
                    } finally {
                        try { if (typeof hideLoading === "function") hideLoading(); } catch (ignoreHideLoadingError) {}
                    }
                }
                if (["置顶", "上移", "下移", "置底"].indexOf(input) >= 0) {
                    try {
                        var moveModes = {"置顶": "top", "上移": "up", "下移": "down", "置底": "bottom"};
                        eval(loaderSource)(["moveSource"]).moveSource(sourceId, moveModes[input]);
                        refreshPage(false);
                        return "toast://已" + input + "：" + sourceName;
                    } catch (error) {
                        return "toast://排序失败：" + (error && error.toString ? error.toString() : String(error));
                    }
                }
                if (input === "扩展") {
                    return $(sourceExt || "", "输入该源的 extend 参数").input(function(sourceId, loaderSource) {
                        try {
                            eval(loaderSource)(["setSourceExtend"]).setSourceExtend(sourceId, input);
                            refreshPage(false);
                            return "toast://extend 已保存";
                        } catch (error) {
                            return "toast://" + (error && error.toString ? error.toString() : String(error));
                        }
                    }, sourceId, loaderSource);
                }
                if (input === "编辑") return "editFile://" + sourcePath;
                if (input === "删除") {
                    return $("确认删除视频源「" + sourceName + "」？").confirm(function(sourceId, selectedKey, stateKey, loaderSource) {
                        try {
                            eval(loaderSource)(["removeSource"]).removeSource(sourceId);
                            var selected = [];
                            try { selected = JSON.parse(String(getMyVar(selectedKey, "[]") || "[]")); } catch (ignoreSelectedError) {}
                            putMyVar(selectedKey, JSON.stringify(selected.filter(function(id) { return String(id) !== sourceId; })));
                            var state = {};
                            try { state = JSON.parse(String(getMyVar(stateKey, "{}") || "{}")); } catch (ignoreStateError) {}
                            delete state[sourceId];
                            putMyVar(stateKey, JSON.stringify(state));
                            refreshPage(false);
                            return "toast://已删除：" + sourceId;
                        } catch (error) {
                            return "toast://删除失败：" + (error && error.toString ? error.toString() : String(error));
                        }
                    }, sourceId, selectedKey, stateKey, loaderSource);
                }
                return "hiker://empty";
            }, source.id, source.name, source.path, String(source.ext || ""), isDisabled, isCurrent, checkStateKey, selectedStateKey, callbackCoreLoader, DETECT_VERSION);

        items.push({
            title: sourceRowTitle(rowTitle, fileName, status),
            col_type: "text_1",
            url: sourceActionUrl,
            extra: rowExtra
        });
        items.push({col_type: "line"});
    });

    if (!filtered.length) {
        items.push({
            title: tab === "disabled" ? "没有禁用的视频源" : (tab === "duplicate" ? "未发现重复的源站" : "暂无视频源，请到设置中导入"),
            col_type: "text_center_1",
            url: "hiker://page/py_settings_v1841#noRecordHistory##noHistory#"
        });
    }
} catch (error) {
    items.push({title: "视频源管理加载失败", desc: core.errorText(error), col_type: "text_center_1", url: "hiker://empty"});
}

setResult(items);
