function loadDetailCore() {
    var corePath = "hiker://files/data/PY\u5f71\u89c6\u58f3/subpage/py_core.js";
    var pagePath = "hiker://page/py_core_v1845";
    var requiredMethods = ["detailSource", "getSource", "imageUrl", "callbackCoreLoaderSource", "errorText"];
    function ready(candidate) {
        if (!candidate) return false;
        for (var index = 0; index < requiredMethods.length; index++) {
            if (typeof candidate[requiredMethods[index]] !== "function") return false;
        }
        return true;
    }
    var loaded = null;
    try { loaded = $.require(pagePath); } catch (ignorePageRequireError) {}
    if (!ready(loaded)) {
        try { loaded = $.require(corePath, true); } catch (ignoreFileRequireError) {}
    }
    if (!ready(loaded)) {
        var previousExports = $.exports;
        try {
            $.exports = {};
            var code = "";
            try { if (typeof readFile === "function") code = String(readFile(corePath) || ""); } catch (ignoreReadError) {}
            if (!code) code = String(request(corePath) || "");
            if (!code) throw new Error("PY 核心模块为空");
            eval(code);
            loaded = $.exports;
        } finally {
            $.exports = previousExports;
        }
    }
    if (!ready(loaded)) throw new Error("PY 详情核心模块不完整");
    return loaded;
}

var core = loadDetailCore();
var items = [];
var sourceId = String(MY_PARAMS.sourceId || "");
var vodId = String(MY_PARAMS.vodId || MY_PARAMS.pid || "");
// 从阅读页"章目录"跳回时，extra 传参可能全部丢失（flex_button 不传参），
// 从固定 key MyVar 兜底读取（detail.js 章节按钮生成时已存 py_reader_meta）
if ((!vodId || !sourceId)) {
    try {
        var detailMetaCache = JSON.parse(getMyVar("py_reader_meta", "{}") || "{}") || {};
        if (!sourceId) sourceId = String(detailMetaCache.sourceId || "");
        if (!vodId) vodId = String(detailMetaCache.vodId || "");
        if (!String(MY_PARAMS.name || "")) MY_PARAMS.name = String(detailMetaCache.name || "");
        if (!String(MY_PARAMS.pic || "")) MY_PARAMS.pic = String(detailMetaCache.pic || "");
    } catch (ignoreDetailMetaError) {}
}
var callbackCoreLoader = "";
try {
    if (core && typeof core.callbackCoreLoaderSource === "function") {
        callbackCoreLoader = core.callbackCoreLoaderSource();
    }
} catch (ignorePageCoreLoaderError) {}
if (!callbackCoreLoader) {
    try {
        var bootstrapCore = $.require("hiker://files/data/PY\u5f71\u89c6\u58f3/subpage/py_core.js", true);
        if (bootstrapCore && typeof bootstrapCore.callbackCoreLoaderSource === "function") {
            callbackCoreLoader = bootstrapCore.callbackCoreLoaderSource();
        }
    } catch (ignoreBootstrapCoreLoaderError) {}
}

function value(value, fallback) {
    var text = value === undefined || value === null ? "" : String(value);
    return text || fallback || "";
}

function decodeEscapes(text) {
    return String(text || "")
        .replace(/\\u([0-9a-fA-F]{4})/g, function(_, hex) {
            return String.fromCharCode(parseInt(hex, 16));
        })
        .replace(/\\x([0-9a-fA-F]{2})/g, function(_, hex) {
            return String.fromCharCode(parseInt(hex, 16));
        })
        .replace(/\\r\\n|\\n|\\r/g, "\n");
}

function decodeEntities(text) {
    return String(text || "")
        .replace(/&nbsp;/gi, " ")
        .replace(/&amp;/gi, "&")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">")
        .replace(/&quot;/gi, "\"")
        .replace(/&#39;|&apos;/gi, "'")
        .replace(/&#(\d+);/g, function(_, code) {
            return String.fromCharCode(Number(code));
        })
        .replace(/&#x([0-9a-fA-F]+);/g, function(_, code) {
            return String.fromCharCode(parseInt(code, 16));
        });
}

function cleanText(text) {
    var cleaned = decodeEntities(decodeEscapes(text));
    cleaned = cleaned.replace(/\[a=cr:[\s\S]*?\/\]([\s\S]*?)\[\/a\]/gi, "$1");
    cleaned = cleaned.replace(/\[a=[^\]]*\]/gi, "").replace(/\[\/a\]/gi, "");
    cleaned = cleaned.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, " ");
    return cleaned.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
}

function singleLine(text) {
    return cleanText(text).replace(/\s+/g, " ").trim();
}

function escapeHtml(text) {
    return String(text || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function firstClean(object, keys) {
    for (var index = 0; index < keys.length; index++) {
        var text = singleLine(value(object[keys[index]], ""));
        if (text) return text;
    }
    return "";
}

function uniqueTexts(values) {
    var seen = {};
    return values.filter(function(item) {
        var text = singleLine(value(item, ""));
        if (!text || seen[text]) return false;
        seen[text] = true;
        return true;
    }).map(function(item) {
        return singleLine(value(item, ""));
    });
}

function sectionTitle(title, color, centered) {
    var content = "<font color=\"" + color + "\"><b>" + escapeHtml(title) + "</b></font>";
    return centered ? "<center>" + content + "</center>" : content;
}

function pushInfoLine(lines, label, text) {
    var cleaned = singleLine(text);
    if (cleaned) lines.push(label + "：" + cleaned);
}

function usefulTitle(text) {
    var title = singleLine(text);
    if (!title || /^未命名(?:\s*\d+)?$/i.test(title)) return "";
    return title;
}

function preferredTitle(detailTitle, listTitle) {
    var detail = usefulTitle(detailTitle);
    var original = usefulTitle(listTitle);
    if (!detail) return original;
    var parts = detail.split(/\s*\.{3,}\s*/).filter(function(part) { return part !== ""; });
    if (parts.length >= 2 && parts[0] === parts[parts.length - 1]) {
        if (original && original.indexOf(parts[0]) === 0) return original;
        return parts[0];
    }
    return detail;
}

function episode(entry, index) {
    var text = String(entry || "");
    var separator = text.indexOf("$");
    if (separator < 0) return {name: "播放 " + (index + 1), id: text};
    return {
        name: text.slice(0, separator) || "播放 " + (index + 1),
        id: text.slice(separator + 1)
    };
}

function isNovelEpisodeTarget(sourceName, routeFlag, playId) {
    var id = String(playId || "");
    var flag = String(routeFlag || "");
    var source = String(sourceName || "");

    if (/^(?:novel|marchnovel):\/\//i.test(id)) return true;
    if (/^data:text\/html(?:;[^,]*)?,/i.test(id)) return true;
    if (/(?:小说|正文|阅读)/.test(flag)) return true;

    // "@@" is also widely used by video sources for Referer and metadata.
    // Only treat this legacy chapter format as a novel when the source itself is novel-oriented.
    return id.indexOf("@@") >= 0 && /(?:小说|七猫|书城)/i.test(source);
}

function pushPlayLists(vod, detailTitle, detailPic) {
    var flags = value(vod.vod_play_from, "播放").split("$$$");
    var groups = value(vod.vod_play_url, "").split("$$$");
    var routes = [];
    groups.forEach(function(group, groupIndex) {
        var episodes = String(group || "").split("#").filter(function(item) { return item !== ""; });
        if (!episodes.length) return;
        routes.push({
            flag: singleLine(value(flags[groupIndex], "线路 " + (groupIndex + 1))) || ("线路 " + (groupIndex + 1)),
            episodes: episodes,
            originalIndex: groupIndex
        });
    });
    if (/(?:韩国\s*KBJ|sexkbj)/i.test(String(sourceName || ""))) {
        routes.sort(function(a, b) {
            var aPreferred = /(?:^|[^a-z0-9])hls2(?:[^a-z0-9]|$)/i.test(a.flag) ? 0 : 1;
            var bPreferred = /(?:^|[^a-z0-9])hls2(?:[^a-z0-9]|$)/i.test(b.flag) ? 0 : 1;
            return aPreferred - bPreferred || a.originalIndex - b.originalIndex;
        });
    }
    if (!routes.length) {
        items.push({title: "当前条目没有播放地址", col_type: "text_center_1", url: "hiker://empty"});
        return;
    }

    var statePrefix = "py_detail_" + md5(sourceId + "@" + vodId);
    var routeKey = statePrefix + "_route";
    var pageKey = statePrefix + "_page";
    var sortKey = statePrefix + "_sort";
    var routeIndex = Math.max(0, Math.min(routes.length - 1, Number(getMyVar(routeKey, "0") || 0)));
    var route = routes[routeIndex];
    var descending = String(getMyVar(sortKey, "") || "") === "desc";
    var allEpisodes = route.episodes.slice();
    if (descending) allEpisodes.reverse();

    routes.forEach(function(currentRoute, index) {
        var selected = index === routeIndex;
        items.push({
            title: currentRoute.flag,
            col_type: "scroll_button",
            url: $("#noLoading#").lazyRule(function(routeKey, pageKey, index) {
                putMyVar(routeKey, String(index));
                putMyVar(pageKey, "0");
                refreshPage(false);
                return "hiker://empty";
            }, routeKey, pageKey, index),
            extra: selected
                ? {backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false}
                : {lineVisible: false}
        });
    });

    var pageSize = 60;
    var pageCount = Math.max(1, Math.ceil(allEpisodes.length / pageSize));
    var currentPage = Math.max(0, Math.min(pageCount - 1, Number(getMyVar(pageKey, "0") || 0)));
    items.push({
        title: descending ? "倒序" : "正序",
        col_type: "scroll_button",
        url: $("#noLoading#").lazyRule(function(sortKey, pageKey) {
            putMyVar(sortKey, String(getMyVar(sortKey, "") || "") === "desc" ? "" : "desc");
            putMyVar(pageKey, "0");
            refreshPage(false);
            return "hiker://empty";
        }, sortKey, pageKey),
        extra: {backgroundColor: "#E8F5F1", textColor: "#116B58", lineVisible: false}
    });
    if (pageCount > 1) {
        items.push({
            title: "上一页",
            col_type: "scroll_button",
            url: $("#noLoading#").lazyRule(function(pageKey, currentPage, pageCount) {
                putMyVar(pageKey, String(currentPage > 0 ? currentPage - 1 : pageCount - 1));
                refreshPage(false);
                return "hiker://empty";
            }, pageKey, currentPage, pageCount),
            extra: {lineVisible: false}
        });
        items.push({
            title: (currentPage + 1) + " / " + pageCount,
            col_type: "scroll_button",
            url: "hiker://empty",
            extra: {lineVisible: false}
        });
        items.push({
            title: "下一页",
            col_type: "scroll_button",
            url: $("#noLoading#").lazyRule(function(pageKey, currentPage, pageCount) {
                putMyVar(pageKey, String(currentPage + 1 < pageCount ? currentPage + 1 : 0));
                refreshPage(false);
                return "hiker://empty";
            }, pageKey, currentPage, pageCount),
            extra: {lineVisible: false}
        });
    }

    allEpisodes.slice(currentPage * pageSize, (currentPage + 1) * pageSize).forEach(function(entry, visibleIndex) {
        var originalIndex = descending ? allEpisodes.length - 1 - (currentPage * pageSize + visibleIndex) : currentPage * pageSize + visibleIndex;
        var play = episode(entry, originalIndex);
        var episodeName = singleLine(play.name) || ("播放 " + (originalIndex + 1));
        // 把当前线路的所有剧集（分辨率）一起传给 resolvePlay：
        // 多清晰度源（如 FreePornVideos 的 2160P/720P/480P 分集）点击任一集播放时，
        // 播放页线路面板显示全部清晰度可切换；普通源只有 1 个剧集则保持单线路。
        var routeEpisodes = allEpisodes.slice();
        // 小说章节按明确协议、线路语义或小说源的旧章节格式识别。
        // 视频源也可能用 "@@" 传 Referer/元数据，不能仅凭分隔符进入阅读页。
        // 章节按钮直接指向 py_reader 阅读页（静态 URL，
        // 海阔点击即跳转新页面；不走 lazyRule——lazyRule 返回值会被海阔
        // 当作播放地址，hiker://page/ 不跳转）。
        var playRawId = String(play.id || "");
        var isNovelEpisode = isNovelEpisodeTarget(sourceName, route.flag, playRawId);
        if (isNovelEpisode) {
            // 存当前线路章节 id 列表（供 py_reader 上一章/下一章使用）
            try {
                var chapterListKey = "py_chapters_" + md5(sourceId + "@" + vodId);
                var chapterIdList = allEpisodes.map(function(entryItem) {
                    return episode(entryItem, 0).id;
                });
                putMyVar(chapterListKey, JSON.stringify(chapterIdList));
                // 存 vodId/书名/封面到 MyVar（extra 传参可能丢失，reader 章目录按钮兜底）。
                // 用固定 key（不依赖 sourceId），py_detail 从阅读页跳回时 MY_PARAMS 可能全空
                putMyVar("py_reader_meta", JSON.stringify({sourceId: sourceId, vodId: vodId, name: detailTitle, pic: detailPic}));
            } catch (ignoreChapterListError) {}
            items.push({
                title: episodeName,
                col_type: "text_4",
                // #readTheme# 阅读模式：点击正文中央调出阅读设置（字号/行距/背景），
                // 支持点击/音量翻页、进度记忆。仅此一个标记，不带 ## 连写避免解析异常
                url: "hiker://page/py_reader_v1845?c=" + md5(playRawId).slice(0, 8) + "#readTheme#",
                extra: {
                    sourceId: sourceId,
                    flag: String(route.flag || ""),
                    chapterId: playRawId,
                    title: episodeName,
                    // vodId 可能是海阔保留字段（extra 传参丢失），用自定义 pid 传递
                    pid: vodId,
                    name: detailTitle,
                    pic: detailPic,
                    cls: "playlist py_route_" + route.originalIndex,
                    backgroundColor: "#F5F7F6",
                    lineVisible: false,
                    textAlign: "center"
                }
            });
            return;
        }
        items.push({
            title: episodeName,
            col_type: "text_4",
            url: $("hiker://empty").lazyRule(function(currentSourceId, currentFlag, playId, label, currentVodId, currentTitle, currentPic, loadCore, routeEpisodes) {
                try {
                    if (typeof showLoading === "function") showLoading("正在解析播放地址...");
                    if (!loadCore) throw new Error("\u672c\u5730\u64ad\u653e\u6838\u5fc3\u52a0\u8f7d\u5668\u7f3a\u5931");
                    var module = eval("(" + loadCore + ")")(["resolvePlay", "recordHistory"]);
                    var playResult = module.resolvePlay(currentSourceId, currentFlag, playId, label, currentVodId, routeEpisodes);
                    module.recordHistory({sourceId: currentSourceId, vodId: currentVodId, title: currentTitle, pic: currentPic, flag: currentFlag, episodeName: label, playId: playId});
                    return playResult;
                } catch (error) {
                    return "toast://播放解析失败: " + (error && error.toString ? error.toString() : String(error));
                } finally {
                    try { if (typeof hideLoading === "function") hideLoading(); } catch (ignoreHideLoadingError) {}
                }
            }, sourceId, route.flag, play.id, episodeName, vodId, detailTitle, detailPic, callbackCoreLoader, routeEpisodes),
            extra: {cls: "playlist py_route_" + route.originalIndex, backgroundColor: "#F5F7F6", lineVisible: false, textAlign: "center"}
        });
    });
}

try {
    var result = core.detailSource(sourceId, vodId, {
        name: value(MY_PARAMS.name, ""),
        pic: value(MY_PARAMS.pic, "")
    }) || {};
    var list = Array.isArray(result.list) ? result.list : [];
    if (!list.length) throw new Error("详情接口没有返回影片数据");
    var vod = list[0] || {};
    var title = preferredTitle(vod.vod_name, MY_PARAMS.name) || "详情";
    // 列表页已经定位到当前影片的封面；详情 HTML 的第一张图可能是广告。
    var pic = value(MY_PARAMS.pic, value(vod.vod_pic, ""));
    var actor = firstClean(vod, ["vod_actor", "actor", "actors", "cast"]);
    var director = firstClean(vod, ["vod_director", "director", "directors"]);
    var genres = uniqueTexts([vod.vod_class, vod.type_name, vod.vod_tag]);
    var area = firstClean(vod, ["vod_area", "area"]);
    var year = firstClean(vod, ["vod_year", "year"]);
    var language = firstClean(vod, ["vod_lang", "language", "lang"]);
    var status = firstClean(vod, ["vod_remarks", "vod_serial", "remarks", "status"]);
    var infoLines = [];

    var sourceName = "";
    try { sourceName = String(core.getSource(sourceId).name || ""); } catch (ignoreSourceNameError) {}
    pushInfoLine(infoLines, "来源", sourceName);
    pushInfoLine(infoLines, "演员", actor);
    pushInfoLine(infoLines, "导演", director);
    pushInfoLine(infoLines, "类型", genres.join(" "));
    var regionLine = [];
    if (area) regionLine.push("地区：" + area);
    if (year) regionLine.push("年份：" + year);
    if (language) regionLine.push("语言：" + language);
    if (regionLine.length) infoLines.push(regionLine.join("   "));
    pushInfoLine(infoLines, "状态", status);

    setPageTitle(title);
    var cover = core.imageUrl(sourceId, pic, vodId);
    items.push({
        title: title,
        desc: infoLines.join("\n"),
        pic_url: cover,
        img: cover,
        col_type: "movie_1_vertical_pic",
        // 点击封面直接打开海阔图片查看器：直接放图片 URL，海阔会自动识别
        // 图片类型并跳转大图查看器（加密/代理图同样走海阔图片加载框架）。
        // 不用 pics:// 前缀：其解析器会按 & 拆分代理 URL 导致多图错乱。
        url: cover || "hiker://empty",
        extra: {lineVisible: false, img: cover}
    });
    var content = cleanText(vod.vod_content);
    if (content) {
        items.push({
            title: sectionTitle("∷ 剧情简介", "#2998a8", false),
            col_type: "rich_text",
            url: "hiker://empty",
            extra: {textSize: 17}
        });
        items.push({
            title: content,
            col_type: "long_text",
            url: "hiker://empty",
            extra: {textSize: 17, lineVisible: false}
        });
    }
    pushPlayLists(vod, title, pic);
} catch (error) {
    setPageTitle(value(MY_PARAMS.name, "详情"));
    items.push({
        title: "详情加载失败，点击重试",
        desc: core.errorText(error),
        col_type: "text_center_1",
        url: $("#noLoading#").lazyRule(function() {
            refreshPage(true);
            return "hiker://empty";
        })
    });
}

setResult(items);
