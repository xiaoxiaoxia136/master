var core = $.require("hiker://page/py_core_v1845");
var callbackCoreLoader = core.callbackCoreLoaderSource();
var items = [];
var keyword = "";
var currentPage = Number(typeof MY_PAGE === "undefined" ? 1 : (MY_PAGE || 1));

// 安全取关键词：MY_PARAMS/MY_KEYWORD 可能是未定义变量（直接引用会 ReferenceError
// 被外层 catch 吞掉导致后续解码不执行），全部用 typeof 判断。
try {
    var kwFromParams = (typeof MY_PARAMS !== "undefined" && MY_PARAMS) ? MY_PARAMS.keyword : "";
    var kwFromKeyword = (typeof MY_KEYWORD !== "undefined") ? MY_KEYWORD : "";
    keyword = String(kwFromParams || kwFromKeyword || getParam("keyword") || "");
} catch (ignoreKeywordError) {
    try { keyword = String(getParam("keyword") || ""); } catch (ignoreParamError) {}
}

// 海阔 URL 跳转传参带编码（%E5%B7%A8...）。decodeURIComponent 在部分 Rhino
// 环境对中文 %XX 序列抛异常，这里用手写 UTF-8 百分号解码器，循环解到无 %XX。
// 注意：解码必须在任何 try/catch 之外无条件执行，否则一旦上面取值抛异常
// 解码器永远不会运行，标题和搜索都会保持编码状态。
function percentDecodeUtf8(text) {
    var bytes = [];
    var i = 0;
    while (i < text.length) {
        if (text[i] === "%" && i + 2 < text.length && /^[0-9a-fA-F]{2}$/.test(text.slice(i + 1, i + 3))) {
            bytes.push(parseInt(text.slice(i + 1, i + 3), 16));
            i += 3;
        } else {
            var code = text.charCodeAt(i);
            if (code < 128) {
                bytes.push(code);
            } else {
                bytes.push(0xEF, 0xBF, 0xBD); // 非 % 的宽字符原样转 UTF-8 占位（理论上不出现）
            }
            i += 1;
        }
    }
    // UTF-8 → JS string
    var out = "";
    var pos = 0;
    while (pos < bytes.length) {
        var b0 = bytes[pos];
        if (b0 < 0x80) {
            out += String.fromCharCode(b0);
            pos += 1;
        } else if (b0 >= 0xC2 && b0 <= 0xDF && pos + 1 < bytes.length) {
            out += String.fromCharCode(((b0 & 0x1F) << 6) | (bytes[pos + 1] & 0x3F));
            pos += 2;
        } else if (b0 >= 0xE0 && b0 <= 0xEF && pos + 2 < bytes.length) {
            out += String.fromCharCode(((b0 & 0x0F) << 12) | ((bytes[pos + 1] & 0x3F) << 6) | (bytes[pos + 2] & 0x3F));
            pos += 3;
        } else if (b0 >= 0xF0 && b0 <= 0xF7 && pos + 3 < bytes.length) {
            var cp = ((b0 & 0x07) << 18) | ((bytes[pos + 1] & 0x3F) << 12) | ((bytes[pos + 2] & 0x3F) << 6) | (bytes[pos + 3] & 0x3F);
            cp -= 0x10000;
            out += String.fromCharCode(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF));
            pos += 4;
        } else {
            out += String.fromCharCode(b0);
            pos += 1;
        }
    }
    return out;
}
var decodeRound = 0;
while (/%[0-9a-fA-F]{2}/.test(keyword) && decodeRound < 4) {
    var before = keyword;
    keyword = percentDecodeUtf8(keyword);
    if (keyword === before) break;
    decodeRound += 1;
}

function cleanLabel(value, fallback) {
    var text = value === undefined || value === null ? "" : String(value);
    text = text
        .replace(/\\u([0-9a-fA-F]{4})/g, function(_, hex) { return String.fromCharCode(parseInt(hex, 16)); })
        .replace(/\\x([0-9a-fA-F]{2})/g, function(_, hex) { return String.fromCharCode(parseInt(hex, 16)); })
        .replace(/<br\s*\/?>/gi, " ")
        .replace(/<[^>]+>/g, " ")
        .replace(/\s+/g, " ")
        .trim();
    return text || fallback || "";
}

function notifyNextPage(message) {
    if (currentPage <= 1 || typeof toast !== "function") return;
    try { toast(message); } catch (ignorePageToastError) {}
}

function sourceLabel(source) {
    source = source || {};
    var fileName = cleanLabel(source.fileName, "").replace(/\.py$/i, "");
    var name = cleanLabel(source.name, fileName || "视频源")
        .replace(/&#(?:x[0-9a-fA-F]+|\d+);/g, " ")
        .replace(/^[^0-9A-Za-z\u4e00-\u9fff]+/, "")
        .replace(/[|｜].*$/, "")
        .replace(/\s+/g, " ")
        .trim();
    return name || fileName || "视频源";
}

function filterKey() {
    try { return "py_search_source_" + md5(keyword); } catch (ignoreMd5Error) {
        return "py_search_source_" + encodeURIComponent(keyword).slice(0, 80);
    }
}

function detailRoute(sourceId, vod) {
    var folder = String(vod.vod_tag || "").toLowerCase() === "folder";
    return folder ? {
        url: "hiker://page/py_category_v1845?page=fypage##fypage",
        extra: {
            sourceId: sourceId,
            tid: String(vod.vod_id || ""),
            name: cleanLabel(vod.vod_name, "分类"),
            extend: {},
            filters: {},
            lineVisible: false
        }
    } : {
        url: "hiker://page/py_detail_v1845",
        extra: {
            sourceId: sourceId,
            vodId: String(vod.vod_id || ""),
            name: cleanLabel(vod.vod_name, "详情"),
            pic: String(vod.vod_pic || ""),
            lineVisible: false
        }
    };
}

function pushSourceTag(title, sourceId, selected, key) {
    // 选中源加 "🔴 " 前缀：搜索页横向标签栏的折叠按钮（>）展开的是海阔原生
    // selectBottomRes 弹窗，它只按标签 title 渲染文本、不支持选中高亮样式，
    // 因此用 emoji 前缀让当前源在原生弹窗里也能一眼看出选中状态。
    // 标签栏本体同时保留绿底白字高亮（extra.backgroundColor #168C72）。
    var displayTitle = selected ? "🔴 " + title : title;
    items.push({
        title: displayTitle,
        col_type: "scroll_button",
        url: $("#noLoading#").lazyRule(function(stateKey, selectedSourceId, loaderSource) {
            try {
                putMyVar(stateKey, selectedSourceId);
                if (selectedSourceId) {
                    eval(loaderSource)(["setCurrentSource"]).setCurrentSource(selectedSourceId);
                }
                refreshPage(false);
            } catch (ignoreSwitchSourceError) {}
            return "hiker://empty";
        }, key, sourceId, callbackCoreLoader),
        extra: selected ? {backgroundColor: "#168C72", textColor: "#FFFFFF", lineVisible: false} : {lineVisible: false}
    });
}

function searchTask(param) {
    try {
        var module = eval(param.loaderSource)(["searchSource"]);
        var result = module.searchSource(param.sourceId, param.keyword, param.page) || {};
        var list = Array.isArray(result.list) ? result.list : [];
        var pageCount = Number(result.pagecount || result.pageCount || 0);
        if (pageCount > 0 && Number(param.page) > pageCount) list = [];
        return JSON.stringify({
            sourceId: param.sourceId,
            sourceName: param.sourceName,
            sourceIndex: param.sourceIndex,
            list: list.slice(0, param.limit)
        });
    } catch (error) {
        return JSON.stringify({
            sourceId: param.sourceId,
            sourceName: param.sourceName,
            sourceIndex: param.sourceIndex,
            list: [],
            error: error && error.toString ? error.toString() : String(error)
        });
    }
}

function runSearch(targets) {
    var collected = [];
    var tasks = targets.map(function(source, sourceIndex) {
        return {
            func: searchTask,
            param: {
                sourceId: source.id,
                sourceName: sourceLabel(source),
                sourceIndex: sourceIndex,
                keyword: keyword,
                page: String(currentPage),
                limit: targets.length > 1 ? 20 : 60,
                loaderSource: callbackCoreLoader
            },
            id: String(source.id)
        };
    });

    if (typeof batchExecute === "function" && tasks.length > 1) {
        batchExecute(tasks, {
            func: function(param, id, error, taskResult) {
                try {
                    param.results.push(JSON.parse(String(taskResult || "{}")));
                } catch (parseError) {
                    param.results.push({sourceId: id, sourceName: id, sourceIndex: 9999, list: [], error: String(error || parseError)});
                }
            },
            param: {results: collected}
        });
    } else {
        tasks.forEach(function(task) {
            collected.push(JSON.parse(searchTask(task.param)));
        });
    }
    return collected.sort(function(left, right) {
        return Number(left.sourceIndex || 0) - Number(right.sourceIndex || 0);
    });
}

try {
    setPageTitle(keyword ? "搜索 · " + keyword + "" : "全源搜索");
    if (!keyword) throw new Error("请输入搜索关键词");
    notifyNextPage("正在加载下一页");

    var index = core.getIndex();
    var sources = Array.isArray(index.sources) ? index.sources : [];
    if (!sources.length) throw new Error("请先导入 PY 文件");

    var stateKey = filterKey();
    var selectedSourceId = String(getMyVar(stateKey, "") || "");
    try {
        addListener("onClose", $.toString(function(key) {
            putMyVar(key, "");
        }, stateKey));
    } catch (ignoreCloseListenerError) {}
    if (selectedSourceId && !sources.some(function(source) { return source.id === selectedSourceId; })) {
        selectedSourceId = "";
        putMyVar(stateKey, "");
    }
    // 默认只搜索当前激活源：进入搜索页直接展示当前源结果，避免全源并发
    // 慢、结果分散。用户点击其他源标签时 refreshPage 实时只加载该源。
    if (!selectedSourceId) {
        try {
            var currentSource = core.getCurrentSource();
            if (currentSource && currentSource.id && sources.some(function(source) { return source.id === currentSource.id; })) {
                selectedSourceId = String(currentSource.id);
                putMyVar(stateKey, selectedSourceId);
            }
        } catch (ignoreDefaultSourceError) {}
    }

    if (currentPage === 1) {
        // 源标签栏：当前激活源置顶（紧跟"全部"），保证搜索页一眼可见当前源及其选中高亮。
        // 其余源按原顺序跟在后面；横向滚动可查看全部。
        var orderedSources = sources.slice();
        if (selectedSourceId) {
            var activeIndex = -1;
            orderedSources.forEach(function(source, index) {
                if (String(source.id) === String(selectedSourceId)) activeIndex = index;
            });
            if (activeIndex > 0) {
                var activeSource = orderedSources.splice(activeIndex, 1)[0];
                orderedSources.unshift(activeSource);
            }
        }
        pushSourceTag("全部", "", !selectedSourceId, stateKey);
        orderedSources.forEach(function(source) {
            pushSourceTag(sourceLabel(source), source.id, source.id === selectedSourceId, stateKey);
        });
    }

    var targets = selectedSourceId
        ? sources.filter(function(source) { return source.id === selectedSourceId; })
        : sources;
    var groups = runSearch(targets);
    var total = 0;
    var failed = 0;

    groups.forEach(function(group) {
        if (group.error) failed += 1;
        var sourceList = core.normalizeVodList(group.list || []);
        sourceList.forEach(function(vod) {
            var route = detailRoute(group.sourceId, vod || {});
            var remarks = cleanLabel(vod.vod_remarks || vod.vod_year, "");
            var pic = core.imageUrl(group.sourceId, vod.vod_pic, vod.vod_id);
            items.push({
                title: cleanLabel(vod.vod_name, "未命名"),
                desc: cleanLabel(group.sourceName, "视频源") + (remarks ? " · " + remarks : ""),
                pic_url: pic,
                img: pic,
                col_type: "movie_2",
                url: route.url,
                extra: Object.assign({}, route.extra, {img: pic})
            });
            total += 1;
        });
    });

    if (currentPage > 1 && !total && !failed) notifyNextPage("到底了");

    if (!total && currentPage === 1) {
        items.push({
            title: selectedSourceId ? "当前源没有搜索结果" : "所有视频源均没有搜索结果",
            col_type: "text_center_1",
            url: "hiker://empty",
            extra: {lineVisible: false}
        });
    }
    if (failed && currentPage === 1) {
        items.push({
            title: "有 " + failed + " 个源暂时无响应",
            col_type: "text_center_1",
            url: "hiker://empty",
            extra: {lineVisible: false}
        });
    }
} catch (error) {
    items.push({
        title: "搜索失败",
        desc: core.errorText(error),
        col_type: "text_center_1",
        url: "hiker://empty",
        extra: {lineVisible: false}
    });
}

setResult(items);
